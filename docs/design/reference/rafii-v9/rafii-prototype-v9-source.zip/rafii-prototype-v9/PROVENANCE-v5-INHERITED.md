# v5 provenance and adaptation boundary

## Starting point

The supplied `rafii-prototype-v4.html` and `rafii-prototype-v4-source.zip` were used as the base. Original attachments remain unchanged. The v4 phone-motion engine is preserved byte-for-byte; swipe is a separate input adapter around the existing switching functions. Native-app mockups and monochrome glass tokens are inherited from v4. See `PROVENANCE-v4-INHERITED.md` for their older provenance; those phone/theme files were not independently re-fetched in v5.

## Repository reads performed in v5

Remote repository: `dev-james0723/PostRiff`, associated with the James-Au-Studio / Rafii project in the inherited provenance.
Branch: `consumer-saas`.
Pinned commit re-verified through GitHub: `468811b73d28b4389f931519827c05d0e6c8abfb`.
A search for a literal installed repository named `james-au-studio` returned no match. The inherited remote mapping above was used. No claim is made about the current laptop checkout, unpushed code, or a newer deployment.

Read through the connected GitHub tools:

- `web/src/components/application/language-picker/language-picker.tsx`
- The `web/src/lib/locales/` directory and initial ranges of `catalogue.generated.json`
- `scripts/build_locale_catalogue.mjs`, including all seed sets and build logic

The original picker is search-first, with native language names, flags, English subtitles, families, suggested choices, recents, keyboard navigation and a mobile sheet/desktop popover. These concepts are ported into the prototype's existing dialog system and liquid-glass surfaces. The React/Tailwind/Drawer/Popover implementation and live production providers are not imported.

## Locale data precision

The complete generated JSON bytes were not available in the working container. The offline UI catalogue was reconstructed from the inspected source builder's **complete tag seed sets**: 55 curated entries, 8 regionless entries, 21 extra regional entries and 112 additional language entries, totalling 196. Curated native/English names and useful search aliases were transcribed from the source. Regional and additional-language labels are generated at build time with the source's Intl.DisplayNames approach. The catalogue records this environment's ICU/CLDR version. The remote generated file reported ICU 78.3 / CLDR 48.0; the local builder used ICU 77.1. Some fallback labels can therefore differ.

This is a UI projection, not the full backend locale registry: it does not carry every production promptName, writing guide, source alias, grammatical metadata or reviewed status. Production-quality translation, locale-specific writing guidance and complete behavioural parity with the original locale core are outside this offline demo. The 196 choices are selectable and retained in per-channel preferences; unsupported sample-text languages remain labelled placeholders.

No fonts were copied or distributed. Flags and glyphs use device/system fonts.

## Model panel

The supplied `IMG_1159.jpg` is the visual reference. xAI model names, descriptions and badges reproduce that supplied image for layout purposes only. They have not been verified as live models or capabilities. The picker explicitly discloses this. All other presets and capability badges are illustrative UI state. Provider marks are small inline SVG approximations. API and CLI modes do not connect to any service or run commands.

## Scope

All source changes were made only in a separate working copy of the downloadable prototype. No GitHub write operations, production edits, pushes or deployments were performed. No external requests occur when the bundled demo runs.
