# Rafii v9 · Channel Folders

Open `index.html` in a browser. The bundled HTML is self-contained, including the retained v8 features. There is no installation, API key, server or external asset dependency.

## Try it

Open the channel stack in the composer. Three editable **example folders** are supplied: Personal, Festival, Professional. These are demo groups and not real connected accounts.

- Tap a folder's main area to add all its accounts. An already fully selected folder removes its members. Partial selection displays a minus and “2 of 3 selected”. The chevron only opens the account inspector.
- Use checkboxes inside an open folder or Individual accounts to make exceptions for this draft. A single account may belong to several folders. Counts and generated drafts are deduplicated.
- **Done** commits destinations to the draft. Cancel/close discards pending destination changes. **Undo** restores the last selection change, including overlapping folder states.
- **New folder** creates a group. **Save selection as folder** starts with the selected accounts. Name the folder, optionally choose a symbol, choose members and pin it to the shelf.
- Open a folder and select **Edit** to change its name, symbol or members. The adjacent **More** button contains pin/unpin, duplicate, move up/down and delete. Reordering works within the pinned/unpinned section. The compact shelf shows at most four folders; View all reveals the rest.
- One search field finds folders, platforms and account handles. Saving, editing or deleting a folder never silently changes the draft's destinations or output settings.

## Saved data and limitations

Only folder definitions (IDs, names, member account IDs, symbol and pin state) use localStorage, when the browser permits it. They can survive reloads in a normal allowed origin. If storage is unavailable, the footer explicitly reports **Session-only folders**. This is common in restricted document previewers. Nothing is uploaded or synced. Live drafts, source notes, model preferences and the demo queue still live only in this tab.

Saved folder edits are explicit library changes, separate from the draft selection transaction. Closing Channel Bloom does not undo an already saved folder edit. Resetting the draft demo keeps saved folders. Deleting a folder does not disconnect or deselect accounts. Draft folder labels use membership snapshots so later folder edits do not rewrite an existing draft's destinations.

This prototype contains **six demo accounts, one per platform**. Folder membership is keyed by stable account ID, not platform name. The folder core preserves two different account IDs even when they share a platform; connecting additional accounts and adapting the generation pipeline for real multi-account publishing is outside this prototype. No actual account, AI, CLI or publishing service is connected. There is a 50-folder limit, 40-character names, and no nested folders. Drag-to-group, covers and workflow presets remain deferred as discussed.

## Retained features

The v8 Content Library (31 editorial types, 20 native formats, Gallery/List/Pairings, local animated SVGs, filters and information panels), model/reasoning demo picker, per-channel languages, expanded editor, six phone previews, swipe/slide/crossfade and session queue are retained. Folder selection changes destinations only.

## Source

- `src/folders-core.js`: pure account-set, mixed-state, membership, ordering, snapshot and storage validation helpers.
- `src/folders-ui.js`: folder shelf, inspector, creation/editor, selection transaction, Undo and guarded local storage.
- `src/folders-v9.css`: scoped borderless monochrome glass styling and responsive layouts.
- `src/index.html`, `src/app.js`: minimal integration with the existing composer and Channel Bloom.
- `tests/v9/`: test-first failures, passing tests, motion checks, screenshot audit and validation records.
- `previews-v9/`: actual browser captures, not generated concepts.

Build: `python build.py`.

Targeted checks:

```sh
node --test tests/v9/folders.test.cjs
python tests/v9/test_folders.py
python tests/v9/visual_audit.py
```

Browser tests require Python Playwright and Chromium on PATH. They use `set_content`, because browser navigation to file/local URLs is restricted in the verification environment. No browser security policy was changed. See `VALIDATION.md` for results and limitations. A file previewer that does not execute JavaScript is not equivalent to an interactive browser.
