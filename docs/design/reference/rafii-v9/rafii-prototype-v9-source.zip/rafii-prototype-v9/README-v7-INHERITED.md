# Rafii interactive prototype v7

Open `index.html` in a browser. It is one self-contained file, with no install, build step, API key, remote fonts, CDN or account required. On iPhone, open as a web page in a browser rather than a document preview. Browser support on physical iOS is not verified.

## Try it
Open the content-type control in the Creation Pod. Switch between Gallery, List and Pairings. Editorial intent and Native format remain separate tabs. Pick a purpose category, search, or filter by an app's suggested fit. Filtering never changes selected draft channels.

List shows a newly simplified animated SVG, title and taxonomy tags. The circled-i button opens a descriptive popover with an eased transition. It does not select the row. Press Escape to dismiss it before dismissing the library.

Pairings shows a suggested opposite dimension and target-app fit. Use pairing changes the pending editorial/native choices. Use these choices commits them to the composer; closing without Apply discards those changes. Evidence links explain the metric, period and sample behind a format-level signal. Fit suggestions are not popularity data or supported publishing capabilities.

The purpose categories are Everyday; News & events; Teach & explain; Conversations; Showcase & proof; Products & offers; Community. Native-format groups are Reading; Visual; Video & live; Interactive; Audio; Community; Business.

All 51 large illustrations and compact pictograms have restrained motion. Offscreen artwork and artwork in a hidden browser tab pauses. Pause artwork and the OS/app reduced-motion setting quiet it. The animation is CSS/WAAPI, not a Rive or Hyperframe dependency.

The v6 phone swipe/crossfade, expanded editor, model/provider picker, reasoning preference, per-channel languages, writing voice and local draft queue remain available.

## Boundaries
This remains an offline interaction prototype. Models and capabilities are illustrative presets. It does not perform generation, translation, speech, video creation, live analytics, API/CLI calls or publishing. Native app previews are illustrative, not guarantees of current app layouts. Demo drafts and user-added sources live in the current tab and disappear on reload. Only explicitly clicking a research-source link leaves the offline page.

## Build
`python build.py` rebuilds `index.html`.
`python tools/build_library.py` regenerates v7 metadata and the 51 compact SVG assets.
`python tools/build_atlas.py` creates `thumbnail-atlas.html`, a complete visual inspection sheet.

## Verify
`node --test tests/*.cjs tests/v6/*.cjs tests/v7/*.cjs`
`python tests/v7/test_v7.py`
`python tests/v7/visual_audit.py`
`python tests/v7/run_regressions.py`

Browser tests require Python Playwright and Chromium on PATH. Tests use set_content because this environment restricts navigations to file/local-server URLs; no policy was changed. The latest v7 UI suite was also verified in two eight-test batches after a monolithic run exceeded the tool time budget. See VALIDATION.md for actual results and limitations. No physical iPhone, Safari, WebKit or Firefox was tested.

## Files
EXECUTION-PLAN.md: concrete implementation plan.
RESEARCH.md: source inventory and interpretation boundaries.
PROVENANCE.md: original work, inherited components and asset origin.
VALIDATION.md: test results and visual review evidence.
previews-v7/: actual working browser screenshots.
src/: local source, 51 compact SVGs and unchanged v6 illustrations.
thumbnail-atlas.html: all 51 compact concepts; #light / #gallery inspect alternative states.
