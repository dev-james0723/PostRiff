"""Build v7 curation and 51 deterministic compact SVG glyphs. No external assets."""
from pathlib import Path
import json, hashlib
ROOT=Path(__file__).resolve().parents[1]; SRC=ROOT/'src'
T=json.loads((SRC/'taxonomy-data.json').read_text())
def p(d): return f'<path d="{d}"/>'
def r(x,y,w,h,rad=3): return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{rad}"/>'
def c(x,y,r): return f'<circle cx="{x}" cy="{y}" r="{r}"/>'
def dot(x,y,r=2):return f'<circle cx="{x}" cy="{y}" r="{r}" fill="currentColor" stroke="none"/>'
# The moving motif is separate from the stationary body; each uses a distinct metaphor.
IC={
'status_update':(r(7,9,31,29)+p('M12 18h15M12 24h9'),c(34,31,8)+p('M34 27v4l3 2')),
'announcement':(p('M8 20h10L35 11v27L18 29H8zM14 29l3 10h5l-2-9'),p('M40 20l4-2M40 29l4 2')),
'news_curation':(r(7,8,32,32)+p('M13 14h11M13 32h20M13 36h14')+r(13,20,12,8,1),p('M29 20h5M29 25h5')+r(27,7,13,8,1)),
'opinion_commentary':(p('M8 8h29v23H22l-9 7v-7H8z')+p('M14 16h13M14 22h8'),p('M28 35l10-10 5 5-10 10-7 2zM35 28l5 5')),
'quote':(p('M10 11h28v28H10z'),p('M17 19c-4 0-4 9 0 9v-5h-3M28 19c-4 0-4 9 0 9v-5h-3')),
'question_prompt':(p('M7 9h34v27H28l-9 7v-7H7z'),p('M19 19a5 5 0 0 1 10 0c0 4-5 3-5 7')+dot(24,30,1)),
'poll_quiz':(r(6,9,36,30)+r(12,15,5,5,1)+r(12,27,5,5,1),p('M22 17h14M22 29h9M13 17l2 2 4-5')),
'how_to':(p('M7 35h10V25h10V15h13'),c(10,29,2)+c(20,20,2)+p('M32 9h9v9M27 23l13-13')),
'educational_explainer':(r(18,17,13,13,3)+p('M18 20l-7-7M31 20l7-7M24 30v8'),c(8,10,4)+c(40,10,4)+r(19,38,10,6,1)),
'list_checklist':(r(10,6,28,36)+p('M15 23h3M15 33h3M24 14h8M24 24h8M24 34h8'),p('M14 12l3 3 5-6M14 23l3 3 5-6')),
'review_comparison':(r(5,10,16,28)+r(27,10,16,28)+p('M9 29h8M31 29h8'),p('M24 6v36M9 19l3 3 5-7M31 20h8')),
'resource_roundup':(r(6,10,10,30,1)+r(19,7,10,33,1)+p('M33 12l7-2 5 28-7 2zM9 17h4M22 15h4'),p('M3 42h42M10 34h3M23 34h3')),
'product_service_showcase':(r(7,7,34,28)+p('M19 35v5M29 35v5M14 41h20')+r(13,13,12,14,1),p('M31 13v8M27 17h8')),
'product_update':(r(6,10,36,29)+p('M6 18h36M12 14h2M18 14h2')+r(12,24,10,9,2),p('M29 29h10M34 24v10')),
'launch_release':(p('M17 31c-2-12 6-21 20-24 0 14-8 23-19 25zM16 24l-9 1v11l9-4M23 32l-1 9h-9l4-9')+c(29,17,3),p('M12 35l-5 6M18 37l-3 7M9 30l-5 3')),
'promotion_offer':(p('M8 8h17l17 17-17 17L8 25z')+c(16,16,2),p('M21 22l12 10')+c(30,23,3)+c(23,31,3)),
'event_live':(r(8,10,32,31)+p('M16 6v8M32 6v8M8 20h32'),c(30,30,5)+p('M13 27h6M13 33h4')),
'behind_the_scenes':(r(7,14,34,25)+p('M7 14l31-8 2 8H7M14 13l4-5M25 13l4-8'),p('M17 22l11 6-11 6z')),
'personal_lifestyle':(r(5,9,25,32,2)+r(20,7,22,26,1)+p('M24 26l5-7 5 5 4-3M10 17h5M10 24h5M10 31h5'),c(34,14,2)+p('M29 38c2-5 9-3 6 2l-6 4-6-4c-3-5 4-7 6-2z')),
'milestone':(p('M7 39h34M10 38V26h10v12M20 38V17h10v21M30 38V8h10v30'),p('M9 18l9-6 7 1 13-10M32 3h7v7')),
'ugc_testimonial':(c(12,15,6)+p('M3 31c0-13 18-13 18 0M23 8h19v22H31l-8 5z'),p('M28 14v8h4v-4M35 14v8h4v-4')),
'case_study':(r(6,8,36,34)+p('M11 15h10M25 15h12M24 20v16'),p('M11 33l5-4 3 2M28 33l4-4 5-7M33 22h4v4')),
'qa_faq':(p('M6 7h27v17H17l-6 5v-5H6M19 27h23v13h-6l-4 4v-4H19z'),p('M15 13a4 4 0 0 1 7 1c0 3-3 3-3 6M24 33h11')),
'community_announcement':(r(6,7,36,24,2)+p('M10 13h12M10 18h25'),c(12,36,3)+c(24,36,3)+c(36,36,3)+p('M7 45v-4h10v4M19 45v-4h10v4M31 45v-4h10v4')),
'cause_advocacy':(p('M9 26v13h30V26M15 34h18M15 40v4M33 40v4'),p('M24 13c5-10 19-4 12 5l-12 10-12-10c-7-9 7-15 12-5z')),
'contest_challenge':(p('M16 7h16v14c0 11-16 11-16 0zM24 29v10M15 41h18M16 10H8v6c0 7 8 7 8 7M32 10h8v6c0 7-8 7-8 7'),p('M22 12l5 6-5 6M21 24h8')),
'job_recruitment':(r(6,14,36,26)+p('M17 14V8h14v6M6 23c9 6 27 6 36 0'),p('M19 27h10v6H19z')+p('M24 19v4')),
'article_blog_newsletter':(p('M6 12c7-3 12-2 18 2 6-4 11-5 18-2v27c-8-3-12-2-18 2-6-4-10-5-18-2zM24 14v27M11 28h8M29 28h8M11 33h8M29 33h8'),r(11,18,8,6,0)+p('M29 19h8M29 23h8')),
'recap_followup':(p('M9 24h30M11 17v14M24 17v14M37 17v14')+r(5,9,12,7,1)+r(18,33,12,7,1)+r(31,9,12,7,1),p('M31 27l-5 5 5 5M26 32h11c8 0 8-17 0-17')),
'reaction_reply':(p('M6 8h31v21H22l-9 7v-7H6')+p('M13 15h16M13 20h9'),p('M28 33l-5 5 5 5M24 38h11c8 0 8-11 2-11')),
'live_ama':(r(19,5,10,20,5)+p('M13 17v4c0 14 22 14 22 0v-4M24 34v8M18 43h12'),p('M37 7c6 4 6 9 0 13M10 7c-6 4-6 9 0 13')),
# Native format pictograms: presentation rather than editorial intent.
'text':(r(7,9,34,30),p('M14 18h20M14 24h20M14 30h12')),
'long_text':(r(10,5,28,38)+p('M16 12h16M16 17h16M16 22h16M16 29h16M16 34h11'),p('M16 38h8')),
'thread':(r(7,5,28,10)+r(13,32,28,10)+p('M21 15v6h-7v11'),r(13,19,28,9)+p('M35 28v4')),
'image_caption':(r(6,7,36,34)+p('M6 31h36M13 36h22M10 26l10-12 8 11 5-6 6 7'),c(33,14,3)),
'quote_card':(r(8,7,32,35)+p('M14 34h14'),p('M18 15c-5 0-6 12 0 12v-6h-4M31 15c-5 0-6 12 0 12v-6h-4')),
'carousel':(r(8,9,27,30)+p('M38 13h4v27H15'),p('M16 25h12M24 20l5 5-5 5')+dot(17,43,1)+dot(23,43,1)+dot(29,43,1)),
'link_preview':(r(6,9,36,30)+r(11,14,12,15,2)+p('M28 15h8M28 21h8M11 34h21'),p('M29 29l5-5c4-4 9 1 5 5l-4 4M32 32l-4 4c-4 4-9-1-5-5l4-4')),
'native_article':(r(7,7,34,35,2)+p('M7 15h34M13 11h3M13 23h21M13 28h21M13 33h14'),p('M13 19h8')),
'document':(p('M13 5h17l9 9v26H13zM30 5v10h9M9 10H5v34h26'),p('M19 22h14M19 28h14M19 34h9')),
'short_vertical_video':(r(14,4,22,40,5)+p('M21 8h8M23 40h4'),p('M21 17l9 7-9 7z')),
'long_video':(r(4,10,40,28)+p('M10 33h28'),p('M20 17l10 6-10 6z')+c(16,33,2)),
'livestream':(r(5,12,38,27)+p('M16 7l8 5 8-5M10 43h28'),dot(14,19,2)+p('M20 19h16M19 26l9 5-9 5z')),
'story':(r(13,4,24,40,5)+p('M17 9h4M24 9h4M31 9h2M19 37h12'),c(25,23,7)),
'poll':(r(6,6,36,36)+r(12,13,5,5,1)+r(12,24,5,5,1)+r(12,34,5,4,1),p('M23 15h12M23 26h7M23 36h9M12 14l3 3 5-6')),
'quiz':(r(8,5,32,37)+p('M18 12a5 5 0 0 1 10 0c0 4-5 4-5 8'),r(13,27,9,8,1)+r(26,27,9,8,1)+p('M28 30l2 2 4-5')),
'audio':(c(24,24,19)+p('M11 21v6M17 15v18M23 10v28'),p('M29 14v20M35 20v8')),
'broadcast_message':(p('M5 18h10L31 10v26l-16-8H5zM14 29l3 12h6l-3-12'),p('M35 16c5 4 5 10 0 14M40 11c8 7 8 19 0 23')),
'community_message':(p('M5 7h26v18H16l-6 5v-5H5M20 29h23v12H33l-6 5v-5h-7'),c(14,14,2)+c(22,14,2)+p('M10 20h16M25 34h12')),
'product_catalog':(r(6,7,16,16,2)+r(27,7,16,16,2)+r(6,28,16,16,2)+r(27,28,16,16,2),p('M10 17l4-5 4 5M31 12h8v7h-8M12 33h5v7h-5M31 34h8M35 30v9')),
'local_business_update':(p('M7 20h34v23H7M4 20l5-11h30l5 11M16 43V29h12v14M6 20c0 7 9 7 9 0 0 7 9 7 9 0 0 7 9 7 9 0 0 7 9 7 9 0'),c(34,8,5)+p('M34 5v3l2 1')),
}
assert len(IC)==51
cats_e=[('everyday','Everyday','Small updates & real life','status_update personal_lifestyle behind_the_scenes milestone recap_followup'),('news','News & events','What is happening','announcement news_curation event_live'),('education','Teach & explain','Make something useful','how_to educational_explainer list_checklist resource_roundup qa_faq article_blog_newsletter'),('conversation','Conversations','Invite a response','opinion_commentary quote question_prompt poll_quiz reaction_reply live_ama'),('showcase','Showcase & proof','Show what makes it work','review_comparison product_service_showcase ugc_testimonial case_study'),('growth','Products & offers','What is new or available','product_update launch_release promotion_offer'),('community','Community','Bring people together','community_announcement cause_advocacy contest_challenge job_recruitment')]
cats_n=[('reading','Text & reading','Words with room to breathe','text long_text thread native_article document'),('visual','Visual','Pictures that tell the story','image_caption quote_card carousel link_preview story'),('video','Video & live','Moving stories','short_vertical_video long_video livestream'),('interactive','Interactive','Participation, not just viewing','poll quiz'),('audio','Audio','Something to listen to','audio'),('community','Community','For a shared space','broadcast_message community_message'),('business','Business','Services, products & places','product_catalog local_business_update')]
# Curation is not a platform/API compatibility guarantee. Always retain that distinction.
P={
'status_update':[('text','threads x facebook','A short note that invites an easy reply.'),('image_caption','instagram linkedin','Add a picture when the update is visual.')],
'announcement':[('image_caption','instagram facebook linkedin','Lead with a clear message, then the details.'),('text','x threads','Keep the essential news in one short update.')],
'news_curation':[('link_preview','linkedin facebook','Keep the original source attached.'),('thread','x threads','Give each source its own piece of context.')],
'opinion_commentary':[('text','threads x linkedin','Make one clear point, then invite another view.'),('long_text','linkedin facebook','Use more space when context matters.')],
'quote':[('quote_card','instagram facebook','Turn a properly attributed quote into a visual.'),('text','threads x','Let the words stand on their own.')],
'question_prompt':[('text','threads x linkedin','Ask one specific, answerable question.'),('image_caption','instagram facebook','Use the visual to set up the question.')],
'poll_quiz':[('poll','linkedin x','A participation-first plan; check account capabilities.'),('quiz','instagram','Plan a Story-based quiz, not a feed quiz.')],
'how_to':[('carousel','instagram red','Give each practical step a separate frame.'),('document','linkedin','Package the steps in a swipeable document.')],
'educational_explainer':[('carousel','instagram red','Break a concept into a few visual steps.'),('document','linkedin','Use a document for diagrams and deeper explanation.')],
'list_checklist':[('carousel','instagram red','One useful checklist item per slide.'),('document','linkedin','An easy-to-return-to reference document.')],
'review_comparison':[('carousel','instagram red','Compare the same criteria side by side.'),('long_text','linkedin','State your criteria, evidence and limitations.')],
'resource_roundup':[('document','linkedin','Collect resources in one organised reference.'),('thread','x threads','One resource and one reason per entry.')],
'product_service_showcase':[('short_vertical_video','instagram facebook','Show the product or service in use.'),('image_caption','red linkedin','Let the visual and a concrete benefit work together.')],
'product_update':[('image_caption','linkedin x','Show what changed, not just that it changed.'),('short_vertical_video','instagram','Demonstrate the updated flow.')],
'launch_release':[('short_vertical_video','instagram facebook','Make the new thing understandable at a glance.'),('image_caption','linkedin x','Lead with the release and who it helps.')],
'promotion_offer':[('image_caption','instagram facebook','Show the offer and its terms without clutter.'),('story','instagram facebook','A time-specific offer for your existing audience.')],
'event_live':[('image_caption','facebook linkedin','Lead with what, when and where.'),('story','instagram','Share short event moments; this is not a live stream.')],
'behind_the_scenes':[('short_vertical_video','instagram facebook','Show a small piece of the real process.'),('image_caption','red threads','Pair a work-in-progress image with the story behind it.')],
'personal_lifestyle':[('image_caption','instagram red','A daily moment with personal context.'),('text','threads','A small, conversational reflection.')],
'milestone':[('image_caption','linkedin instagram','Share the milestone and what made it possible.'),('text','threads x','A small celebration and a word of thanks.')],
'ugc_testimonial':[('quote_card','instagram linkedin','Use a genuine quote with permission and attribution.'),('image_caption','facebook red','Let real customer evidence stay identifiable.')],
'case_study':[('document','linkedin','Explain the problem, method, evidence and result.'),('carousel','instagram','Turn the evidence into a short visual narrative.')],
'qa_faq':[('carousel','instagram','Answer one question per slide.'),('long_text','linkedin facebook','Collect clear answers with necessary context.')],
'community_announcement':[('community_message','facebook','A notice for a specific group; surface access varies.'),('text','threads','Make it clear who the message is for.')],
'cause_advocacy':[('image_caption','instagram facebook','Explain the cause with context and reliable sources.'),('long_text','linkedin','Keep facts, opinion and calls to action distinct.')],
'contest_challenge':[('image_caption','instagram facebook','Make steps and eligibility clear; review contest rules.'),('short_vertical_video','red','Demonstrate the challenge; check platform rules.')],
'job_recruitment':[('image_caption','linkedin','Show the role, expectations and application route.'),('link_preview','facebook','Link to the complete role description.')],
'article_blog_newsletter':[('native_article','linkedin','A reading-first plan; account and surface access vary.'),('link_preview','facebook x','Introduce a longer piece with its source link.')],
'recap_followup':[('carousel','instagram red','Sequence the moments with a clear beginning and end.'),('thread','x threads','Connect the key takeaways.')],
'reaction_reply':[('text','threads x','Respond to the actual context, not just a headline.'),('image_caption','facebook','Add a relevant image when it clarifies the response.')],
'live_ama':[('livestream','instagram facebook','Plan questions and moderation; eligibility is unverified.'),('thread','threads x','A text-based Q&A alternative, not a live broadcast.')],
}
extra={'long_video':('educational_explainer','linkedin facebook','A longer filmed explanation; limits are not verified.'),'audio':('opinion_commentary','','An audio plan. No direct match among the six demo apps is verified.'),'broadcast_message':('community_announcement','instagram','Plan for an eligible broadcast surface, not a regular feed post.'),'product_catalog':('product_service_showcase','facebook instagram','Commerce-enabled surface only; availability is not verified.'),'local_business_update':('event_live','facebook','A local update plan. Adapt to an available Page surface.')}
E={
'ig-saves':dict(label='Save-focused format',kind='Engagement signal',publisher='Metricool',date='2026-06-16',url='https://metricool.com/press-release-instagram-study-2026/',finding='Carousels generated nine times more saves than single-image posts in the study.',sample='24,364,803 Instagram posts; 375,118 accounts; Jan–Feb 2025 vs Jan–Feb 2026.',limit='Averages in this sample, not a popularity rank or proof that a specific editorial topic works.'),
'ig-usage':dict(label='Usage ≠ engagement',kind='Usage signal',publisher='Metricool',date='2026-06',url='https://metricool.com/instagram-carousel-multiple-captions/',finding='Carousels were used 37% less often than single-image posts in Metricool’s 2026 Instagram analysis.',sample='2026 Instagram study; Jan–Feb 2025 vs Jan–Feb 2026.',limit='Relative usage in the sample, not the most-used editorial type and not live trend data.'),
'li-docs':dict(label='Document engagement',kind='Engagement signal',publisher='Buffer',date='2026-03-19',url='https://buffer.com/resources/data-best-content-format-social-media/',finding='LinkedIn document carousels recorded a 21.77% median engagement rate in this dataset.',sample='Buffer-published posts; underlying engagement report data through Dec 3, 2025.',limit='LinkedIn documents, not Instagram image carousels. Engagement is platform-defined; no cross-platform ranking.'),
'li-usage':dict(label='What gets posted',kind='Usage signal',publisher='Metricool',date='2026-04-14',url='https://metricool.com/press-release-linkedin-study-2026/',finding='Images and video made up nearly 75% of Company Page posts; video was the most-used format among Personal Profiles in this sample.',sample='673,658 posts; 63,108 LinkedIn accounts; Jan–Feb 2025 vs Jan–Feb 2026.',limit='Company Pages and Personal Profiles differ. This measures format use, not which editorial topic is most popular.'),
'ig-reach':dict(label='Discovery vs depth',kind='Engagement signal',publisher='Buffer',date='2026-03-05',url='https://buffer.com/resources/state-of-social-media-engagement-2026/',finding='The Instagram reach study found Reels reached 36% more people than carousels.',sample='Separate Instagram analysis: 4M+ Buffer posts, Jan 2022–Oct 2024.',limit='Older reach data, not a current algorithm guarantee. It does not measure editorial topic popularity.'),
'x-text':dict(label='Text engagement',kind='Engagement signal',publisher='Buffer',date='2026-03-19',url='https://buffer.com/resources/data-best-content-format-social-media/',finding='X text posts had 3.56% median engagement, compared with 3.40% for images.',sample='Buffer-published posts; 2026 format report, underlying data through Dec 3, 2025.',limit='Format-level, not a ranking of opinions, questions or other editorial types.'),
'threads-visual':dict(label='Try a visual',kind='Engagement signal',publisher='Buffer',date='2026-03-19',url='https://buffer.com/resources/data-best-content-format-social-media/',finding='Threads video had 5.55% median engagement, compared with 2.79% for text in the dataset.',sample='Buffer-published posts; underlying data through Dec 3, 2025.',limit='Not proof that every visual performs better; editorial pairing is a separate design suggestion.'),
'fb-mix':dict(label='A close format race',kind='Engagement signal',publisher='Buffer',date='2026-03-19',url='https://buffer.com/resources/data-best-content-format-social-media/',finding='Facebook image, video and text median engagement rates were within one percentage point of each other.',sample='Buffer-published posts; underlying data through Dec 3, 2025.',limit='No decisive universal winner. Fit the format to the idea, then test your own audience.'),
}
def evidence(native,plats):
 ids=[]
 if native=='carousel' and 'instagram' in plats:ids+=['ig-saves','ig-usage']
 if native=='document' and 'linkedin' in plats:ids+=['li-docs']
 if native=='image_caption' and 'linkedin' in plats:ids+=['li-usage']
 if native=='short_vertical_video' and 'instagram' in plats:ids+=['ig-reach']
 if native=='text' and 'x' in plats:ids+=['x-text']
 if native in ['image_caption','short_vertical_video','long_video'] and 'threads' in plats:ids+=['threads-visual']
 if native in ['text','image_caption','short_vertical_video','long_video'] and 'facebook' in plats:ids+=['fb-mix']
 return ids
pairs=[]
for editorial,rows in P.items():
 for j,(native,platforms,why) in enumerate(rows):
  plats=platforms.split();pairs.append(dict(id=f'{editorial}-{native}',editorial=editorial,native=native,platforms=plats,why=why,evidence=evidence(native,plats),kind='fit_suggestion',surface_note='Planning fit only. Account, app surface and publishing/API support are not verified.'))
for native,(ed,plats,why) in extra.items():
 pairs.append(dict(id=f'{ed}-{native}',editorial=ed,native=native,platforms=plats.split(),why=why,evidence=[],kind='fit_suggestion',surface_note='Specialist or conditional surface. Check availability before use.'))
L={'version':'7.0.0','reviewed_at':'2026-09-22','categories':{},'items':{},'evidence':E,'platforms':[{'id':i,'label':n} for i,n in [('instagram','Instagram'),('linkedin','LinkedIn'),('threads','Threads'),('x','X'),('facebook','Facebook'),('red','Xiaohongshu')]],'pairings':pairs}
category_lookup={}
for dim,cats in [('editorial',cats_e),('native',cats_n)]:
 L['categories'][dim]=[]
 for id,label,desc,items in cats:
  L['categories'][dim].append(dict(id=id,label=label,description=desc))
  for item in items.split():category_lookup[item]=id
mini={};large={}
for i,item in enumerate(T['items']):
 id=item['id'];base,accent=IC[id]
 svg=f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" role="img" aria-label="{item["title"].replace("&","&amp;")}" class="mini-glyph">{base}<g class="glyph-motion">{accent}</g></svg>'
 path=f'assets/glyphs/{id}.svg';(SRC/path).parent.mkdir(parents=True,exist_ok=True);(SRC/path).write_text(svg)
 mini[id]=svg
 big=(SRC/item['thumbnail_asset_path']).read_text();large[id]=big
 group=category_lookup[id];route=[p for p in pairs if p['editorial' if item['dimension']=='editorial' else 'native']==id]
 assert route,id
 L['items'][id]=dict(category=group,tags=['editorial' if item['dimension']=='editorial' else 'format',group],platforms=sorted(set(p for r in route for p in r['platforms'])),pairings=route,compact_thumbnail=dict(thumbnail_id=f'rafii-glyph-{id}-v7',thumbnail_kind='svg',thumbnail_asset_path=path,alt_text=f'{item["title"]}: {item["description"]}',aspect_ratio='1:1',visual_concept=f'Distilled {item["title"].lower()} pictogram with a separate animated accent.',source_type='original_deterministic_svg',content_hash='sha256:'+hashlib.sha256(svg.encode()).hexdigest(),version='7.0.0'))
(SRC/'library-data.json').write_text(json.dumps(L,ensure_ascii=False,indent=2))
# Keep local vectors as strings, not remote image URLs. Inline renderer namespaces SVG ids.
js='/* Original v7 categories, curation and vectors. See EXECUTION-PLAN.md and research notes. */\n(function(root){const data='+json.dumps(L,ensure_ascii=False,separators=(',',':'))+';data.mini='+json.dumps(mini,ensure_ascii=False,separators=(',',':'))+';data.art='+json.dumps(large,ensure_ascii=False,separators=(',',':'))+';if(typeof module==="object"&&module.exports)module.exports=data;else root.RafiiLibrary=data;})(globalThis);'
(SRC/'library-data.js').write_text(js)
print('Built',len(L['items']),'glyphs;',len(pairs),'pairings;',len(E),'evidence records')
