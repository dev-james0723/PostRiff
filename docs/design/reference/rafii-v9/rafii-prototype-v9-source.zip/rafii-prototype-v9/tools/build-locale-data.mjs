// UI projection of scripts/build_locale_catalogue.mjs from dev-james0723/PostRiff
// commit 468811b73d28b4389f931519827c05d0e6c8abfb. Same TUNED / REGIONLESS / ISO /
// REGIONAL_EXTRA seed sets. Backend prompts/guides are not included in this offline UI.
// ICU-derived labels are frozen at build time, not calculated by the user's browser.
import {writeFileSync} from 'node:fs';
const tuned=`zh-Hant-HK|zh|繁體中文（香港）|Chinese — Traditional (Hong Kong)|hong kong,hk,香港,港,繁體,繁体,traditional,書面語,书面语,written chinese,macau,澳門,澳门,港式中文,香港中文
 yue-Hant-HK|zh|廣東話（香港）|Cantonese (Hong Kong)|cantonese,canto,廣東話,广东话,粵語,粤语,廣府話,港式,口語,口语,hong kong,hk,香港,繁體,繁体,zh-yue
 zh-Hant-TW|zh|繁體中文（台灣）|Chinese — Traditional (Taiwan)|taiwan,tw,台灣,臺灣,台湾,國語,国语,華語,mandarin,繁體,繁体,traditional,正體,正体,台灣中文
 zh-Hans-CN|zh|简体中文（中国）|Chinese — Simplified (China)|mainland,china,cn,prc,中国,中國,大陆,大陸,中国大陆,中國大陸,内地,內地,普通话,普通話,mandarin,putonghua,简体,簡體,simplified
 zh-Hans-SG|zh|简体中文（新加坡）|Chinese — Simplified (Singapore)|singapore,sg,新加坡,华文,華文,malaysia,马来西亚,馬來西亞,简体,simplified
 en-US|en|English (US)|English (United States)|american,usa,us,united states,america,美式英文,美國英文,美国英文
 en-GB|en|English (UK)|English (United Kingdom)|british,uk,britain,england,gb,united kingdom,英式英文,英國英文,英国英文
 en-GB-scotland|en|English (Scotland)|Scottish English|scottish,scotland,scots english,alba
 en-IE|en|English (Ireland)|Irish English|irish,ireland,eire,éire
 en-AU|en|English (Australia)|Australian English|australian,aussie,australia,oz
 en-NZ|en|English (New Zealand)|New Zealand English|kiwi,nz,new zealand,aotearoa
 en-CA|en|English (Canada)|Canadian English|canadian,canada
 en-IN|en|English (India)|Indian English|indian,india
 en-SG|en|English (Singapore)|Singapore English|singapore,singlish,sg
 es-ES|es|Español (España)|Spanish (Spain)|castellano,castilian,spain,espana,españa,european spanish
 es-MX|es|Español (México)|Spanish (Mexico)|mexican,mexicano,mexico,méxico,latino
 es-AR|es|Español (Argentina)|Spanish (Argentina)|argentine,argentino,argentina,rioplatense,uruguay,voseo
 es-CO|es|Español (Colombia)|Spanish (Colombia)|colombian,colombiano,colombia
 es-US|es|Español (Estados Unidos)|Spanish (United States)|us spanish,hispanic,latino,spanglish
 es-419|es|Español (Latinoamérica)|Spanish (Latin America)|latam,latin american,latinoamericano,latinoamerica,latinoamérica,neutral spanish
 pt-BR|pt|Português (Brasil)|Portuguese (Brazil)|brazilian,brasileiro,brasil,brazil,br
 pt-PT|pt|Português (Portugal)|Portuguese (Portugal)|european portuguese,portugal
 fr-FR|fr|Français (France)|French (France)|francais,français,france
 fr-CA|fr|Français (Canada)|French (Canada)|quebecois,québécois,quebec,québec,canadian french
 de-DE|de|Deutsch (Deutschland)|German (Germany)|deutsch,germany,deutschland
 de-AT|de|Deutsch (Österreich)|German (Austria)|austrian,osterreich,österreich,austria
 de-CH|de|Deutsch (Schweiz)|German (Switzerland)|swiss german,schweizerdeutsch,swiss,schweiz,suisse
 it-IT|eu|Italiano|Italian|italiano,italy,italia
 nl-NL|eu|Nederlands|Dutch (Netherlands)|dutch,nederlands,holland,netherlands
 pl-PL|eu|Polski|Polish|polish,polska,poland
 tr-TR|eu|Türkçe|Turkish|turkish,turkce,türkiye,turkiye,turkey
 ru-RU|eu|Русский|Russian|russian,russkiy,russia,россия
 uk-UA|eu|Українська|Ukrainian|ukrainian,ukrainska,ukraine,україна
 ja-JP|as|日本語|Japanese|japanese,nihongo,日文,日語,日语,japan,日本,jp
 ko-KR|as|한국어|Korean|korean,hangugeo,韓文,韩文,韓語,korea,한국
 th-TH|as|ไทย|Thai|thai,thailand,ภาษาไทย,泰文
 vi-VN|as|Tiếng Việt|Vietnamese|vietnamese,tieng viet,vietnam,viet nam,越南文
 id-ID|as|Bahasa Indonesia|Indonesian|indonesian,indonesia,bahasa
 ms-MY|as|Bahasa Melayu|Malay (Malaysia)|malay,melayu,malaysia,bahasa malaysia,马来文,馬來文
 fil-PH|as|Filipino|Filipino|tagalog,taglish,pilipinas,philippines,pinoy,tl
 hi-IN|sa|हिन्दी|Hindi|hindi,हिंदी,india,bharat
 hi-Latn-IN|sa|Hinglish|Hindi in Roman script (Hinglish)|hinglish,roman hindi,romanized hindi,hindi latin
 bn-IN|sa|বাংলা (ভারত)|Bengali (India)|bengali,bangla,west bengal,kolkata,বাংলা
 bn-BD|sa|বাংলা (বাংলাদেশ)|Bengali (Bangladesh)|bangladesh,bangladeshi,bengali,bangla,dhaka,বাংলাদেশ
 ta-IN|sa|தமிழ்|Tamil|tamil,tanglish,tamil nadu,தமிழ்
 te-IN|sa|తెలుగు|Telugu|telugu,తెలుగు
 mr-IN|sa|मराठी|Marathi|marathi,मराठी
 ur-PK|sa|اردو|Urdu|urdu,pakistan,roman urdu,اردو
 ar-001|me|العربية الفصحى|Arabic (Modern Standard)|arabic,msa,fusha,فصحى,arabi,العربية
 ar-EG|me|العربية (مصر)|Arabic (Egypt)|egyptian,masri,مصري,egypt
 ar-SA|me|العربية (السعودية)|Arabic (Saudi Arabia)|saudi,gulf,khaleeji,خليجي,uae,emirati
 ar-LB|me|العربية (لبنان)|Arabic (Lebanon)|lebanese,levantine,shami,شامي,syria,jordan,palestine
 ar-MA|me|العربية (المغرب)|Arabic (Morocco)|darija,الدارجة,moroccan,maghreb,algeria,tunisia
 he-IL|me|עברית|Hebrew|hebrew,ivrit,israel,עברית
 fa-IR|me|فارسی|Persian|persian,farsi,iran,parsi,فارسی`;
const regionless=`en|en|English|English|english,英文,英語,英语
zh-Hant|zh|繁體中文|Traditional Chinese|traditional chinese,繁體,繁体,繁中,正體,chinese,中文
zh-Hans|zh|简体中文|Simplified Chinese|simplified chinese,简体,簡體,简中
es|es|Español|Spanish|spanish,espanol,西班牙文
pt|pt|Português|Portuguese|portuguese,portugues
fr|fr|Français|French|french,francais,法文
de|de|Deutsch|German|german,deutsch,德文
ar|me|العربية|Arabic|arabic,عربي`;
const extra=[['zh-Hant-MO','zh'],['en-HK','en'],['en-PH','en'],['en-ZA','en'],['en-NG','en'],['es-CL','es'],['es-PE','es'],['es-VE','es'],['pt-AO','pt'],['pt-MZ','pt'],['fr-BE','fr'],['fr-CH','fr'],['nl-BE','eu'],['it-CH','eu'],['ar-AE','me'],['ar-JO','me'],['ar-DZ','me'],['ar-TN','me'],['ta-LK','sa'],['ta-SG','sa'],['ms-SG','as']];
const ISO='af am as az be bg bo br bs ca ce co cs cy da dv dz ee el eo et eu ff fi fo fy ga gd gl gn gu gv ha haw hr ht hu hy ia ig is iu jv ka kk kl km kn ks ku ky la lb lg ln lo lt lv mg mi mk ml mn mt my nb ne nn oc om or os pa ps qu rm rn ro rw sa sc sd se si sk sl sm sn so sq sr st su sv sw tg ti tk tn to ts tt ug uz wo xh yi yo zu ceb hmn chr'.split(' ');
const rtl=new Set(['ar','fa','ur','he','ps','sd','ug','yi','dv','ckb']);
const families=[['zh','Chinese','中文'],['en','English',''],['es','Spanish','Español'],['pt','Portuguese','Português'],['fr','French','Français'],['de','German','Deutsch'],['eu','More of Europe',''],['as','East & Southeast Asia',''],['sa','South Asia',''],['me','Arabic, Hebrew & Persian',''],['more','More languages','']].map(([id,label,native])=>({id,label,native}));
function flagFor(tag){if(tag.endsWith('scotland'))return String.fromCodePoint(0x1F3F4,0xE0067,0xE0062,0xE0073,0xE0063,0xE0074,0xE007F);const region=tag.split('-').slice(1).find(x=>/^[A-Z]{2}$|^[0-9]{3}$/.test(x));if(!region)return '🌐';if(region==='419')return '🌎';if(/^\d/.test(region))return '🌍';return String.fromCodePoint(...[...region].map(x=>0x1f1e6+x.charCodeAt(0)-65));}
function make(tag,family,native,english,aliases='',regionless=false){return {id:tag.toLowerCase(),tag,family,native,english,label:native,short:native,flag:flagFor(tag),aliases:aliases.split(',').filter(Boolean),regionless,dir:rtl.has(tag.split('-')[0])?'rtl':'ltr'};}
const entries=tuned.split('\n').map(x=>make(...x.trim().split('|')));
entries.push(...regionless.split('\n').map(x=>make(...x.trim().split('|'),true)));
const en=new Intl.DisplayNames(['en'],{type:'language',fallback:'none'}),reg=new Intl.DisplayNames(['en'],{type:'region',style:'short',fallback:'none'});
const capitalise=s=>s&&/^[\p{Script=Latin}\p{Script=Greek}\p{Script=Cyrillic}\p{Script=Armenian}]/u.test(s)?s.charAt(0).toLocaleUpperCase()+s.slice(1):s;
for(const [tag,family] of extra){const base=tag.split('-')[0],region=tag.split('-').at(-1);let english=`${en.of(base)} (${reg.of(region)})`,native=english;try{native=`${capitalise(new Intl.DisplayNames([tag],{type:'language',fallback:'none'}).of(base))} (${new Intl.DisplayNames([tag],{type:'region',style:'short',fallback:'none'}).of(region)})`;}catch{}if(tag==='zh-Hant-MO'){native='繁體中文（澳門）';english='Chinese — Traditional (Macao)';}entries.push(make(tag,family,native,english,[reg.of(region),region].join(',')));}
const bases=new Set(entries.map(e=>e.tag.split('-')[0]));const more=[];
for(const code of ISO){if(bases.has(code))continue;const english=en.of(code);if(!english||english===code)continue;let native=english;try{native=capitalise(new Intl.DisplayNames([code],{type:'language',fallback:'none'}).of(code))||english;}catch{}more.push(make(code,'more',native,english,english.toLowerCase(),true));}
more.sort((a,b)=>a.english.localeCompare(b.english,'en'));entries.push(...more);
const data={version:'2026-09-16.1',sourceCommit:'468811b73d28b4389f931519827c05d0e6c8abfb',buildICU:process.versions.icu,buildCLDR:process.versions.cldr,families,entries};
writeFileSync(new URL('../src/locale-data.json',import.meta.url),JSON.stringify(data,null,2)+'\n');
writeFileSync(new URL('../src/locale-data.js',import.meta.url),'/* Frozen UI projection of the project locale seed catalogue. See PROVENANCE.md. */\n(function(root){const data='+JSON.stringify(data)+';if(typeof module==="object"&&module.exports)module.exports=data;else root.RafiiLocaleData=data;})(globalThis);\n');
console.log(`${entries.length} entries; ${tuned.split('\n').length} curated; ${extra.length} regional extras; ${more.length} more; ICU ${process.versions.icu}`);
