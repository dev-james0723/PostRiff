from pathlib import Path
from playwright.sync_api import sync_playwright,expect
from PIL import Image,ImageDraw,ImageFont
R=Path(__file__).resolve().parents[1];O=R/'previews-v7'
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 pg=b.new_page(viewport={'width':430,'height':932},device_scale_factor=1)
 pg.set_content((R/'index.html').read_text());pg.locator('#format-trigger').click();pg.wait_for_timeout(700)
 pg.screenshot(path=str(O/'final-gallery.png'))
 pg.locator('[data-library-view="list"]').click();expect(pg.locator('.library-outgoing')).to_have_count(0);pg.screenshot(path=str(O/'final-list.png'))
 pg.locator('#taxonomy-search').fill('how-to');pg.locator('[data-library-view="pairings"]').click();expect(pg.locator('.library-outgoing')).to_have_count(0)
 pg.locator('#taxonomy-panel').evaluate('e=>e.scrollTop=155');pg.wait_for_timeout(300);pg.screenshot(path=str(O/'final-pairings.png'))
 pg.close();b.close()
font='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf';bold='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
canvas=Image.new('RGB',(1420,1145),'#111111');d=ImageDraw.Draw(canvas)
d.text((45,32),'rafii.',font=ImageFont.truetype(bold,44),fill='#f0f0ec')
d.text((1130,53),'CONTENT LIBRARY / V7',font=ImageFont.truetype(font,14),fill='#aaaaaa')
for idx,(name,title) in enumerate([('gallery','01 / GALLERY'),('list','02 / LIST'),('pairings','03 / PAIRINGS')]):
 x=40+idx*455;d.text((x,112),title,font=ImageFont.truetype(font,17),fill='#d7d7d2');im=Image.open(O/f'final-{name}.png').convert('RGB');canvas.paste(im,(x,155))
d.text((46,1105),'Actual screenshots from the working HTML. Tap, filter, compare and apply. No concept-image rendering.',font=ImageFont.truetype(font,13),fill='#aaaaaa')
canvas.save(R.parent/'rafii-prototype-v7-preview.png')
print('Preview built.')
