# Rafii v7 execution plan

## 目標與邊界
沿用 v6 離線 HTML，改良 Content Library。保留 model、reasoning、language、手機 swipe/crossfade、放大寫作及草稿。今版不接 API、不部署、不修改 james-au-studio production repo。

## 1. 分類與資料
31 個 editorial types 分成七組：Everyday、News & events、Teach & explain、Conversations、Showcase & proof、Products & offers、Community。20 個 native formats 按文字、視覺、影片／直播、互動、音訊、社群、商務分組。每項只有一個主分類，可另帶語意 tags，避免重複清單。分類、搜尋和 app fit filter 可以同時使用；零結果有 Clear filters。

Editorial = 講甚麼；Native = 如何呈現；Channels = 發佈目的地。三者不可合併，也不可因為篩選 app 就變更已選發佈 channel。

## 2. 三種視圖
- Gallery：保留 v6 大型語意插畫，加分類和小型平台適配標記。
- List：獨立設計的 48×48 SVG pictogram、名稱、editorial/everyday 等 tags，以及獨立圓形 i button。圖片永遠可见，不藏進 tooltip。
- Pairings：把每個內容類型連到建議 native format 和 social app，附用途、來源／證據等級。按 Use pairing 只設定 editorial + native，不更動渠道；最後 Use these choices 才套用到主頁。

全域 view 選擇在 editorial/native 切換時保留；每個維度保留各自 category；app fit filter 共用；已選項即使被 filter 隱藏仍顯示於底部 selection tray。搜尋在視圖切換時保留；切換 editorial/native 會清除搜尋，以免另一維度被舊字詞意外遮蔽。已選內容不丟失。

## 3. 建議與熱門資訊
平台適合度是 Rafii 設計建議，不是 API 支援矩陣。數據只提供 format-level 證據，不虛構 31 種 editorial 的熱門榜。
三種明確標記：Fit suggestion、Engagement signal、Usage signal。每個研究記錄 publisher、URL、發布時間、樣本／期間、metric 和限制。關聯性不代表因果，engagement 不等於最多人發佈。小紅書不提供未查證的熱門數字；僅提供有清楚標示的內容編排建議。

核心研究：Buffer 2026 format/engagement reports（其平台及時窗依原報告）；Metricool 2026 Instagram（24,364,803 posts, 375,118 accounts, Jan–Feb 2025 vs Jan–Feb 2026）；Metricool LinkedIn 2026（673,658 posts, 63,108 accounts，同期比較）。LinkedIn 文件／PDF 不偷換成 Instagram image carousel。

## 4. 全部 51 個 compact pictograms
每項各有新的本地 SVG，語意和大圖一致但重新簡化，不能只縮小含細字的大圖。metadata 包含 id、kind、local path、alt、aspect ratio、concept、source、SHA256 和 version。大圖保留舊素材；兩種尺寸都有 subtle internal motion。無 CDN、無 remote images、無新 blank fallback。

## 5. 動畫與可及性
View/category switching：舊/新內容短 crossfade + 8px 位移，約 280–360ms；只有一層可互動，快速切換最後操作勝出。Tooltip：click/tap 或鍵盤聚焦 i 後按 Enter/Space 可開啟，opacity + 4px transform，約 180ms；Escape、再按 i 或外點收起。Tooltip 顯示純描述，不把按鈕放入 tooltip；sources 用獨立可操作 details panel。

SVG 動畫：小幅光度／位移／線段變化，約 4–6s；offscreen 和 hidden tab 暫停，有 Pause artwork，尊重 prefers-reduced-motion。禁止一整排卡牌不停跳動。

## 6. 執行次序
先寫分類、圖示與 UI 行為測試並確認缺項會失敗 → 新增離線 data + compact SVG → 替換 taxonomy renderer → 加 filter、三視圖和 tooltip → 加研究 evidence panel → 檢查 v6 回歸 → 逐尺寸截圖與修正 → 打包 HTML、source ZIP、驗證報告。

## 驗收
51 項全部可在 Gallery/List/Pairings 找到；同一項有一致 tags/選擇，i 不誤選卡片；所有縮圖存在且 hash 正確；單鍵 Escape 優先關 tooltip；Apply/Cancel 正確；手機一欄、桌面 Gallery 兩欄；長文字、no-results、dark/light、鍵盤 focus、reduced motion、快速 view switching 無溢出；既有模型/語言/手機 swipe 可用。Browser 截圖是 working HTML，不是生成概念圖。實體 iOS 未測必須如實標明。
