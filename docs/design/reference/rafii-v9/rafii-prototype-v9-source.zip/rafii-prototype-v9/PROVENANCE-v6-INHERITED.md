# v6 source provenance

## Base

This version modifies a separate copy of the supplied v5 source package. See `PROVENANCE-v5-INHERITED.md` and `PROVENANCE-v4-INHERITED.md` for the earlier repo-derived phone templates, locale catalogue reconstruction and scope boundaries. No new claim is made about the current James-Au-Studio laptop checkout or live website. The existing 196 language/region entries and phone/swap input behaviour are inherited rather than re-fetched.

## Original v6 work

The 31 editorial-type and 20 native-format illustrations are original deterministic SVG compositions written for this prototype. They use local geometric shapes, papers, frames, diagrams, timelines and typography. They do not copy artwork, assets or text from the visual reference. There are no remote image URLs or raster stock photographs. Every new item has a distinct image and SHA-256 hash.

`tools/build_taxonomy.py` generates the local assets and metadata. `content_hash` is computed from exact SVG bytes. The explicit legacy-fallback drawing is separate from the 51 new items. No font binaries are included; text uses system fonts.

The model crossfade, moving reasoning lens and measured shared-language expansion are original local browser/CSS implementations. They do not rely on Rive, a CDN or an external animation service.

## Provider marks

OpenAI, Claude, Grok and Gemini mark geometry is reproduced from the Lobe Icons project's mono SVG components, read through the connected GitHub tools. This is an independently maintained icon library, **not a claim of direct official-vendor asset downloads or endorsement**.

- OpenAI: `src/OpenAI/components/Mono.tsx`, blob `cec37c595dadac9be007f17c5b038eda4283efd1`.
- Claude: `src/Claude/components/Mono.tsx`, blob `29c171b0826c5ce4cf78d7376e841b63b129a9ba`.
- Grok: `src/Grok/components/Mono.tsx`, blob `2403b75bfacf734851b0b252f3b76706bcbab2ef`.
- Gemini: `src/Gemini/components/Mono.tsx`, blob `672a381a27a00895ece2aa90755828df299cd7d5`.

Repository: https://github.com/lobehub/lobe-icons

Exact paths, source URLs, local hashes and wrapper changes are recorded in `src/assets/brands/brands.json`. Path geometry is unchanged; React-specific wrappers were removed and the theme is applied through `currentColor`. The original MIT notice is included in `src/assets/brands/LICENSE.txt`. Brand names and marks remain the property of their respective owners. CLI uses a generic terminal glyph, not a claimed vendor logo.

## Simulation boundary

Model labels and badges remain inherited demonstration data, not a current verified model catalogue. Reasoning intensity is an app-level preference. Native-format choices are concepts and do not imply the capability exists on every platform. All local templates, language limitations and draft-preview disclaimers remain explicit. No AI or CLI commands are executed and nothing is published.
