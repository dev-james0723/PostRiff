# Rafii v8 validation

## Result

**149 automated tests passed.** All six retained browser suites and the new 10-test toolbar suite completed with exit code 0. The 39 local core/data/asset contract tests passed. Logs are in `tests/v8/`.

**120 responsive checks passed:** 96 content-library states (8 screen sizes × light/dark × editorial/native × gallery/list/pairings), 16 filter-panel states, and 8 per-page runtime/network checks. No observed horizontal overflow or JavaScript errors. The prototype made no network requests in that audit.

HTML SHA256: `7266e550f2ff83deb68d11bcc8cd7f00689da07da8e7c248b026c39d4ee20d20`

## Scope and actual commands

`python build.py`, `node --check src/app.js`, `node --test tests/*.cjs tests/v5/*.cjs tests/v6/*.cjs tests/v7/*.cjs`, `python tests/v8/test_toolbar.py`, `python tests/v8/run_regressions.py` and `python tests/v8/layout_audit.py`.

The new tests first ran against v7: eight failures showed missing control grouping and insufficient content space; two retained behavior checks passed. The completed v8 build passed all ten. An initial inherited-v7-suite command was interrupted by a tool timeout; its partial log is not counted. A fresh full rerun subsequently passed all sixteen inherited library tests.

Retained v7 tests now explicitly open the Filters panel before using the moved category/app/motion/research controls. Their behavioral assertions remain: filtering never changes selected destinations, selection survives view switches, tooltips do not select content, pairings work, and artwork can be paused.

## Layout

Checked viewport sizes: 320×740, 375×812, 390×844, 430×932, 768×1024, 1024×768, 1440×1000, 1920×1080.

At 390×844, v7 had a 345.8px header and a 145.8px footer. V8 has a 253.7px header and a 107px footer. The scrollable content area grew from 340.5px to 449.5px. Measurements are in `tests/v8/geometry.json`. This compares the same default editorial gallery with no active filters, not a real-device browser recording.

The main view and Filters controls have matched heights of at least 44px. Category and app-fit selects are 48px tall and use 16px text. Active filters have a visible count/summary with a Clear action. Long selections wrap in the footer instead of disappearing. Keyboard outlines remain visible.

## Visual evidence

Actual browser screenshots in `previews-v8/` cover mobile, small phone, desktop, Gallery, List, Pairings, Filters, light mode and an animated information tooltip. Mobile/desktop galleries and the mobile Filters panel were visually inspected. `rafii-prototype-v8-preview.png` combines unchanged before/after browser captures, not generated interface artwork.

Category/app settings and labelled artwork controls are available in the panel rather than permanently displayed in unrelated rows. The footer has one primary action with a compact two-part selection summary. Fit limitations and research remain accessible inside Filters and from pairing evidence links.

## Preserved behavior

Retained suites passed for the original composer/source/queue flow, light/dark theme, phone previews, rapid crossfades, touch swipe, independent/shared languages, model provider transitions, reasoning controls, expanded writing, all 51 taxonomy items and thumbnail contracts.

## Limits

Tested with Linux Chromium and Playwright using the bundled offline HTML. No physical iPhone/Safari, Firefox, screen-reader audit, real GPU/battery/performance measurement, production deployment, API/CLI, translation, social publishing or new benchmark research was performed. Layout checks and screenshots are not a full WCAG conformance assessment. Research and model catalogues are inherited from v7, not reverified current data.
