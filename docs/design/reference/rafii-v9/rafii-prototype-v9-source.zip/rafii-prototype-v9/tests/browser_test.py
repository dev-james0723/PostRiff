"""Inherited black-box tests. v4 routes voice via its independent Voice button.
No business-behaviour assertions were removed. Run with Python + Playwright Chromium.
"""
import os, unittest, shutil
from pathlib import Path
from playwright.sync_api import sync_playwright, expect
TARGET=Path(os.environ.get('RAFII_HTML',str(Path(__file__).resolve().parents[1]/'index.html')))

class PrototypeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.p=sync_playwright().start()
        cls.browser=cls.p.chromium.launch(executable_path=os.environ.get('CHROMIUM_BIN') or shutil.which('chromium') or shutil.which('chromium-browser'),headless=True,args=['--no-sandbox'])
    @classmethod
    def tearDownClass(cls):
        cls.browser.close(); cls.p.stop()
    def setUp(self):
        self.context=self.browser.new_context(viewport={'width':1440,'height':1000},reduced_motion='reduce')
        self.page=self.context.new_page(); self.errors=[]
        self.page.on('pageerror',lambda e:self.errors.append(str(e)))
        self.page.set_content(TARGET.read_text() if TARGET.exists() else '<!doctype html><title>Unbuilt prototype</title>', wait_until='load')
        self.page.evaluate('() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)))')
    def tearDown(self):
        self.context.close()
        self.assertEqual(self.errors,[],'Uncaught browser exceptions')
    def channel_panel(self): self.page.locator('#channels-trigger').click()
    def generate(self):
        self.page.locator('#idea').fill('A tiny habit can change a creative practice.')
        self.page.locator('#generate').click()
        expect(self.page.locator('#generation-status')).to_contain_text('ready',timeout=10000)
    def test_home_is_a_real_interactive_composer(self):
        expect(self.page.locator('#idea')).to_be_visible(timeout=800)
        expect(self.page.locator('#channels-count')).to_have_text('3')
        expect(self.page.locator('#generate')).to_be_disabled()
    def test_channel_change_applies_only_on_done(self):
        self.channel_panel(); self.page.locator('[data-channel="x"]').click()
        expect(self.page.locator('#channel-done')).to_contain_text('4')
        self.page.keyboard.press('Escape')
        expect(self.page.locator('#channels-count')).to_have_text('3')
        self.channel_panel(); self.page.locator('[data-channel="x"]').click(); self.page.locator('#channel-done').click()
        expect(self.page.locator('#channels-count')).to_have_text('4')
        expect(self.page.locator('#channel-stack .overflow')).to_have_text('+1')
    def test_zero_channels_disables_generation(self):
        self.page.locator('#idea').fill('Some idea')
        self.channel_panel(); self.page.locator('#clear-channels').click(); self.page.locator('#channel-done').click()
        expect(self.page.locator('#generate')).to_be_disabled()
        expect(self.page.locator('#channels-count')).to_have_text('0')
    def test_search_does_not_lose_selected_channels(self):
        self.channel_panel(); self.page.locator('#channel-search').fill('Linked')
        expect(self.page.locator('.channel-tile:visible')).to_have_count(1)
        self.page.locator('#channel-search').fill('')
        expect(self.page.locator('#channel-done')).to_contain_text('3')
    def test_format_deck_changes_format(self):
        self.page.locator('#format-trigger').click(); self.page.locator('[data-taxonomy-tab="native"]').click(); self.page.locator('[data-taxonomy-item="carousel"]').click(); self.page.locator('#apply-taxonomy').click()
        expect(self.page.locator('#format-label')).to_contain_text('Carousel')
        expect(self.page.locator('dialog[open]')).to_have_count(0)
    def test_voice_cancel_and_apply(self):
        self.page.locator('#voice-trigger').click(); self.page.locator('[data-tone="bold"]').click()
        self.page.keyboard.press('Escape'); expect(self.page.locator('#voice-summary')).to_contain_text('Neutral')
        self.page.locator('#voice-trigger').click(); self.page.locator('[data-tone="warm"]').click(); self.page.locator('#save-tune').click()
        expect(self.page.locator('#voice-summary')).to_contain_text('Warm')
    def test_source_permission_is_not_preapproved(self):
        self.page.locator('#context-trigger').click()
        expect(self.page.locator('.quote-permission:checked')).to_have_count(0)
        self.page.locator('#source-note').fill('<script>window.pwned=true</script>')
        self.page.locator('#add-note').click(); expect(self.page.locator('.source-row')).to_have_count(3)
        self.assertIsNone(self.page.evaluate('window.pwned'))
        expect(self.page.locator('.quote-permission:checked')).to_have_count(0)
    def test_generation_is_explicitly_simulated_and_editable(self):
        self.generate(); expect(self.page.locator('#preview-disclaimer')).to_contain_text('No AI')
        expect(self.page.locator('#draft-editor')).to_have_value(__import__('re').compile('.*A tiny habit.*',__import__('re').S))
        self.page.locator('#draft-editor').fill('An edited draft.')
        self.page.locator('#save-draft').click()
        self.page.locator('[data-view="queue"]').first.click()
        expect(self.page.locator('#queue-view')).to_contain_text('An edited draft.')
        expect(self.page.locator('#queue-view')).to_contain_text('Not scheduled')
    def test_html_in_idea_is_not_executed_in_preview(self):
        self.page.locator('#idea').fill('<img src=x onerror="window.pwned=true">')
        self.page.locator('#generate').click()
        expect(self.page.locator('#generation-status')).to_contain_text('ready',timeout=10000)
        self.assertIsNone(self.page.evaluate('window.pwned'))
        expect(self.page.locator('#draft-editor')).to_have_value(__import__('re').compile('.*<img.*',__import__('re').S))
        # v6 has legitimate local taxonomy thumbnails; injected markup must not appear.
        expect(self.page.locator('#results img[src="x"], #results [onerror]')).to_have_count(0)
        self.assertTrue(all(url.startswith('data:image/svg+xml;base64,') for url in self.page.locator('#results img').evaluate_all('es=>es.map(e=>e.src)')))
    def test_error_can_be_retried(self):
        self.page.locator('#demo-controls').click(); self.page.locator('#simulate-error').check()
        self.page.locator('#close-controls').click()
        self.page.locator('#idea').fill('An idea to test recovery'); self.page.locator('#generate').click()
        expect(self.page.locator('#generation-status')).to_contain_text('needs a retry',timeout=10000)
        self.page.locator('.draft-tab[data-status="error"]').click(); self.page.locator('#retry-draft').click()
        expect(self.page.locator('#generation-status')).to_contain_text('3 of 3 ready',timeout=10000)
    def test_dialog_escape_returns_focus(self):
        self.channel_panel(); self.page.keyboard.press('Escape')
        expect(self.page.locator('#channels-trigger')).to_be_focused()
    def test_single_panel_at_a_time(self):
        self.channel_panel(); expect(self.page.locator('dialog[open]')).to_have_count(1)
        self.page.keyboard.press('Escape'); self.page.locator('#format-trigger').click()
        expect(self.page.locator('dialog[open]')).to_have_count(1)
    def test_mobile_no_overflow_and_channel_panel_fits(self):
        self.page.set_viewport_size({'width':390,'height':844})
        self.page.wait_for_function("getComputedStyle(document.querySelector('.app-shell')).marginLeft === '0px'")
        self.assertLessEqual(self.page.evaluate('document.documentElement.scrollWidth'),390)
        self.channel_panel()
        box=self.page.locator('#channel-dialog').bounding_box()
        self.assertGreaterEqual(box['x'],0); self.assertLessEqual(box['x']+box['width'],390)
        expect(self.page.locator('#channel-done')).to_be_visible()
    def test_small_mobile_no_overflow(self):
        self.page.set_viewport_size({'width':320,'height':640})
        self.page.wait_for_function("getComputedStyle(document.querySelector('.app-shell')).marginLeft === '0px'")
        self.assertLessEqual(self.page.evaluate('document.documentElement.scrollWidth'),320)
        self.page.locator('#format-trigger').click()
        self.assertLessEqual(self.page.locator('#format-dialog').bounding_box()['width'],320)
    def test_reduced_motion_does_not_disable_controls(self):
        self.assertTrue(self.page.evaluate("matchMedia('(prefers-reduced-motion: reduce)').matches"))
        self.channel_panel(); self.page.locator('[data-channel="x"]').click(); self.page.locator('#channel-done').click()
        expect(self.page.locator('#channels-count')).to_have_text('4')
    def test_reset_clears_session(self):
        self.generate(); self.page.locator('#save-draft').click()
        self.page.locator('#demo-controls').click(); self.page.locator('#reset-demo').click()
        expect(self.page.locator('#idea')).to_have_value('')
        expect(self.page.locator('#channels-count')).to_have_text('3')
        self.page.locator('[data-view="queue"]').first.click()
        expect(self.page.locator('#queue-view')).to_contain_text('No drafts saved yet')

    def test_completed_generation_stops_all_beams(self):
        self.generate()
        expect(self.page.locator('.flow-beam:not([hidden])')).to_have_count(0)
    def test_prototype_makes_no_network_requests(self):
        requests=[]
        self.page.on('request',lambda request:requests.append(request.url))
        self.context.set_offline(True)
        self.generate()
        self.assertEqual(requests,[])
    def test_cancel_discards_pending_job_and_keeps_idea(self):
        self.page.locator('#idea').fill('Keep this thought')
        self.page.locator('#generate').click()
        self.page.locator('#cancel-generation').click()
        self.page.wait_for_timeout(2100)
        expect(self.page.locator('#results')).to_be_hidden()
        expect(self.page.locator('#idea')).to_have_value('Keep this thought')
        expect(self.page.locator('#generate')).to_be_enabled()
    def test_all_six_channels_work_with_compact_mobile_pod(self):
        self.page.set_viewport_size({'width':320,'height':740})
        self.page.wait_for_function("getComputedStyle(document.querySelector('.app-shell')).marginLeft === '0px'")
        self.channel_panel()
        for channel in ['x','facebook','red']:
            self.page.locator(f'[data-channel="{channel}"]').click()
        self.page.locator('#channel-done').click()
        expect(self.page.locator('#channels-count')).to_have_text('6')
        expect(self.page.locator('#channel-stack .overflow')).to_have_text('+3')
        self.assertLessEqual(self.page.evaluate('document.documentElement.scrollWidth'),320)
    def test_upload_wrong_type_gives_error_without_adding_source(self):
        self.page.locator('#context-trigger').click()
        self.page.locator('#source-file').set_input_files({'name':'test.pdf','mimeType':'application/pdf','buffer':b'test'})
        expect(self.page.locator('#source-error')).to_contain_text('Choose a .txt')
        expect(self.page.locator('.source-row')).to_have_count(2)
    def test_new_source_is_local_and_public_quoting_is_off(self):
        self.page.locator('#context-trigger').click()
        self.page.locator('#source-file').set_input_files({'name':'brief.txt','mimeType':'text/plain','buffer':b'This is a local note.'})
        expect(self.page.locator('.source-row')).to_have_count(3)
        expect(self.page.locator('.quote-permission:checked')).to_have_count(0)

if __name__=='__main__': unittest.main(verbosity=2)
