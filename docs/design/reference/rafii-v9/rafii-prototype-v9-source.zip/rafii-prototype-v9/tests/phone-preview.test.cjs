const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const f=path.join(__dirname,'../src/phone-previews.js');
const P=fs.existsSync(f)?require(f):{};
function ready(){assert.equal(typeof P.renderPhone,'function','Repository phone layouts must be implemented');}
test('six repository platform templates are available',()=>{ready();assert.deepEqual(P.channels,['instagram','linkedin','threads','x','facebook','red']);});
test('phone dimensions retain repository logical geometry',()=>{ready();assert.equal(P.screen.width,393);assert.equal(P.screen.height,852);assert.equal(P.screen.statusBar,54);});
test('each preview has the right app identifier, not a generic card',()=>{ready();for(const id of P.channels){const html=P.renderPhone({channel:id,text:'My idea'});assert.ok(html.includes('data-native-platform="'+id+'"'));assert.ok(html.includes('device-island'));assert.ok(html.includes('My idea'));}});
test('six layouts preserve their distinctive chrome',()=>{ready();const render=id=>P.renderPhone({channel:id,text:'Some idea'});assert.match(render('instagram'),/Instagram/);assert.match(render('linkedin'),/My Network/);assert.match(render('threads'),/For you/);assert.match(render('x'),/Following/);assert.match(render('facebook'),/Marketplace/);assert.match(render('red'),/说点什么/);});
test('user text cannot become active HTML in a preview',()=>{ready();const html=P.renderPhone({channel:'threads',text:'<img src=x onerror=alert(1)><script>evil()</script>'});assert.ok(!html.includes('<img src=x'));assert.ok(html.includes('&lt;img'));assert.ok(!html.includes('<script>'));});
test('text-only Instagram shows missing media instead of invented asset',()=>{ready();assert.match(P.renderPhone({channel:'instagram',text:'No photo',artwork:false}),/photo or video/);});
test('preview media is explicit artwork and does not fabricate engagement',()=>{ready();for(const id of P.channels){const html=P.renderPhone({channel:id,text:'My idea',artwork:true});assert.match(html,/Sample artwork/);assert.doesNotMatch(html,/(2,847|144 others|321 likes|verified badge)/);}});
test('unknown platform is rejected instead of using Instagram',()=>{ready();assert.throws(()=>P.renderPhone({channel:'bogus',text:'test'}),/Unknown/);});
test('carousel has four distinct visual pages and no executable input',()=>{ready();const a=P.renderPhone({channel:'instagram',format:'carousel',slide:0,text:'Idea',artwork:true});const b=P.renderPhone({channel:'instagram',format:'carousel',slide:1,text:'Idea',artwork:true});assert.notEqual(a,b);assert.match(a,/1 \/ 4/);assert.match(b,/2 \/ 4/);});
test('video script is not presented as an actual rendered video',()=>{ready();assert.match(P.renderPhone({channel:'instagram',format:'video',text:'00:00 Hello',artwork:false}),/script|video/i);});
