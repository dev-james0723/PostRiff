import os,shutil,unittest
from pathlib import Path
from playwright.sync_api import sync_playwright,expect
ROOT=Path(__file__).resolve().parents[2]
TARGET=Path(os.environ.get('RAFII_HTML',ROOT/'index.html'))
class V7Tests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.p=sync_playwright().start();cls.browser=cls.p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox'])
 @classmethod
 def tearDownClass(cls):cls.browser.close();cls.p.stop()
 def setUp(self):
  self.page=self.browser.new_page(viewport={'width':1280,'height':950});self.errors=[];self.page.on('pageerror',lambda e:self.errors.append(str(e)));self.page.set_content(TARGET.read_text());self.page.set_default_timeout(1800);self.page.locator('#format-trigger').click();self.page.wait_for_timeout(620)
 def tearDown(self):
  self.page.close();self.assertEqual(self.errors,[])
 def click(self,s):self.page.locator(s).click();self.page.wait_for_timeout(430);expect(self.page.locator('.library-outgoing')).to_have_count(0,timeout=2200)
 def test_three_views_and_seven_editorial_categories(self):
  self.assertEqual(self.page.locator('[data-library-view]').count(),3);self.assertEqual(self.page.locator('#library-category option').count(),8)
 def test_list_has_31_unique_compact_thumbnails_tags_and_info(self):
  self.click('[data-library-view="list"]');self.assertEqual(self.page.locator('.library-current [data-taxonomy-item]').count(),31);self.assertEqual(self.page.locator('.library-current .info-button').count(),31);self.assertEqual(self.page.locator('.library-current .mini-glyph').count(),31);expect(self.page.locator('[data-taxonomy-item="status_update"]')).to_contain_text('editorial');expect(self.page.locator('[data-taxonomy-item="status_update"]')).to_contain_text('everyday')
 def test_category_filters_dont_change_selection(self):
  self.click('#library-filter-trigger');self.page.locator('#library-category').select_option('education');self.click('#close-library-filters');self.assertEqual(self.page.locator('.library-current [data-taxonomy-item]').count(),6);expect(self.page.locator('#taxonomy-selection')).to_contain_text('Status update')
 def test_info_is_not_selection_escape_only_closes_tooltip(self):
  self.click('[data-library-view="list"]');self.click('[data-info="announcement"]');expect(self.page.locator('#library-tooltip')).to_be_visible();expect(self.page.locator('#library-tooltip')).to_contain_text('important message');expect(self.page.locator('#taxonomy-selection')).to_contain_text('Status update');self.page.keyboard.press('Escape');self.page.wait_for_timeout(220);expect(self.page.locator('#library-tooltip')).not_to_be_visible();expect(self.page.locator('#format-dialog')).to_be_visible()
 def test_view_switch_has_real_outgoing_layer(self):
  self.page.locator('[data-library-view="list"]').click();self.assertEqual(self.page.locator('.library-outgoing').count(),1);expect(self.page.locator('.library-outgoing')).to_have_count(0,timeout=2200)
 def test_platform_filter_is_fit_only_and_leaves_destinations(self):
  before=self.page.locator('#channels-count').inner_text();self.click('#library-filter-trigger');self.page.locator('#library-platform').select_option('red');self.click('#close-library-filters');self.page.wait_for_timeout(430);expect(self.page.locator('.library-outgoing')).to_have_count(0,timeout=2200);self.assertLess(self.page.locator('.library-current [data-taxonomy-item]').count(),31);self.assertEqual(before,self.page.locator('#channels-count').inner_text())
 def test_pairings_use_pair_not_publish_target(self):
  self.click('[data-library-view="pairings"]');self.page.locator('#taxonomy-search').fill('how-to');self.page.wait_for_timeout(430);expect(self.page.locator('.library-outgoing')).to_have_count(0,timeout=2200);self.click('[data-use-pairing="how_to-document"]');expect(self.page.locator('#taxonomy-selection')).to_contain_text('How-to');expect(self.page.locator('#taxonomy-selection')).to_contain_text('Document');self.assertEqual(self.page.locator('#channels-count').inner_text(),'3')
 def test_search_no_results_recovery(self):
  self.page.locator('#taxonomy-search').fill('no-such-taxonomy');expect(self.page.locator('#taxonomy-empty')).to_be_visible();self.click('#clear-library-filters');self.assertEqual(self.page.locator('.library-current [data-taxonomy-item]').count(),31)
 def test_native_has_twenty_icons_in_list_and_pairings(self):
  self.click('[data-library-view="list"]');self.click('[data-taxonomy-tab="native"]');self.assertEqual(self.page.locator('.library-current [data-taxonomy-item]').count(),20);self.assertEqual(self.page.locator('.library-current .mini-glyph').count(),20);self.click('[data-library-view="pairings"]');self.assertEqual(self.page.locator('.library-current [data-taxonomy-item]').count(),20)
 def test_selection_persists_apply_and_cancel(self):
  self.click('[data-library-view="list"]');self.click('[data-taxonomy-item="status_update"]');self.click('[data-taxonomy-tab="native"]');self.click('[data-taxonomy-item="image_caption"]');self.click('#apply-taxonomy');expect(self.page.locator('#format-label')).to_contain_text('Image');self.click('#format-trigger');self.page.locator('#taxonomy-search').fill('launch');self.page.wait_for_timeout(450);self.click('[data-taxonomy-item="launch_release"]');self.click('#format-dialog .close-dialog');expect(self.page.locator('#format-label')).to_contain_text('Status update')
 def test_reduced_motion_and_art_pause(self):
  self.page.emulate_media(reduced_motion='reduce');self.click('[data-library-view="list"]');self.assertEqual(self.page.locator('.mini-glyph .glyph-motion').first.evaluate('e=>getComputedStyle(e).animationName'),'none');self.page.emulate_media(reduced_motion='no-preference');self.click('#library-filter-trigger');self.click('#art-motion-toggle');self.click('#close-library-filters');self.assertEqual(self.page.locator('.mini-glyph .glyph-motion').first.evaluate('e=>getComputedStyle(e).animationPlayState'),'paused')
 def test_list_is_a_compact_horizontal_row(self):
  self.click('[data-library-view="list"]');row=self.page.locator('.library-current .list-card').first;self.assertLessEqual(row.bounding_box()['height'],100);self.assertEqual(row.evaluate('e=>getComputedStyle(e).flexDirection'),'row')
 def test_rapid_view_changes_settle_without_stale_layers(self):
  self.page.evaluate("""async()=>{for(const view of ['list','pairings','gallery','list']){document.querySelector(`[data-library-view="${view}"]`).click();await new Promise(r=>setTimeout(r,35));}}""");expect(self.page.locator('.library-outgoing')).to_have_count(0,timeout=2500);expect(self.page.locator('.library-current')).to_have_attribute('data-view','list');self.assertEqual(self.page.locator('.library-current [data-taxonomy-item]').count(),31)
 def test_svg_animation_is_local_visible_and_stops_when_paused(self):
  self.click('[data-library-view="list"]');glyph=self.page.locator('.library-current .compact-art').first;expect(glyph).to_have_class(__import__('re').compile('art-visible'));self.assertNotEqual(glyph.locator('.glyph-motion').evaluate('e=>getComputedStyle(e).animationName'),'none');self.click('#library-filter-trigger');self.click('#art-motion-toggle');self.click('#close-library-filters');self.assertEqual(glyph.locator('.glyph-motion').evaluate('e=>getComputedStyle(e).animationPlayState'),'paused')
 def test_card_selection_retains_itself_across_views(self):
  self.click('[data-library-view="list"]');self.click('[data-taxonomy-item="announcement"]');self.click('[data-library-view="pairings"]');expect(self.page.locator('.library-current [data-taxonomy-item="announcement"]')).to_have_attribute('aria-pressed','true');self.click('[data-library-view="gallery"]');expect(self.page.locator('.library-current [data-taxonomy-item="announcement"]')).to_have_attribute('aria-pressed','true')
 def test_sources_show_metric_scope_and_caveat(self):
  self.click('#library-filter-trigger');self.click('#library-research-trigger');expect(self.page.locator('#library-evidence')).to_be_visible();expect(self.page.locator('#library-evidence')).to_contain_text('Usage');expect(self.page.locator('#library-evidence')).to_contain_text('not');self.assertGreater(self.page.locator('#library-evidence a[href^="https://"]').count(),0)
if __name__=='__main__':unittest.main(verbosity=2)
