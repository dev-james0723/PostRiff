from pathlib import Path
import subprocess,sys,json,time
r=Path(__file__).resolve().parents[2]
out=r/'tests/v7'; results={}
for rel in ['tests/browser_test.py','tests/update_test.py','tests/refinement_test.py','tests/v5_test.py','tests/v6/test_v6.py']:
 t=time.monotonic()
 with (out/(Path(rel).stem+'-regression.txt')).open('w') as f:
  try:
   p=subprocess.run([sys.executable,str(r/rel)],cwd=r,stdout=f,stderr=subprocess.STDOUT,timeout=160)
   results[rel]={'exit_code':p.returncode,'seconds':round(time.monotonic()-t,1)}
  except subprocess.TimeoutExpired:results[rel]={'exit_code':'TIMEOUT','seconds':round(time.monotonic()-t,1)}
 print(rel,results[rel],flush=True)
 (out/'regression-results.json').write_text(json.dumps(results,indent=2))
