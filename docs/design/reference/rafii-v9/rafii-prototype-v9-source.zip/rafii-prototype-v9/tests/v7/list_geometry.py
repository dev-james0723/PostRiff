from pathlib import Path
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1280,'height':950})
 page.set_content(Path(__file__).resolve().parents[2].joinpath('index.html').read_text())
 page.locator('#format-trigger').click();page.wait_for_timeout(620)
 page.locator('[data-library-view="list"]').click();page.wait_for_timeout(600)
 r=page.locator('.library-current .list-card').first.bounding_box()
 print('List row geometry:',r,flush=True)
 assert r['height']<=100,'A compact list row must not inherit gallery column orientation'
 b.close()
