"""Record actual Chromium frames. Frame durations reflect capture time, not a synthetic animation."""
from pathlib import Path
import time,subprocess,json,tempfile
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[2]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 pg=b.new_page(viewport={'width':430,'height':932},device_scale_factor=1)
 pg.set_content((R/'index.html').read_text());pg.locator('#format-trigger').click();pg.wait_for_timeout(650)
 events=[(.8,"document.querySelector('[data-library-view=list]').click()"),(2,"document.querySelector('[data-info=status_update]').click()"),(3.2,"document.querySelector('[data-info=status_update]').click()"),(4.1,"{const x=document.querySelector('#taxonomy-search');x.value='how-to';x.dispatchEvent(new Event('input'));}"),(5,"document.querySelector('[data-library-view=pairings]').click()"),(6,"document.querySelector('#taxonomy-panel').scrollTo({top:160,behavior:'smooth'})"),(8,"document.querySelector('[data-use-pairing=how_to-document]').click()"),(9,"document.querySelector('[data-taxonomy-tab=native]').click()"),(10,"document.querySelector('[data-library-view=list]').click()"),(11.2,"document.querySelector('[data-library-view=gallery]').click()"),(12.5,"document.querySelector('#apply-taxonomy').click()")]
 out=R.parent/'rafii-v7-interactions.mp4';temp=tempfile.TemporaryDirectory(prefix='rafii-v7-frames-');frames_dir=Path(temp.name)
 start=time.monotonic();i=0;frames=0;stamps=[]
 while time.monotonic()-start<14:
  t=time.monotonic()-start
  while i<len(events) and t>=events[i][0]:pg.evaluate(events[i][1]);i+=1
  stamps.append(time.monotonic()-start);pg.screenshot(path=str(frames_dir/f'{frames:05}.jpg'),type='jpeg',quality=85);frames+=1
  pause=frames/16-(time.monotonic()-start)
  if pause>0:time.sleep(pause)
 end=time.monotonic()-start;lines=[]
 for n,stamp in enumerate(stamps):lines += [f"file '{frames_dir/f'{n:05}.jpg'}'",f"duration {max(.01,(stamps[n+1] if n+1<len(stamps) else end)-stamp):.6f}"]
 lines.append(f"file '{frames_dir/f'{frames-1:05}.jpg'}'");(frames_dir/'frames.txt').write_text('\n'.join(lines))
 subprocess.run(['ffmpeg','-y','-loglevel','error','-f','concat','-safe','0','-i',str(frames_dir/'frames.txt'),'-an','-c:v','libx264','-r','30','-pix_fmt','yuv420p','-movflags','+faststart',str(out)],check=True)
 pg.close();b.close();temp.cleanup();(R/'tests/v7/recording.json').write_text(json.dumps({'frames':frames,'duration_seconds':round(end-stamps[0],2),'source':'Actual browser screenshots with capture-time durations preserved. Capture rate is not a device-performance benchmark.','file':out.name},indent=2));print(out,frames)
