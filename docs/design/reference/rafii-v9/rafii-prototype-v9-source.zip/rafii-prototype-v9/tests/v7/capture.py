from pathlib import Path
from playwright.sync_api import sync_playwright,expect
R=Path(__file__).resolve().parents[2];O=R/'previews-v7';O.mkdir(exist_ok=True)
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 for device,w,h in [('desktop',1440,1050),('mobile',390,844)]:
  pg=b.new_page(viewport={'width':w,'height':h},device_scale_factor=1)
  pg.set_content((R/'index.html').read_text());pg.wait_for_timeout(400)
  pg.screenshot(path=str(O/f'{device}-home.png'))
  pg.locator('#format-trigger').click();pg.wait_for_timeout(650)
  pg.screenshot(path=str(O/f'{device}-gallery.png'))
  for view in ['list','pairings']:
   pg.locator(f'[data-library-view="{view}"]').click();expect(pg.locator('.library-outgoing')).to_have_count(0,timeout=5000);pg.wait_for_timeout(200)
   pg.screenshot(path=str(O/f'{device}-{view}.png'))
  pg.locator('[data-library-view="list"]').click();expect(pg.locator('.library-outgoing')).to_have_count(0,timeout=5000)
  pg.locator('[data-info="status_update"]').click();pg.wait_for_timeout(350)
  pg.screenshot(path=str(O/f'{device}-tooltip.png'))
  pg.keyboard.press('Escape');pg.wait_for_timeout(300)
  pg.locator('[data-taxonomy-tab="native"]').click();expect(pg.locator('.library-outgoing')).to_have_count(0,timeout=5000)
  pg.screenshot(path=str(O/f'{device}-native-list.png'))
  pg.evaluate("document.documentElement.dataset.appearance='light'")
  pg.wait_for_timeout(300);pg.screenshot(path=str(O/f'{device}-light-list.png'))
  pg.close();print(device,flush=True)
 b.close()
print('Captured.',flush=True)
