from pathlib import Path
import json,sys,xml.etree.ElementTree as ET
from playwright.sync_api import sync_playwright,expect
R=Path(__file__).resolve().parents[2];O=R/'previews-v7';O.mkdir(exist_ok=True)
html=(R/'index.html').read_text();records=[]
sizes=[(320,740),(375,812),(390,844),(430,932),(768,1024),(1024,768),(1440,1000),(1920,1080)]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 pg=b.new_page(reduced_motion='reduce');errors=[];requests=[];pg.on('pageerror',lambda e:errors.append(str(e)));pg.on('request',lambda r:requests.append(r.url))
 pg.set_content(html);pg.locator('#format-trigger').click()
 for w,h in sizes:
  pg.set_viewport_size({'width':w,'height':h})
  for theme in ['dark','light']:
   pg.evaluate('(x)=>document.documentElement.dataset.appearance=x',theme)
   for dim,expected in [('editorial',31),('native',20)]:
    pg.locator(f'[data-taxonomy-tab="{dim}"]').click()
    for view in ['gallery','list','pairings']:
     pg.locator(f'[data-library-view="{view}"]').click();pg.wait_for_timeout(35)
     results=pg.evaluate('''()=>{const dialog=document.querySelector('#format-dialog'),panel=document.querySelector('#taxonomy-panel'),layer=document.querySelector('.library-current'),cards=[...layer.querySelectorAll('[data-taxonomy-item]')],r=dialog.getBoundingClientRect();return {modalInside:r.x>=-1&&r.y>=-1&&r.right<=innerWidth+1&&r.bottom<=innerHeight+1,documentFits:document.documentElement.scrollWidth<=innerWidth+1,panelFits:panel.scrollWidth<=panel.clientWidth+1,count:cards.length,allHaveSvg:cards.every(c=>c.querySelector('svg')),cardsFit:cards.every(c=>c.scrollWidth<=c.clientWidth+1),columns:getComputedStyle(layer).gridTemplateColumns.split(' ').length,rows:cards.map(c=>c.getBoundingClientRect().height)}}''')
     results.update(width=w,height=h,theme=theme,dimension=dim,view=view)
     assert results['modalInside'],results
     assert results['documentFits'] and results['panelFits'] and results['cardsFit'],results
     assert results['count']==expected and results['allHaveSvg'],results
     if view=='gallery':assert results['columns']==(1 if w<=600 else 2),results
     if view=='list':assert max(results['rows'])<=110,results
     records.append(results)
  print(w,h,'passed',flush=True)
 # keyboard focused, boundary tooltip, long text, missing/legacy fallback are explicit audit states.
 pg.set_viewport_size({'width':390,'height':844});pg.evaluate("document.documentElement.dataset.appearance='dark'")
 pg.locator('[data-library-view="list"]').click();pg.locator('[data-taxonomy-item="local_business_update"]').focus();pg.screenshot(path=str(O/'mobile-focus.png'))
 pg.locator('[data-info="local_business_update"]').click();pg.wait_for_timeout(30)
 box=pg.locator('#library-tooltip').bounding_box();assert box['x']>=0 and box['x']+box['width']<=390
 pg.screenshot(path=str(O/'mobile-boundary-tooltip.png'));pg.keyboard.press('Escape')
 # Force an explicit legacy copy only for audit. None of the 51 data items uses it.
 pg.evaluate('''()=>{const c=document.querySelector('.library-current [data-taxonomy-item]');c.querySelector('strong').textContent='A very long editorial title for multilingual demonstration and content planning';const icon=c.querySelector('.compact-art');icon.setAttribute('aria-label','Explicit legacy fallback');icon.innerHTML='<svg viewBox="0 0 48 48" role="img" aria-label="Legacy content item"><rect x="8" y="5" width="32" height="38" rx="4" fill="none" stroke="currentColor"/><path d="M16 17h16M16 24h16M16 31h8" fill="none" stroke="currentColor"/></svg>';c.focus();}''')
 pg.screenshot(path=str(O/'mobile-legacy-long-title.png'))
 assert not errors,errors
 assert not [u for u in requests if u.startswith(('http:','https:'))],requests
 pg.close();b.close()
for f in (R/'src/assets/glyphs').glob('*.svg'):assert ET.parse(f).getroot().tag=='{http://www.w3.org/2000/svg}svg'
(R/'tests/v7/visual-results.json').write_text(json.dumps({'states':records,'browser_errors':errors,'external_requests':requests,'standalone_svg_files':51},indent=2))
print('96 layout states passed; 51 standalone vectors parsed.',flush=True)
