"""Re-run every retained behavioural suite plus v9; retain fresh evidence."""
import subprocess,sys,json,time,concurrent.futures
from pathlib import Path
R=Path(__file__).resolve().parents[2];O=R/'tests/v9';O.mkdir(exist_ok=True)
cases=[('node',['node','--test',*map(str,sorted((R/'tests').rglob('*.cjs')))])]
for name in ['tests/browser_test.py','tests/update_test.py','tests/refinement_test.py','tests/v5_test.py','tests/v6/test_v6.py','tests/v7/test_v7.py','tests/v8/test_toolbar.py','tests/v9/test_folders.py']:
 cases.append((name,[sys.executable,str(R/name)]))
def run(case):
 name,cmd=case;start=time.monotonic();log=O/(name.replace('/','_')+'.log')
 with log.open('w') as f:
  try:r=subprocess.run(cmd,cwd=R,stdout=f,stderr=subprocess.STDOUT,timeout=200);code=r.returncode
  except subprocess.TimeoutExpired:code='timeout'
 return name,{'exit_code':code,'seconds':round(time.monotonic()-start,2),'log':str(log.relative_to(R))}
results={}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 for name,r in pool.map(run,cases):
  results[name]=r;print(name,r,flush=True);(O/'all-results.json').write_text(json.dumps(results,indent=2))
raise SystemExit(0 if all(r['exit_code']==0 for r in results.values()) else 1)
