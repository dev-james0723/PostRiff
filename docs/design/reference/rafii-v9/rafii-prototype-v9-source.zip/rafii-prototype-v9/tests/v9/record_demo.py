"""Record actual Chromium screencast frames and their timestamps; no generated mockups."""
import base64,subprocess
from pathlib import Path
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[2];O=R/'tests/v9/recording-frames';O.mkdir(exist_ok=True);frames=[]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 ctx=b.new_context(viewport={'width':390,'height':844},reduced_motion='no-preference',device_scale_factor=1)
 page=ctx.new_page();page.set_default_timeout(5000);page.set_content((R/'index.html').read_text());page.locator('#channels-trigger').click();page.wait_for_timeout(700)
 c=ctx.new_cdp_session(page)
 def capture(event):
  path=O/f'{len(frames):05d}.jpg';path.write_bytes(base64.b64decode(event['data']));frames.append((path,event['metadata']['timestamp']));c.send('Page.screencastFrameAck',{'sessionId':event['sessionId']})
 c.on('Page.screencastFrame',capture);c.send('Page.startScreencast',{'format':'jpeg','quality':86,'maxWidth':390,'maxHeight':844,'everyNthFrame':1})
 page.wait_for_timeout(700);page.locator('#clear-channels').click();page.wait_for_timeout(350)
 page.locator('[data-folder-select="festival"]').click();page.wait_for_timeout(700)
 page.locator('[data-folder-inspect="festival"]').click();page.wait_for_timeout(1400)
 page.locator('#folder-inspector input[data-account-select="account-facebook"]').uncheck();page.wait_for_timeout(600)
 page.locator('#folder-undo').click();page.wait_for_timeout(550)
 page.locator('#edit-folder').click();page.wait_for_timeout(600)
 page.locator('#folder-name').fill('Festival updates');page.wait_for_timeout(400)
 page.locator('[data-folder-symbol="spark"]').click();page.wait_for_timeout(400)
 page.locator('#save-folder').click();page.wait_for_timeout(700)
 page.locator('#channel-done').click();page.wait_for_timeout(900)
 c.send('Page.stopScreencast');ctx.close();b.close()
lines=[]
for i,(path,t) in enumerate(frames):
 duration=frames[i+1][1]-t if i+1<len(frames) else .6
 lines.extend([f"file '{path}'",f'duration {max(.016,duration):.6f}'])
lines.append(f"file '{frames[-1][0]}'");(O/'frames.txt').write_text('\n'.join(lines))
output=R.parent/'rafii-v9-folders.mp4'
subprocess.run(['ffmpeg','-y','-loglevel','error','-f','concat','-safe','0','-i',str(O/'frames.txt'),'-vsync','vfr','-c:v','libx264','-preset','fast','-crf','23','-pix_fmt','yuv420p','-movflags','+faststart',str(output)],check=True)
print('Captured',len(frames),'actual browser frames;',round(frames[-1][1]-frames[0][1],2),'seconds.',output)
