"""Real UI tests for v9 folder actions and selection isolation."""
import os,unittest,shutil
from pathlib import Path
from playwright.sync_api import sync_playwright,expect
R=Path(__file__).resolve().parents[2]
TARGET=Path(os.environ.get('RAFII_HTML',R/'index.html'))
class FoldersTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.p=sync_playwright().start();cls.browser=cls.p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox'])
 @classmethod
 def tearDownClass(cls):cls.browser.close();cls.p.stop()
 def setUp(self):
  self.page=self.browser.new_page(viewport={'width':390,'height':844},reduced_motion='reduce');self.errors=[]
  self.page.on('pageerror',lambda e:self.errors.append(str(e)));self.page.set_content(TARGET.read_text());self.page.set_default_timeout(2200)
  self.page.locator('#channels-trigger').click()
 def tearDown(self):
  self.page.close();self.assertEqual(self.errors,[])
 def clear(self):self.page.locator('#clear-channels').click()
 def group(self,g):return self.page.locator(f'[data-folder-select="{g}"]')
 def inspect(self,g):self.page.locator(f'[data-folder-inspect="{g}"]').click()
 def pick(self,platform):self.page.locator(f'#channel-grid input[value="{platform}"]').check()
 def create(self,name='My channels'):
  self.page.locator('#new-folder').click();self.page.locator('#folder-name').fill(name)
  self.page.locator('#folder-member-choices input').first.check();self.page.locator('#save-folder').click()
 def test_three_demo_folders_and_compact_individual_rows(self):
  self.assertEqual(self.page.locator('[data-folder-select]').count(),3)
  self.assertEqual(self.page.locator('#channel-grid input').count(),6)
  self.assertLess(self.page.locator('#channel-grid .account-row').first.bounding_box()['height'],86)
 def test_folder_checkbox_uses_mixed_state(self):
  self.assertEqual(self.group('personal').get_attribute('aria-checked'),'mixed')
 def test_inspection_does_not_select_accounts(self):
  before=self.page.locator('#channel-done').inner_text();self.inspect('festival')
  expect(self.page.locator('#folder-inspector')).to_be_visible();self.assertEqual(self.page.locator('#channel-done').inner_text(),before)
 def test_folder_adds_and_commits_once(self):
  self.clear();self.group('festival').click();expect(self.page.locator('#channel-done')).to_contain_text('3')
  self.page.locator('#channel-done').click();expect(self.page.locator('#channels-count')).to_have_text('3')
  expect(self.page.locator('#channel-folder-summary')).to_contain_text('Festival')
 def test_overlap_has_no_duplicate_accounts_and_undo(self):
  self.clear();self.group('personal').click();self.group('professional').click()
  expect(self.page.locator('#channel-done')).to_contain_text('4');self.group('personal').click()
  expect(self.group('professional')).to_have_attribute('aria-checked','mixed')
  self.page.locator('#folder-undo').click();expect(self.page.locator('#channel-done')).to_contain_text('4')
 def test_cancel_discards_staged_destinations(self):
  self.clear();self.group('festival').click();self.page.locator('#channel-dialog .close-dialog').click()
  self.page.locator('#channels-trigger').click();expect(self.page.locator('#channel-grid input[value="linkedin"]')).to_be_checked()
  expect(self.page.locator('#channel-grid input[value="red"]')).not_to_be_checked()
 def test_save_selection_creates_without_changing_selection(self):
  self.clear();self.pick('instagram');self.pick('red');self.page.locator('#save-selection-folder').click()
  self.page.locator('#folder-name').fill('Across borders');self.page.locator('#save-folder').click()
  expect(self.page.locator('#folder-shelf')).to_contain_text('Across borders');expect(self.page.locator('#channel-done')).to_contain_text('2')
 def test_editor_checks_name_and_members(self):
  self.page.locator('#new-folder').click();expect(self.page.locator('#save-folder')).to_be_disabled()
  self.page.locator('#folder-name').fill('Empty');expect(self.page.locator('#save-folder')).to_be_disabled()
 def test_create_and_rename(self):
  self.create();button=self.page.locator('[data-folder-select]').filter(has_text='My channels');expect(button).to_be_visible()
  fid=button.get_attribute('data-folder-select');self.inspect(fid);self.page.locator('#edit-folder').click()
  self.page.locator('#folder-name').fill('Renamed');self.page.locator('#save-folder').click()
  expect(self.page.locator('#folder-shelf')).to_contain_text('Renamed')
 def test_changes_to_folder_do_not_alter_staged_accounts(self):
  before=self.page.locator('#channel-done').inner_text();self.inspect('festival');self.page.locator('#edit-folder').click()
  self.page.locator('#folder-member-choices input').first.uncheck();self.page.locator('#save-folder').click()
  self.assertEqual(self.page.locator('#channel-done').inner_text(),before)
 def test_duplicate_pin_and_reorder(self):
  self.inspect('personal');self.page.locator('#folder-more').click();self.page.locator('[data-folder-command="duplicate"]').click()
  expect(self.page.locator('#folder-shelf')).to_contain_text('Personal copy')
  self.page.locator('#folder-more').click();self.page.locator('[data-folder-command="pin"]').click()
  self.page.locator('#folder-more').click();expect(self.page.locator('[data-folder-command="up"]')).to_be_visible()
 def test_delete_does_not_disconnect_or_deselect(self):
  before=self.page.locator('#channel-done').inner_text();self.inspect('festival');self.page.locator('#folder-more').click()
  self.page.locator('[data-folder-command="delete"]').click();self.page.locator('#confirm-delete-folder').click()
  self.assertEqual(self.group('festival').count(),0);self.assertEqual(self.page.locator('#channel-grid input').count(),6)
  self.assertEqual(self.page.locator('#channel-done').inner_text(),before)
 def test_search_matches_both_folder_and_account(self):
  self.page.locator('#channel-search').fill('Festival');self.assertEqual(self.page.locator('[data-folder-select]').count(),1)
  self.page.locator('#channel-search').fill('Instagram');expect(self.page.locator('#channel-grid .account-row:visible')).to_have_count(1)
 def test_empty_search_and_clear(self):
  self.page.locator('#channel-search').fill('zzzzzz');expect(self.page.locator('#folder-search-empty')).to_be_visible()
  self.page.locator('#clear-folder-search').click();self.assertEqual(self.page.locator('[data-folder-select]').count(),3)
 def test_keyboard_toggle_then_expand(self):
  self.clear();self.group('personal').focus();self.page.keyboard.press('Space');expect(self.group('personal')).to_have_attribute('aria-checked','true')
  self.page.locator('[data-folder-inspect="personal"]').focus();self.page.keyboard.press('Enter');expect(self.page.locator('#folder-inspector')).to_be_visible()
 def test_customized_label_and_unchanged_folder(self):
  self.clear();self.group('festival').click();self.page.locator('#channel-grid input[value="facebook"]').uncheck();self.page.locator('#channel-done').click()
  expect(self.page.locator('#channel-folder-summary')).to_contain_text('customized');self.page.locator('#channels-trigger').click();self.inspect('festival')
  expect(self.page.locator('#folder-inspector input')).to_have_count(3)
 def test_selection_keeps_language_model_voice(self):
  self.page.locator('#channel-dialog .close-dialog').click();before=[self.page.locator(s).inner_text() for s in ['#language-summary','#model-summary','#voice-summary']]
  self.page.locator('#channels-trigger').click();self.clear();self.group('personal').click();self.page.locator('#channel-done').click()
  after=[self.page.locator(s).inner_text() for s in ['#language-summary','#model-summary','#voice-summary']];self.assertEqual(before,after)
 def test_generate_saved_folder_selection_without_duplicate_platform_drafts(self):
  self.clear();self.group('personal').click();self.group('professional').click();self.page.locator('#channel-done').click()
  self.page.locator('#idea').fill('One thoughtful practice session.');self.page.locator('#generate').click()
  expect(self.page.locator('#generation-status')).to_contain_text('4 of 4 ready',timeout=6000)
  self.assertEqual(self.page.locator('.draft-tab').count(),4)
 def test_inspector_unfolds_directly_beneath_its_folder_row(self):
  self.inspect('festival')
  self.assertEqual(self.page.locator('#folder-inspector').evaluate('(e)=>e.parentElement.id'),'folder-shelf')
  self.assertEqual(self.page.locator('#folder-inspector').evaluate('(e)=>e.previousElementSibling.dataset.folderCard'),'festival')
 def test_only_one_confirmation_and_no_modal_overflow(self):
  expect(self.page.locator('#channel-dialog .folder-main-footer .dialog-primary:visible')).to_have_count(1)
  self.assertTrue(self.page.locator('#channel-dialog').evaluate('(e)=>e.scrollWidth<=e.clientWidth+1'))
 def test_reorder_changes_the_actual_visible_order(self):
  self.inspect('professional');self.page.locator('#folder-more').click();self.page.locator('[data-folder-command="up"]').click()
  self.assertEqual(self.page.locator('[data-folder-select]').evaluate_all('es=>es.map(e=>e.dataset.folderSelect)'),['personal','professional','festival'])
 def test_unsaved_folder_editor_cancels_without_creating(self):
  self.page.locator('#new-folder').click();self.page.locator('#folder-name').fill('Not saved');self.page.locator('#cancel-folder-editor').click()
  self.assertEqual(self.page.locator('[data-folder-select]').count(),3)
 def test_duplicate_name_is_rejected_without_overwriting(self):
  self.page.locator('#new-folder').click();self.page.locator('#folder-name').fill('Festival');self.page.locator('#folder-member-choices input').first.check()
  expect(self.page.locator('#save-folder')).to_be_disabled();expect(self.page.locator('#folder-editor-error')).to_contain_text('already')
 def test_fifth_folder_can_be_found_in_view_all(self):
  self.create('Fourth');self.create('Fifth')
  self.assertEqual(self.page.locator('[data-folder-select]').count(),5)
  self.page.locator('#view-all-folders').click();self.assertEqual(self.page.locator('[data-folder-select]').count(),4)
  self.page.locator('#view-all-folders').click();self.assertEqual(self.page.locator('[data-folder-select]').count(),5)
 def test_escape_exits_editor_without_closing_channel_sheet(self):
  self.page.locator('#new-folder').click();self.page.keyboard.press('Escape')
  expect(self.page.locator('#folder-main-view')).to_be_visible();expect(self.page.locator('#channel-dialog')).to_be_visible()
 def test_saved_folder_does_not_disappear_when_channel_selection_is_cancelled(self):
  self.create('Keep me');self.page.locator('#channel-dialog .close-dialog').click();self.page.locator('#channels-trigger').click()
  expect(self.page.locator('#folder-shelf')).to_contain_text('Keep me')
 def test_folder_inspector_has_real_intermediate_animation(self):
  self.page.emulate_media(reduced_motion='no-preference')
  self.page.locator('[data-folder-inspect="festival"]').evaluate('e=>e.click()')
  box=self.page.locator('#folder-inspector');self.assertGreater(box.evaluate('(e)=>e.getAnimations().length'),0)
  self.page.wait_for_timeout(140);middle=box.bounding_box()['height'];self.page.wait_for_timeout(550)
  self.assertGreater(middle,0);self.assertLess(middle,box.bounding_box()['height'])
 def test_rapid_open_close_settles_on_last_folder(self):
  self.page.emulate_media(reduced_motion='no-preference')
  self.page.evaluate("""async()=>{for(const id of ['festival','festival','personal','festival']){document.querySelector(`[data-folder-inspect="${id}"]`).click();await new Promise(r=>setTimeout(r,40));}}""")
  self.page.wait_for_timeout(650);expect(self.page.locator('#folder-inspector h3')).to_have_text('Festival')
  self.assertEqual(self.page.locator('#folder-inspector').count(),1);self.assertEqual(self.page.locator('#folder-inspector').evaluate('(e)=>e.getAnimations().length'),0)
 def test_reduced_motion_has_no_folder_web_animations(self):
  self.inspect('festival');self.assertEqual(self.page.locator('#folder-inspector').evaluate('(e)=>e.getAnimations({subtree:true}).length'),0)
 def test_folder_names_are_rendered_as_text(self):
  self.create('<img src=x onerror=alert(1)>');self.assertEqual(self.page.locator('#folder-shelf img').count(),0)
if __name__=='__main__':unittest.main(verbosity=2)
