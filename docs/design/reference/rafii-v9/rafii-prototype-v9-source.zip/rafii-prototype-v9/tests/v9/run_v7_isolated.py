"""Run unchanged inherited cases in fresh browser processes to bound renderer lifetime."""
import ast,subprocess,sys,json
from pathlib import Path
R=Path(__file__).resolve().parents[2];O=R/'tests/v9';T=R/'tests/v7/test_v7.py'
cls=next(n for n in ast.parse(T.read_text()).body if isinstance(n,ast.ClassDef))
names=[n.name for n in cls.body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')]
start=int(sys.argv[1]) if len(sys.argv)>1 else 0;end=int(sys.argv[2]) if len(sys.argv)>2 else len(names)
for name in names[start:end]:
 p=O/('v7_'+name+'.log')
 with p.open('w') as f:
  r=subprocess.run([sys.executable,str(T),'V7Tests.'+name],stdout=f,stderr=subprocess.STDOUT,cwd=R,timeout=35)
 print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
