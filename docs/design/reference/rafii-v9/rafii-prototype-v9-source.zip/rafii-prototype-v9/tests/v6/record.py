"""Record real browser frames of the v6 controls; no fabricated animation frames."""
from pathlib import Path
import time,subprocess,json,tempfile
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[2]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 pg=b.new_page(viewport={'width':430,'height':900},device_scale_factor=1)
 pg.set_content((R/'index.html').read_text());pg.locator('#model-trigger').evaluate('e=>e.click()');pg.wait_for_timeout(650)
 events=[(.7,'[data-provider="anthropic"]'),(1.8,'[data-model-choice="claude-sonnet"]'),(2.4,'[data-thinking="low"]'),(3.1,'[data-thinking="max"]'),(3.9,'[data-provider="google"]'),(4.9,'[data-model-choice="gemini-flash"]'),(5.5,'[data-thinking="high"]'),(6.2,'#model-dialog .close-dialog'),(6.7,'#language-trigger'),(7.5,'#same-language-toggle'),(9.2,'#language-dialog .close-dialog'),(9.7,'#format-trigger'),(11.0,'[data-taxonomy-tab="native"]')]
 video=R.parent/'rafii-v6-interactions.mp4'
 temp=tempfile.TemporaryDirectory(prefix='rafii-record-');frames_dir=Path(temp.name)
 start=time.monotonic(); i=0;frames=0;duration=12.6;stamps=[]
 while time.monotonic()-start<duration:
  t=time.monotonic()-start
  while i<len(events) and t>=events[i][0]:
   pg.locator(events[i][1]).evaluate('e=>e.click()');i+=1
  stamps.append(time.monotonic()-start)
  pg.screenshot(path=str(frames_dir/f'{frames:05}.jpg'),type='jpeg',quality=85);frames+=1
  sleep=frames/16-(time.monotonic()-start)
  if sleep>0:time.sleep(sleep)
 end=time.monotonic()-start
 lines=[]
 for n,stamp in enumerate(stamps):
  lines.append(f"file '{frames_dir/f'{n:05}.jpg'}'")
  lines.append(f"duration {max(.01,(stamps[n+1] if n+1<len(stamps) else end)-stamp):.6f}")
 lines.append(f"file '{frames_dir/f'{frames-1:05}.jpg'}'")
 (frames_dir/'frames.txt').write_text('\n'.join(lines))
 subprocess.run(['ffmpeg','-y','-loglevel','error','-f','concat','-safe','0','-i',str(frames_dir/'frames.txt'),'-an','-c:v','libx264','-r','30','-pix_fmt','yuv420p','-movflags','+faststart',str(video)],check=True)
 b.close();temp.cleanup()
 (R/'tests/v6/recording.json').write_text(json.dumps({'captured_frames':frames,'duration_seconds':end-stamps[0],'source':'Actual Chromium browser frames with wall-clock frame durations preserved','file':video.name},indent=2))
 print(video,frames)
