"""Capture complete galleries from the actual picker markup, plus state and layout audits."""
from pathlib import Path
import json,re,shutil
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[2];html=(R/'index.html').read_text();O=R/'previews-v6';O.mkdir(exist_ok=True)
css='\n'.join(re.findall(r'<style>(.*?)</style>',html,re.S))
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1280,'height':900});page.set_content(html)
 page.locator('#format-trigger').evaluate('e=>e.click()');page.wait_for_timeout(600)
 editorial=page.locator('#taxonomy-grid').inner_html();page.locator('[data-taxonomy-tab="native"]').click();page.wait_for_timeout(400);native=page.locator('#taxonomy-grid').inner_html()
 legacy=page.evaluate('RafiiTaxonomy.legacyAsset')
 state_extra=page.locator('.taxonomy-card').first.evaluate('''el=>{const clone=el.cloneNode(true);clone.id='long-title-card';clone.removeAttribute('data-taxonomy-item');clone.querySelector(':scope>strong').textContent='A deliberately long editorial title for an international audience with detailed context';clone.querySelector('.taxonomy-description').textContent='A deliberately long description checks that labels wrap naturally, stay legible and never disappear behind neighbouring cards or fixed controls.';return clone.outerHTML;}''')
 disabled=page.locator('.taxonomy-card').first.evaluate('''el=>{const c=el.cloneNode(true);c.removeAttribute('data-taxonomy-item');c.disabled=true;c.id='disabled-state-card';c.querySelector(':scope>strong').textContent='Unavailable state (audit only)';return c.outerHTML;}''')
 audit='<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Rafii v6 · complete visual validation</title><style>'+css+'''\nbody{margin:0;padding:28px;background:var(--bg);color:var(--ink);font-family:Arial,sans-serif}.audit-wrap{max-width:900px;margin:auto}.audit-wrap h1{font-size:30px;margin:20px 0}.audit-wrap h2{font-size:24px;margin:40px 0 24px}.audit-wrap p{font-size:13px;line-height:1.6;color:var(--muted);margin-bottom:24px}.taxonomy-grid{margin:10px 0 40px}.audit-wrap .taxonomy-card{pointer-events:auto}@media(max-width:600px){body{padding:18px}}
</style></head><body><main class="audit-wrap"><h1>rafii. / the complete editorial library</h1><p>Actual v6 picker cards. 31 editorial types and 20 native formats. Concept preferences only, not verified platform availability.</p><h2>01 / Editorial types</h2><div class="taxonomy-grid" id="audit-editorial">'''+editorial+'''</div><h2>02 / Native formats</h2><div class="taxonomy-grid" id="audit-native">'''+native+'''</div><h2>03 / Explicit validation states</h2><p>These extra cards are state tests, not new taxonomy items.</p><div class="taxonomy-grid">'''+state_extra+disabled+f'''<button class="taxonomy-card legacy-card"><span class="taxonomy-art"><img src="{legacy}" width="320" height="200" alt="Legacy content type: select a supported current type."></span><span class="taxonomy-family">LEGACY FALLBACK ONLY</span><strong>Unrecognised legacy type</strong><span class="taxonomy-description">This explicit fallback is never used for the 51 newly implemented items.</span></button></div></main></body></html>'''
 (R/'visual-validation.html').write_text(audit)
 results=[]
 for device,width,height in [('desktop',1200,900),('tablet',768,1024),('mobile',390,844)]:
  for theme in ['dark','light']:
   pg=b.new_page(viewport={'width':width,'height':height});pg.set_content(audit);pg.evaluate('(theme)=>document.documentElement.dataset.appearance=theme',theme);pg.wait_for_timeout(180)
   pg.locator('#audit-editorial .taxonomy-card').nth(7).focus()
   pg.screenshot(path=str(O/(f'complete-{device}-{theme}.png')),full_page=True)
   data=pg.evaluate('''()=>({overflow:document.documentElement.scrollWidth>innerWidth,images:[...document.images].map(i=>({ok:i.complete&&i.naturalWidth>0,alt:!!i.alt})),cards:[...document.querySelectorAll('.taxonomy-card')].map(c=>{const r=c.getBoundingClientRect();return [...c.querySelectorAll(':scope>strong,.taxonomy-description')].some(t=>{const a=t.getBoundingClientRect();return a.left<r.left||a.right>r.right+.5||a.bottom>r.bottom+.5})}),columns:getComputedStyle(document.querySelector('.taxonomy-grid')).gridTemplateColumns.split(' ').length})''')
   assert not data['overflow'];assert all(i['ok'] and i['alt'] for i in data['images']);assert not any(data['cards']);assert data['columns']==(1 if width<=600 else 2)
   results.append({'device':device,'theme':theme,'width':width,'images':len(data['images']),'overflow':False,'clipped_title_or_description':False,'columns':data['columns']});pg.close()
 # Actual app layout and all principal dialogs across eight viewport sizes.
 layouts=[]
 for width,height in [(320,740),(375,812),(390,844),(430,932),(600,960),(768,1024),(1024,768),(1440,1000)]:
  pg=b.new_page(viewport={'width':width,'height':height});pg.set_content(html)
  for name,trigger in [('home',None),('taxonomy','#format-trigger'),('model','#model-trigger'),('language','#language-trigger'),('expanded','#showcase-expand')]:
   if trigger:pg.locator(trigger).evaluate('e=>e.click()');pg.wait_for_timeout(550)
   d=pg.evaluate('''()=>{const el=document.querySelector('dialog[open]');const r=el?.getBoundingClientRect();return {pageOverflow:document.documentElement.scrollWidth>innerWidth,dialogOutside:r? r.left<-.5||r.right>innerWidth+.5||r.top<-.5||r.bottom>innerHeight+.5:false}}''')
   assert not d['pageOverflow'] and not d['dialogOutside'],(width,name,d)
   layouts.append({'width':width,'height':height,'state':name,**d})
   if trigger:pg.locator('dialog[open] .close-dialog').evaluate('e=>e.click()');pg.wait_for_timeout(240)
  pg.close()
 (R/'tests/v6/visual-results.json').write_text(json.dumps({'complete_galleries':results,'layouts':layouts},indent=2));print(json.dumps({'gallery_states':len(results),'app_layout_states':len(layouts),'status':'passed'}));b.close()
