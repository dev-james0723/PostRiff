from pathlib import Path
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[2];h=(R/'index.html').read_text();out=R/'previews-v6';out.mkdir(exist_ok=True)
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 for name,w,height in [('desktop',1440,1000),('mobile',390,844)]:
  page=b.new_page(viewport={'width':w,'height':height});page.set_content(h);page.screenshot(path=str(out/(name+'-home.png')),full_page=True)
  for state,trigger in [('editorial','#format-trigger'),('model','#model-trigger'),('shared','#language-trigger')]:
   page.locator(trigger).evaluate('e=>e.click()');page.wait_for_timeout(600)
   if state=='shared':page.locator('#same-language-toggle').check();page.wait_for_timeout(600)
   page.screenshot(path=str(out/(name+'-'+state+'.png')),full_page=False)
   if state=='editorial':
    page.locator('[data-taxonomy-tab="native"]').click();page.wait_for_timeout(500);page.screenshot(path=str(out/(name+'-native.png')))
   page.locator('dialog[open] .close-dialog').click();page.wait_for_timeout(300)
  page.close()
 b.close()
