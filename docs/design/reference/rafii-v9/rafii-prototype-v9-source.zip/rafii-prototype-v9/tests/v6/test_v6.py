import os, shutil, unittest
from pathlib import Path
from playwright.sync_api import sync_playwright, expect
ROOT=Path(__file__).resolve().parents[2]
TARGET=Path(os.environ.get('RAFII_HTML', ROOT/'index.html'))
class V6Tests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.p=sync_playwright().start();cls.browser=cls.p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox'])
 @classmethod
 def tearDownClass(cls): cls.browser.close();cls.p.stop()
 def setUp(self):
  self.page=self.browser.new_page(viewport={'width':1280,'height':900});self.errors=[];self.page.on('pageerror',lambda e:self.errors.append(str(e)));self.page.set_content(TARGET.read_text(),wait_until='load');self.page.set_default_timeout(2000)
 def tearDown(self):self.page.close();self.assertEqual(self.errors,[])
 def click(self,s):self.page.locator(s).evaluate('e=>e.click()')
 def test_reasoning_available_for_every_model_and_bars(self):
  self.click('#model-trigger'); self.page.wait_for_timeout(500)
  for m in self.page.evaluate('RafiiModels.models'):
   self.click(f'[data-provider="{m["provider"]}"]'); self.click(f'[data-model-choice="{m["id"]}"]');expect(self.page.locator('#thinking-control')).to_be_visible()
   for n,level in enumerate(['low','medium','high','max'],1):
    self.click(f'[data-thinking="{level}"]');self.assertEqual(self.page.locator('.thinking-bars i.lit').count(),n)
 def test_provider_switch_has_two_content_layers_in_flight(self):
  self.click('#model-trigger');self.page.wait_for_timeout(650);self.click('[data-provider="anthropic"]');
  self.assertEqual(self.page.locator('#model-list-transition .switch-outgoing').count(),1)
  self.page.wait_for_timeout(650);expect(self.page.locator('#model-provider-title')).to_have_text('Anthropic');expect(self.page.locator('#model-list-transition .switch-outgoing')).to_have_count(0)
 def test_reasoning_indicator_is_persistent_and_moves(self):
  self.click('#model-trigger');self.page.wait_for_timeout(600)
  self.assertEqual(self.page.locator('#thinking-options .reasoning-lens').count(),1)
  self.page.locator('#thinking-options .reasoning-lens').evaluate('el=>el.dataset.testIdentity="keep"')
  self.click('[data-thinking="max"]');expect(self.page.locator('.reasoning-lens')).to_have_attribute('data-test-identity','keep');expect(self.page.locator('#thinking-options')).to_have_attribute('data-level','max')
 def test_taxonomy_all_51_cards_with_unique_thumbnails(self):
  self.click('#format-trigger');self.assertEqual(self.page.locator('[data-taxonomy-item]').count(),31)
  imgs=self.page.locator('.library-current [data-taxonomy-item] .large-art svg');self.assertEqual(imgs.count(),31)
  self.assertEqual(len(set(imgs.evaluate_all('es=>es.map(e=>e.parentElement.dataset.artId)'))),31)
  self.click('[data-taxonomy-tab="native"]');expect(self.page.locator('.library-outgoing')).to_have_count(0);self.assertEqual(self.page.locator('[data-taxonomy-item]').count(),20)
  self.assertEqual(self.page.locator('.library-current [data-taxonomy-item] .large-art svg').count(),20)
 def test_taxonomy_choice_persists_through_generation(self):
  self.click('#format-trigger');self.click('[data-taxonomy-item="how_to"]');self.click('[data-taxonomy-tab="native"]');self.click('[data-taxonomy-item="carousel"]');self.click('#apply-taxonomy');expect(self.page.locator('#format-dialog')).not_to_be_visible();
  self.page.locator('#idea').fill('Small practice steps.');self.click('#generate');expect(self.page.locator('#generation-status')).to_contain_text('3 of 3 ready',timeout=5500)
  expect(self.page.locator('#draft-format-meta')).to_contain_text('How-to');expect(self.page.locator('#draft-format-meta')).to_contain_text('Carousel')
 def test_mobile_taxonomy_one_column_desktop_two(self):
  self.click('#format-trigger');self.assertEqual(self.page.locator('.library-current[data-view="gallery"]').evaluate('e=>getComputedStyle(e).gridTemplateColumns.split(" ").length'),2)
  self.page.set_viewport_size({'width':390,'height':844});self.assertEqual(self.page.locator('.library-current[data-view="gallery"]').evaluate('e=>getComputedStyle(e).gridTemplateColumns.split(" ").length'),1)
 def test_shared_dropdown_animates_and_keeps_apply_guard(self):
  self.click('#language-trigger');self.page.wait_for_timeout(600);self.click('#same-language-toggle');
  self.assertGreater(self.page.locator('#shared-language-content').evaluate('el=>el.getAnimations({subtree:true}).length'),0)
  expect(self.page.locator('#save-language')).to_be_disabled()
 def test_company_logo_assets_present(self):
  self.click('#model-trigger');self.assertEqual(self.page.locator('#provider-rail [data-brand-asset]').count(),4)
if __name__=='__main__':unittest.main(verbosity=2)
