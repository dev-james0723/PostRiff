"""Regression checks for monochrome glass and repository-native phone previews.
v4 selectors scope to the active phone, excluding the two inert decorative neighbours.
"""
import unittest, os, shutil
from pathlib import Path
from playwright.sync_api import sync_playwright, expect
ROOT=Path(__file__).resolve().parents[1]
class UpdateTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.p=sync_playwright().start(); cls.browser=cls.p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox'])
 @classmethod
 def tearDownClass(cls): cls.browser.close(); cls.p.stop()
 def setUp(self):
  self.context=self.browser.new_context(viewport={'width':1440,'height':1080},reduced_motion='reduce')
  self.page=self.context.new_page(); self.errors=[];self.page.on('pageerror',lambda e:self.errors.append(str(e)))
  self.page.set_content(ROOT.joinpath('index.html').read_text(),wait_until='load'); self.page.wait_for_timeout(80)
 def tearDown(self):
  self.context.close();self.assertEqual(self.errors,[])
 def test_surface_is_borderless_monochrome_glass(self):
  s=self.page.locator('.composer').evaluate('''(e)=>{const s=getComputedStyle(e);const canvas=document.createElement('canvas');canvas.width=canvas.height=1;const ctx=canvas.getContext('2d');ctx.fillStyle=getComputedStyle(document.body).backgroundColor;ctx.fillRect(0,0,1,1);return {border:s.borderTopWidth,blur:s.backdropFilter,bg:[...ctx.getImageData(0,0,1,1).data].slice(0,3)}}''')
  self.assertEqual(s['border'],'0px');self.assertIn('blur',s['blur']);self.assertEqual(s['bg'],[0,0,0])
 def test_all_six_repository_previews_can_be_selected(self):
  self.assertEqual(self.page.locator('[data-showcase-channel]').count(),6)
  for channel in ['instagram','linkedin','threads','x','facebook','red']:
   self.page.locator(f'[data-showcase-channel="{channel}"]').click()
   expect(self.page.locator(f'#showcase-phone [data-native-platform="{channel}"]')).to_have_count(1)
  expect(self.page.locator('#channels-count')).to_have_text('3')
 def test_light_mode_is_available_and_preserves_input(self):
  self.assertEqual(self.page.locator('#theme-toggle').count(),1)
  self.page.locator('#idea').fill('Keep my work');self.page.locator('#theme-toggle').click()
  self.assertEqual(self.page.locator('html').get_attribute('data-appearance'),'light')
  expect(self.page.locator('#idea')).to_have_value('Keep my work')
 def test_expanded_phone_esc_restores_focus(self):
  self.assertEqual(self.page.locator('#showcase-expand').count(),1)
  self.page.locator('#showcase-expand').click();expect(self.page.locator('#phone-dialog')).to_be_visible()
  expect(self.page.locator('#expanded-phone .phone-scene[data-role="active"] .phone-device')).to_have_count(1)
  self.page.keyboard.press('Escape');expect(self.page.locator('#showcase-expand')).to_be_focused()
 def test_generated_caption_updates_phone_live(self):
  self.page.locator('#idea').fill('My unique creative thought');self.page.locator('#generate').click()
  expect(self.page.locator('#generation-status')).to_contain_text('3 of 3 ready',timeout=10000)
  self.assertEqual(self.page.locator('#result-phone .phone-scene[data-role="active"] .phone-device').count(),1)
  self.page.locator('#draft-editor').fill('New edited caption')
  expect(self.page.locator('#result-phone')).to_contain_text('New edited caption')
  self.page.locator('[data-draft="threads"]').click()
  expect(self.page.locator('#result-phone [data-native-platform="threads"]')).to_have_count(1)
 def test_media_toggle_does_not_invent_uploaded_images(self):
  self.assertEqual(self.page.locator('#showcase-artwork').count(),1)
  self.page.locator('#showcase-artwork').uncheck()
  expect(self.page.locator('#showcase-phone .native-art')).to_have_count(0)
  expect(self.page.locator('#showcase-phone')).to_contain_text('photo or video')
 def test_no_active_markup_in_phone(self):
  self.page.locator('#idea').fill('<img src=x onerror="window.bad=true">');self.page.locator('#generate').click()
  expect(self.page.locator('#generation-status')).to_contain_text('3 of 3 ready',timeout=10000)
  self.assertEqual(self.page.locator('#result-phone').count(),1);self.assertIsNone(self.page.evaluate('window.bad'))
  expect(self.page.locator('#result-phone img')).to_have_count(0)
 def test_phone_and_expanded_view_fit_320_390_768(self):
  self.assertEqual(self.page.locator('#showcase-expand').count(),1)
  for width in [320,390,768]:
   self.page.set_viewport_size({'width':width,'height':844});self.page.wait_for_timeout(100)
   self.assertLessEqual(self.page.evaluate('document.documentElement.scrollWidth'),width)
   self.page.locator('#showcase-expand').click();self.page.wait_for_timeout(100)
   box=self.page.locator('#expanded-phone .phone-scene[data-role="active"] .device-shell').bounding_box()
   self.assertGreaterEqual(box['x'],0);self.assertLessEqual(box['x']+box['width'],width+1)
   self.page.keyboard.press('Escape')
 def test_carousel_pager_updates_both_phone_views(self):
  self.page.locator('#format-trigger').click();self.page.locator('[data-taxonomy-tab="native"]').click();self.page.locator('[data-taxonomy-item="carousel"]').click();self.page.locator('#apply-taxonomy').click()
  expect(self.page.locator('#showcase-page-controls')).to_be_visible()
  self.page.locator('#showcase-next').click()
  expect(self.page.locator('#showcase-phone .phone-scene[data-role="active"] .native-page')).to_have_text('2 / 4')
  self.page.locator('#showcase-expand').click();self.page.locator('#expanded-next').click()
  expect(self.page.locator('#expanded-phone .phone-scene[data-role="active"] .native-page')).to_have_text('3 / 4')
  self.page.keyboard.press('Escape')
  expect(self.page.locator('#showcase-phone .phone-scene[data-role="active"] .native-page')).to_have_text('3 / 4')
 def test_all_six_generated_phones_are_available_in_expanded_view(self):
  self.page.locator('#channels-trigger').click()
  for channel in ['x','facebook','red']:self.page.locator(f'[data-channel="{channel}"]').click()
  self.page.locator('#channel-done').click()
  self.page.locator('#idea').fill('Six destinations, one idea');self.page.locator('#generate').click()
  expect(self.page.locator('#generation-status')).to_contain_text('6 of 6 ready',timeout=12000)
  self.page.locator('#result-expand').click()
  for channel in ['instagram','linkedin','threads','x','facebook','red']:
   self.page.locator(f'[data-expanded-channel="{channel}"]').click()
   expect(self.page.locator(f'#expanded-phone [data-native-platform="{channel}"]')).to_have_count(1)
   expect(self.page.locator(f'#result-phone [data-native-platform="{channel}"]')).to_have_count(1)
  self.page.keyboard.press('Escape');expect(self.page.locator('#result-expand')).to_be_focused()
 def test_video_script_never_displays_a_rendered_sample_video(self):
  self.page.locator('#format-trigger').click();self.page.locator('[data-taxonomy-tab="native"]').click();self.page.locator('[data-taxonomy-item="short_vertical_video"]').click();self.page.locator('#apply-taxonomy').click()
  expect(self.page.locator('#showcase-artwork')).to_be_disabled()
  expect(self.page.locator('#showcase-phone')).to_contain_text('Video script only')
  expect(self.page.locator('#showcase-phone .native-art')).to_have_count(0)
 def test_light_mode_glass_panels_are_borderless(self):
  self.page.locator('#theme-toggle').click();self.page.locator('#channels-trigger').click()
  for selector in ['#channel-dialog','.channel-tile-inner','.search-row']:
   s=self.page.locator(selector).first.evaluate('(e)=>({border:getComputedStyle(e).borderTopWidth,blur:getComputedStyle(e).backdropFilter})')
   self.assertEqual(s['border'],'0px');self.assertIn('blur',s['blur'])
 def test_expanded_view_keyboard_focus_stays_in_modal(self):
  self.page.locator('#showcase-expand').click()
  for _ in range(12):
   self.page.keyboard.press('Tab')
   self.assertTrue(self.page.evaluate("!!document.activeElement.closest('#phone-dialog')"))
if __name__=='__main__':unittest.main(verbosity=2)
