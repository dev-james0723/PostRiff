"""v5 regressions run on the bundled HTML; touch tests include CDP-generated touch events."""
import os, shutil, unittest
from pathlib import Path
from playwright.sync_api import sync_playwright, expect
ROOT=Path(__file__).resolve().parents[1]
TARGET=Path(os.environ.get('RAFII_HTML',str(ROOT/'index.html')))
class V5Tests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.p=sync_playwright().start();cls.browser=cls.p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox'])
 @classmethod
 def tearDownClass(cls):cls.browser.close();cls.p.stop()
 def setUp(self):
  self.context=self.browser.new_context(viewport={'width':430,'height':932},has_touch=True,is_mobile=True)
  self.page=self.context.new_page();self.errors=[];self.page.on('pageerror',lambda e:self.errors.append(str(e)))
  self.page.set_content(TARGET.read_text(),wait_until='load');self.page.set_default_timeout(1800)
 def tearDown(self):
  self.context.close();self.assertEqual(self.errors,[])
 def click(self,s):self.page.locator(s).evaluate('e=>e.click()')
 def swipe(self,sel,dx=-130,dy=3,real=False):
  loc=self.page.locator(sel);loc.scroll_into_view_if_needed();self.page.wait_for_timeout(80)
  if real:
   box=loc.bounding_box();x=box['x']+box['width']*.65 if dx<0 else box['x']+box['width']*.3;y=box['y']+min(box['height']*.4,180)
   cdp=self.context.new_cdp_session(self.page)
   cdp.send('Input.dispatchTouchEvent',{'type':'touchStart','touchPoints':[{'x':x,'y':y}]})
   for n in range(1,9):
    cdp.send('Input.dispatchTouchEvent',{'type':'touchMove','touchPoints':[{'x':x+dx*n/8,'y':y+dy*n/8}]});self.page.wait_for_timeout(16)
   cdp.send('Input.dispatchTouchEvent',{'type':'touchEnd','touchPoints':[]});cdp.detach()
  else:
   loc.evaluate('''(el,args)=>{const [dx,dy]=args;let opts={bubbles:true,pointerId:51,pointerType:'touch',isPrimary:true,clientX:220,clientY:240};el.dispatchEvent(new PointerEvent('pointerdown',opts));el.dispatchEvent(new PointerEvent('pointermove',{...opts,clientX:220+dx/2,clientY:240+dy/2}));el.dispatchEvent(new PointerEvent('pointermove',{...opts,clientX:220+dx,clientY:240+dy}));el.dispatchEvent(new PointerEvent('pointerup',{...opts,clientX:220+dx,clientY:240+dy}));}''',[dx,dy])
 def test_swipe_selects_next_and_previous_showcase(self):
  self.swipe('#showcase-phone');expect(self.page.locator('#showcase-phone')).to_have_attribute('data-active-phone','linkedin')
  self.swipe('#showcase-phone',130);expect(self.page.locator('#showcase-phone')).to_have_attribute('data-active-phone','instagram')
 def test_real_touch_preserves_crossfade(self):
  self.swipe('#showcase-phone',real=True)
  expect(self.page.locator('#showcase-phone')).to_have_attribute('data-active-phone','linkedin')
  self.assertGreater(self.page.locator('#showcase-phone').evaluate('e=>e.getAnimations({subtree:true}).length'),0)
 def test_vertical_and_short_swipes_do_not_switch(self):
  self.swipe('#showcase-phone',4,110);self.swipe('#showcase-phone',12,3)
  expect(self.page.locator('#showcase-phone')).to_have_attribute('data-active-phone','instagram')
 def test_model_has_provider_rail_search_and_thinking(self):
  self.click('#model-trigger')
  self.assertGreaterEqual(self.page.locator('[data-provider]').count(),5)
  expect(self.page.locator('#model-search')).to_be_visible()
  self.click('[data-provider="xai"]');self.click('[data-model-choice="grok-reference-46"]')
  expect(self.page.locator('#thinking-options button')).to_have_count(4)
 def test_output_target_is_above_channel_rows(self):
  self.click('#language-trigger');self.page.wait_for_timeout(500)
  top=self.page.locator('#language-target-label').bounding_box()['y']
  row=self.page.locator('#channel-language-list').bounding_box()['y']
  self.assertLess(top,row)
 def test_shared_toggle_reveals_picker_inside_same_card(self):
  self.click('#language-trigger')
  self.assertEqual(self.page.locator('#shared-language-box #shared-language-content').count(),1)
  self.assertEqual(self.page.locator('#shared-language-content').evaluate('e=>e.getBoundingClientRect().height'),0)
  self.page.locator('#same-language-toggle').check();self.page.wait_for_timeout(500)
  self.assertGreater(self.page.locator('#shared-language-content').evaluate('e=>e.getBoundingClientRect().height'),100)
  expect(self.page.locator('#shared-language-content')).to_contain_text('Select a language for every channel')
  expect(self.page.locator('#save-language')).to_be_disabled()
 def test_repo_catalogue_search_has_cantonese_and_more_languages(self):
  self.click('#language-trigger')
  self.assertGreaterEqual(self.page.evaluate('RafiiLocales.entries.length'),180)
  self.click('#individual-language-button')
  self.page.locator('#locale-search').fill('cantonese')
  expect(self.page.locator('#locale-results')).to_contain_text('廣東話（香港）')
 def test_shared_picker_starts_with_no_language_preselected(self):
  self.click('#language-trigger');self.page.locator('#same-language-toggle').check()
  self.assertEqual(self.page.locator('#locale-results [aria-selected="true"]').count(),0)
 def test_suggested_list_has_no_duplicate_options(self):
  self.click('#language-trigger');self.click('#individual-language-button')
  tags=self.page.locator('#locale-results section').first.locator('[data-language-choice]').evaluate_all('els=>els.map(e=>e.dataset.languageChoice)')
  self.assertEqual(len(tags),len(set(tags)))
 def ready(self):
  self.page.locator('#idea').fill('My original idea must remain unchanged.')
  self.click('#generate');expect(self.page.locator('#generation-status')).to_contain_text('3 of 3 ready',timeout=5500)
  self.page.wait_for_timeout(600)
 def choose_language(self,query,tag):
  self.page.locator('#locale-search').fill(query)
  self.click(f'[data-language-choice="{tag}"]')
 def test_real_swipe_generated_draft_preserves_edits_and_destinations(self):
  self.ready();self.page.locator('#draft-editor').fill('Edited Instagram draft.')
  self.swipe('#result-phone',real=True)
  expect(self.page.locator('#result-phone')).to_have_attribute('data-active-phone','linkedin')
  self.page.wait_for_timeout(650);self.swipe('#result-phone',130,real=True)
  expect(self.page.locator('#draft-editor')).to_have_value('Edited Instagram draft.')
  expect(self.page.locator('#channels-count')).to_have_text('3')
 def test_real_swipe_in_enlarged_preview(self):
  self.click('#showcase-expand');self.page.wait_for_timeout(650)
  self.swipe('#expanded-phone',real=True)
  expect(self.page.locator('#expanded-phone')).to_have_attribute('data-active-phone','linkedin')
  expect(self.page.locator('#showcase-phone')).to_have_attribute('data-active-phone','linkedin')
 def test_enlarged_result_swipe_only_uses_ready_selected_channels(self):
  self.ready();self.click('#result-expand');self.page.wait_for_timeout(650)
  self.swipe('#expanded-phone',130)
  expect(self.page.locator('#expanded-phone')).to_have_attribute('data-active-phone','threads')
  expect(self.page.locator('#result-phone')).to_have_attribute('data-active-phone','threads')
 def test_rapid_swipe_sequence_keeps_single_active_phone(self):
  for _ in range(5):self.swipe('#showcase-phone')
  self.page.wait_for_timeout(700)
  expect(self.page.locator('#showcase-phone')).to_have_attribute('data-active-phone','red')
  expect(self.page.locator('#showcase-phone .phone-scene')).to_have_count(3)
  expect(self.page.locator('#showcase-phone .phone-scene[data-role="active"]')).to_have_count(1)
 def test_real_vertical_touch_scrolls_feed_not_apps(self):
  self.page.locator('#idea').fill(('A long original paragraph. '+ '\n')*50)
  self.click('[data-showcase-channel="red"]');self.page.wait_for_timeout(650)
  feed=self.page.locator('#showcase-phone .phone-scene[data-role="active"] .native-feed')
  self.assertGreater(feed.evaluate('e=>e.scrollHeight'),feed.evaluate('e=>e.clientHeight'))
  before=feed.evaluate('e=>e.scrollTop')
  self.swipe('#showcase-phone',2,-145,real=True);self.page.wait_for_timeout(100)
  expect(self.page.locator('#showcase-phone')).to_have_attribute('data-active-phone','red')
  self.assertGreater(feed.evaluate('e=>e.scrollTop'),before)
 def test_pointer_cancel_and_two_fingers_do_not_select_next_app(self):
  self.page.locator('#showcase-phone').evaluate("""e=>{const o={bubbles:true,pointerType:'touch',isPrimary:true,pointerId:81,clientX:220,clientY:240};e.dispatchEvent(new PointerEvent('pointerdown',o));e.dispatchEvent(new PointerEvent('pointermove',{...o,clientX:130}));e.dispatchEvent(new PointerEvent('pointercancel',o));e.dispatchEvent(new PointerEvent('pointerup',{...o,clientX:60}));e.dispatchEvent(new PointerEvent('pointerdown',o));e.dispatchEvent(new PointerEvent('pointerdown',{...o,pointerId:82,isPrimary:false}));e.dispatchEvent(new PointerEvent('pointermove',{...o,clientX:80}));e.dispatchEvent(new PointerEvent('pointerup',{...o,clientX:80}));e.dispatchEvent(new PointerEvent('pointerup',{...o,pointerId:82,isPrimary:false}));}""")
  expect(self.page.locator('#showcase-phone')).to_have_attribute('data-active-phone','instagram')
  self.swipe('#showcase-phone');expect(self.page.locator('#showcase-phone')).to_have_attribute('data-active-phone','linkedin')
 def test_swipe_still_works_when_motion_reduced(self):
  self.page.emulate_media(reduced_motion='reduce');self.swipe('#showcase-phone',real=True)
  expect(self.page.locator('#showcase-phone')).to_have_attribute('data-active-phone','linkedin')
  self.assertEqual(self.page.locator('#showcase-phone').evaluate('e=>e.getAnimations({subtree:true}).length'),0)
 def test_shared_language_selection_apply_reopen_and_restore(self):
  self.page.emulate_media(reduced_motion='reduce');self.click('#language-trigger')
  self.click('[data-channel-language="instagram"]');self.choose_language('Japanese','ja-jp')
  self.page.locator('#same-language-toggle').check();self.choose_language('cantonese','yue-hant-hk')
  expect(self.page.locator('[data-channel-language="instagram"]')).to_contain_text('廣東話')
  expect(self.page.locator('[data-channel-language="linkedin"]')).to_contain_text('廣東話')
  self.click('#save-language');self.click('#language-trigger')
  expect(self.page.locator('#same-language-toggle')).to_be_checked()
  self.page.locator('#same-language-toggle').uncheck()
  expect(self.page.locator('[data-channel-language="instagram"]')).to_contain_text('日本語')
  expect(self.page.locator('[data-channel-language="linkedin"]')).to_contain_text('English')
  self.click('#save-language');expect(self.page.locator('#language-summary')).to_contain_text('Per channel')
 def test_cancel_discards_pending_shared_and_individual_changes(self):
  self.page.emulate_media(reduced_motion='reduce');self.click('#language-trigger')
  self.click('[data-channel-language="instagram"]');self.choose_language('Japanese','ja-jp')
  self.page.locator('#same-language-toggle').check();self.choose_language('fr-FR','fr-fr')
  self.page.keyboard.press('Escape');self.click('#language-trigger')
  expect(self.page.locator('#same-language-toggle')).not_to_be_checked()
  expect(self.page.locator('[data-channel-language="instagram"]')).to_contain_text('English')
 def test_shared_box_animates_through_intermediate_height(self):
  self.click('#language-trigger');self.page.wait_for_timeout(600)
  self.page.locator('#same-language-toggle').evaluate('e=>e.click()')
  heights=self.page.locator('#shared-language-content').evaluate('''e=>new Promise(resolve=>{const h=[],start=performance.now();function frame(t){h.push(e.getBoundingClientRect().height);if(t-start>900)resolve(h);else requestAnimationFrame(frame);}requestAnimationFrame(frame);})''')
  self.assertGreater(heights[-1],100);self.assertTrue(any(0<h<heights[-1]-.5 for h in heights),str(heights))
 def test_keyboard_search_enter_selects_and_escape_collapses_only_list(self):
  self.click('#language-trigger');self.click('#individual-language-button')
  self.page.locator('#locale-search').fill('cantonese');self.page.keyboard.press('Enter')
  expect(self.page.locator('#individual-language-button')).to_contain_text('廣東話')
  self.click('#individual-language-button');self.page.locator('#locale-search').focus();self.page.keyboard.press('Escape')
  expect(self.page.locator('#locale-catalog')).to_be_hidden();expect(self.page.locator('#language-dialog')).to_be_visible()
 def test_arabic_rtl_native_name_and_recent_pick_preserved(self):
  self.click('#language-trigger');self.click('#individual-language-button');self.page.locator('#locale-search').fill('ar-EG')
  expect(self.page.locator('[data-language-choice="ar-eg"] .locale-names strong')).to_have_attribute('dir','rtl')
  self.click('[data-language-choice="ar-eg"]');self.click('#individual-language-button')
  expect(self.page.locator('#locale-results section[aria-label="Recent"]')).to_contain_text('مصر')
 def test_no_language_match_is_safe_and_clear_recovers_all_groups(self):
  self.click('#language-trigger');self.click('#individual-language-button')
  self.page.locator('#locale-search').fill('<img src=x onerror=alert(1)>')
  expect(self.page.locator('#locale-results')).to_contain_text('No language matches')
  self.assertEqual(self.page.locator('#locale-results img').count(),0)
  self.click('#clear-locale-search');expect(self.page.locator('#locale-results')).to_contain_text('Chinese')
 def test_model_thinking_is_saved_and_cancel_does_not_override(self):
  self.page.emulate_media(reduced_motion='reduce');self.click('#model-trigger')
  self.click('[data-provider="xai"]');self.click('[data-model-choice="grok-reference-46"]');self.click('[data-thinking="max"]');self.click('#save-model')
  expect(self.page.locator('#model-summary')).to_contain_text('Grok 4.6')
  self.click('#model-trigger');expect(self.page.locator('[data-thinking="max"]')).to_have_attribute('aria-pressed','true')
  self.click('[data-thinking="low"]');self.page.keyboard.press('Escape');self.click('#model-trigger')
  expect(self.page.locator('[data-thinking="max"]')).to_have_attribute('aria-pressed','true')
 def test_model_search_crosses_provider_and_cli_mode_selects(self):
  self.page.emulate_media(reduced_motion='reduce');self.click('#model-trigger')
  self.page.locator('#model-search').fill('Sonnet');expect(self.page.locator('#model-options')).to_contain_text('Claude Sonnet')
  self.click('[data-model-choice="claude-sonnet"]');self.click('#clear-model-search');self.click('[data-model-mode="cli"]')
  expect(self.page.locator('#provider-cli')).to_have_attribute('aria-selected','true')
  self.click('[data-model-choice="api-cli"]');self.click('#save-model')
  expect(self.page.locator('#model-summary')).to_contain_text('API Model CLI')
 def test_model_search_has_safe_empty_state(self):
  self.click('#model-trigger');self.page.locator('#model-search').fill('<img onerror=alert(1)>')
  expect(self.page.locator('#model-options')).to_contain_text('No models found')
  self.click('#clear-model-search');self.assertGreater(self.page.locator('[data-model-choice]').count(),0)
if __name__=='__main__':unittest.main(verbosity=2)
