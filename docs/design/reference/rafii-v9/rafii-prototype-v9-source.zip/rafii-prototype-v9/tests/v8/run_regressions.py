"""Run retained suites against the rebuilt v8 artifact; preserve stdout and failures."""
import subprocess,sys,json,time,concurrent.futures
from pathlib import Path
R=Path(__file__).resolve().parents[2];O=R/'tests/v8'
suites=['tests/browser_test.py','tests/update_test.py','tests/refinement_test.py','tests/v5_test.py','tests/v6/test_v6.py','tests/v7/test_v7.py']
def run(rel):
 start=time.monotonic()
 with (O/(Path(rel).stem+'-full.txt')).open('w') as f:
  try:
   result=subprocess.run([sys.executable,str(R/rel)],cwd=R,stdout=f,stderr=subprocess.STDOUT,timeout=210)
   return rel,{'exit_code':result.returncode,'seconds':round(time.monotonic()-start,2)}
  except subprocess.TimeoutExpired:
   return rel,{'exit_code':'timeout','seconds':round(time.monotonic()-start,2)}
results={}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 for rel,result in pool.map(run,suites):
  results[rel]=result;(O/'regressions.json').write_text(json.dumps(results,indent=2));print(rel,result,flush=True)
print('DONE',flush=True)
