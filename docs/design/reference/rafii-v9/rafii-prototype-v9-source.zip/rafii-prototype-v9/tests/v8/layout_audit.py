"""Responsive control grouping, select geometry and non-overflow audit."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import json
R=Path(__file__).resolve().parents[2];O=R/'tests/v8';html=(R/'index.html').read_text();records=[]
sizes=[(320,740),(375,812),(390,844),(430,932),(768,1024),(1024,768),(1440,1000),(1920,1080)]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 for w,h in sizes:
  pg=b.new_page(viewport={'width':w,'height':h},reduced_motion='reduce');errors=[];requests=[]
  pg.on('pageerror',lambda e:errors.append(str(e)));pg.on('request',lambda r:requests.append(r.url));pg.set_content(html);pg.locator('#format-trigger').click()
  for theme in ['dark','light']:
   pg.evaluate('(x)=>document.documentElement.dataset.appearance=x',theme)
   for dimension,count in [('editorial',31),('native',20)]:
    pg.locator('[data-taxonomy-tab="'+dimension+'"]').click()
    for view in ['gallery','list','pairings']:
     pg.locator('[data-library-view="'+view+'"]').click()
     geometry=pg.evaluate('''()=>{const d=document.querySelector('#format-dialog'),p=document.querySelector('#taxonomy-panel'),r=d.getBoundingClientRect(),footer=document.querySelector('.taxonomy-footer').getBoundingClientRect(),head=document.querySelector('.taxonomy-head').getBoundingClientRect();return {dialog:{left:r.left,right:r.right,top:r.top,bottom:r.bottom},overflow:p.scrollWidth-p.clientWidth,header:head.height,footer:footer.height,body:p.clientHeight,items:document.querySelectorAll('.library-current [data-taxonomy-item]').length,rows:[...document.querySelectorAll('[data-library-view],#library-filter-trigger')].map(e=>e.getBoundingClientRect().height)}}''')
     ok=geometry['dialog']['left']>=-.5 and geometry['dialog']['right']<=w+.5 and geometry['dialog']['top']>=-.5 and geometry['dialog']['bottom']<=h+.5 and geometry['overflow']<=1 and geometry['items']==count and min(geometry['rows'])>=44 and max(geometry['rows'])-min(geometry['rows'])<=1 and geometry['body']>=170
     records.append({'size':[w,h],'theme':theme,'dimension':dimension,'view':view,'ok':ok,'geometry':geometry})
   pg.locator('#library-filter-trigger').click();bounds=pg.locator('#library-filter-panel').bounding_box()
   fields=pg.locator('#library-category,#library-platform').evaluate_all('es=>es.map(e=>({w:e.getBoundingClientRect().width,h:e.getBoundingClientRect().height}))')
   records.append({'size':[w,h],'theme':theme,'view':'filters','ok':bounds['x']>=0 and bounds['y']>=0 and bounds['x']+bounds['width']<=w+.5 and bounds['y']+bounds['height']<=h+.5 and min(f['h'] for f in fields)>=44 and abs(fields[0]['h']-fields[1]['h'])<1,'geometry':{'panel':bounds,'fields':fields}})
   if w in [390,1440] and theme=='light':pg.screenshot(path=str(R/'previews-v8'/f'{w}-light-filters.png'))
   pg.locator('#close-library-filters').click()
  records.append({'size':[w,h],'view':'runtime','ok':not errors and not requests,'errors':errors,'requests':requests})
  pg.close();(O/'layout-results.json').write_text(json.dumps(records,indent=2));print(w,h,flush=True)
 b.close()
print('CHECKS',len(records),'FAILED',len([r for r in records if not r['ok']]),flush=True)
if any(not r['ok'] for r in records):raise SystemExit(1)
