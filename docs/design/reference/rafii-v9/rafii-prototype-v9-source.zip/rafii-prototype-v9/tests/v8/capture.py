from pathlib import Path
from playwright.sync_api import sync_playwright,expect
import json
R=Path(__file__).resolve().parents[2];O=R/'previews-v8';O.mkdir(exist_ok=True)
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 metrics={}
 for name,w,h in [('mobile',390,844),('small',320,740),('desktop',1440,1000)]:
  pg=b.new_page(viewport={'width':w,'height':h},device_scale_factor=1)
  pg.set_content((R/'index.html').read_text());pg.locator('#format-trigger').click();pg.wait_for_timeout(650)
  pg.screenshot(path=str(O/f'{name}-gallery.png'))
  metrics[name]={s:pg.locator(s).bounding_box() for s in ['.taxonomy-head','#taxonomy-panel','.taxonomy-footer']}
  pg.locator('#library-filter-trigger').click();pg.wait_for_timeout(360)
  pg.screenshot(path=str(O/f'{name}-filters.png'))
  pg.locator('#library-category').select_option('education');pg.locator('#close-library-filters').click();pg.wait_for_timeout(410)
  pg.locator('[data-library-view="list"]').click();pg.wait_for_timeout(430);pg.screenshot(path=str(O/f'{name}-list.png'))
  pg.locator('[data-info="how_to"]').click();pg.wait_for_timeout(350);pg.screenshot(path=str(O/f'{name}-tooltip.png'));pg.keyboard.press('Escape');pg.wait_for_timeout(180)
  pg.locator('[data-library-view="pairings"]').click();pg.wait_for_timeout(450);pg.screenshot(path=str(O/f'{name}-pairings.png'))
  pg.evaluate("document.documentElement.dataset.appearance='light'");pg.wait_for_timeout(220)
  pg.screenshot(path=str(O/f'{name}-light-pairings.png'));pg.close()
 # same viewport baseline; comparison holds actual content, not a generated redesign.
 pg=b.new_page(viewport={'width':390,'height':844});pg.set_content(Path('/mnt/data/rafii-prototype-v7.html').read_text());pg.locator('#format-trigger').click();pg.wait_for_timeout(650);pg.screenshot(path=str(O/'mobile-v7-before.png'))
 metrics['before']={s:pg.locator(s).bounding_box() for s in ['.taxonomy-head','#taxonomy-panel','.taxonomy-footer']}
 (R/'tests/v8/geometry.json').write_text(json.dumps(metrics,indent=2));b.close()
print(json.dumps(metrics,indent=2))
