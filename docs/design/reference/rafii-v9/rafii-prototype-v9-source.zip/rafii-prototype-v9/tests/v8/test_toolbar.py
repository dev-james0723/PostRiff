"""Acceptance tests for the library-toolbar reorganization. Actual browser geometry."""
import os, unittest, shutil
from pathlib import Path
from playwright.sync_api import sync_playwright, expect
ROOT=Path(__file__).resolve().parents[2]
TARGET=Path(os.environ.get('RAFII_HTML',ROOT/'index.html'))
class ToolbarTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.p=sync_playwright().start();cls.browser=cls.p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox'])
 @classmethod
 def tearDownClass(cls):cls.browser.close();cls.p.stop()
 def setUp(self):
  self.page=self.browser.new_page(viewport={'width':390,'height':844},reduced_motion='reduce');self.errors=[]
  self.page.on('pageerror',lambda e:self.errors.append(str(e)));self.page.set_content(TARGET.read_text());self.page.set_default_timeout(2000)
  self.page.locator('#format-trigger').click()
 def tearDown(self):
  self.page.close();self.assertEqual(self.errors,[])
 def filters(self):
  self.assertEqual(self.page.locator('#library-filter-trigger').count(),1,'One discoverable Filters button is required')
  self.page.locator('#library-filter-trigger').click()
 def test_compact_header_leaves_room_for_content(self):
  self.assertLessEqual(self.page.locator('.taxonomy-head').bounding_box()['height'],260)
  self.assertGreaterEqual(self.page.locator('#taxonomy-panel').bounding_box()['height'],390)
 def test_footer_is_compact_and_one_primary_action(self):
  self.assertLessEqual(self.page.locator('.taxonomy-footer').bounding_box()['height'],145)
  self.assertEqual(self.page.locator('.taxonomy-footer .dialog-primary:visible').count(),1)
 def test_view_controls_and_filters_share_height(self):
  self.assertEqual(self.page.locator('#library-filter-trigger').count(),1)
  heights=self.page.locator('[data-library-view],#library-filter-trigger').evaluate_all('es=>es.map(e=>e.getBoundingClientRect().height)')
  self.assertGreaterEqual(min(heights),44)
  self.assertLessEqual(max(heights)-min(heights),1)
 def test_secondary_settings_not_scattered_on_home(self):
  self.assertFalse(self.page.locator('#library-platform').is_visible())
  self.assertFalse(self.page.locator('#library-category').is_visible())
  self.assertFalse(self.page.locator('#art-motion-toggle').is_visible())
 def test_filter_panel_has_matched_fields_and_explicit_motion_label(self):
  self.filters()
  expect(self.page.locator('#library-platform')).to_be_visible();expect(self.page.locator('#library-category')).to_be_visible()
  a=self.page.locator('#library-platform').bounding_box();b=self.page.locator('#library-category').bounding_box()
  self.assertAlmostEqual(a['height'],b['height'],delta=1);self.assertGreaterEqual(a['height'],44)
  expect(self.page.locator('#art-motion-toggle')).to_contain_text('Pause artwork')
 def test_filters_keep_selection_and_count_then_clear(self):
  before=self.page.locator('#taxonomy-selection').inner_text();self.filters()
  self.page.locator('#library-category').select_option('everyday');self.page.locator('#library-platform').select_option('instagram')
  self.page.locator('#close-library-filters').click()
  expect(self.page.locator('#library-filter-trigger')).to_contain_text('2')
  expect(self.page.locator('#active-library-filters')).to_contain_text('Everyday')
  self.assertEqual(self.page.locator('#taxonomy-selection').inner_text(),before)
  self.page.locator('#clear-active-library-filters').click()
  self.assertEqual(self.page.locator('.library-current [data-taxonomy-item]').count(),31)
  expect(self.page.locator('#active-library-filters')).not_to_be_visible()
 def test_filter_escape_returns_focus_without_closing_library(self):
  self.filters();self.page.keyboard.press('Escape')
  expect(self.page.locator('#library-filter-layer')).not_to_be_visible()
  expect(self.page.locator('#format-dialog')).to_be_visible();expect(self.page.locator('#library-filter-trigger')).to_be_focused()
 def test_filter_panel_focus_is_contained(self):
  self.filters();buttons=self.page.locator('#library-filter-layer button:visible');buttons.last.focus();self.page.keyboard.press('Tab')
  self.assertTrue(self.page.evaluate("!!document.activeElement.closest('#library-filter-layer')"))
 def test_list_pairings_and_selection_stay_functional(self):
  self.page.locator('[data-library-view="list"]').click();self.page.locator('[data-taxonomy-item="announcement"]').click()
  self.page.locator('[data-library-view="pairings"]').click();expect(self.page.locator('#taxonomy-selection')).to_contain_text('Announcement')
  self.page.locator('[data-taxonomy-tab="native"]').click();self.page.locator('[data-library-view="list"]').click()
  self.page.locator('[data-taxonomy-item="carousel"]').click();self.page.locator('#apply-taxonomy').click()
  expect(self.page.locator('#format-label')).to_contain_text('Carousel')
 def test_inactive_cards_do_not_show_selection_badges(self):
  cards=self.page.locator('.library-current .taxonomy-card[aria-pressed="false"] .taxonomy-check')
  self.assertTrue(all(o=='0' for o in cards.evaluate_all('es=>es.map(e=>getComputedStyle(e).opacity)')))
if __name__=='__main__':unittest.main(verbosity=2)
