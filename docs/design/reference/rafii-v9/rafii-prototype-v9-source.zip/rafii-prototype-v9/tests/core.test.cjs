const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const file = path.join(__dirname,'../src/core.js');
const C = fs.existsSync(file) ? require(file) : {};
function feature(name) { assert.equal(typeof C[name], 'function', `${name} must be implemented`); }

test('toggles independent channel selection without changing the input', () => {
  feature('toggleChannel'); const before=['instagram','linkedin'];
  assert.deepEqual(C.toggleChannel(before,'threads'), ['instagram','linkedin','threads']);
  assert.deepEqual(C.toggleChannel(before,'instagram'), ['linkedin']);
  assert.deepEqual(before,['instagram','linkedin']);
});
test('does not allow unknown channels into selected accounts', () => {
  feature('toggleChannel'); assert.deepEqual(C.toggleChannel(['instagram'],'unknown'), ['instagram']);
});
test('three selected channels do not show a misleading overflow badge', () => {
  feature('selectionSummary');
  assert.deepEqual(C.selectionSummary(['instagram','linkedin','threads']), {count:3, visible:['instagram','linkedin','threads'], overflow:0});
});
test('overflow reflects additional selected accounts, not available accounts', () => {
  feature('selectionSummary'); const s=C.selectionSummary(['instagram','linkedin','threads','x','facebook']);
  assert.equal(s.count,5); assert.equal(s.overflow,2); assert.equal(s.visible.length,3);
});
test('selection summary deduplicates and filters unknown account IDs', () => {
  feature('selectionSummary'); assert.equal(C.selectionSummary(['instagram','instagram','bogus']).count,1);
});
test('blank and oversized ideas cannot be generated', () => {
  feature('validate'); assert.equal(C.validate('   ',['instagram']).ok,false);
  assert.equal(C.validate('a'.repeat(2001),['instagram']).ok,false);
});
test('zero channels cannot be generated and a valid idea can', () => {
  feature('validate'); assert.equal(C.validate('An idea',[]).ok,false);
  assert.equal(C.validate('An idea',['threads']).ok,true);
});
test('generation takes an immutable snapshot of the selected channels', () => {
  feature('makeRequest'); const channels=['instagram'];
  const r=C.makeRequest({idea:'  A small idea  ',channels,format:'post',tone:'warm',language:'en'});
  channels.push('threads'); assert.deepEqual(r.channels,['instagram']); assert.equal(r.idea,'A small idea');
  assert.ok(Object.isFrozen(r)); assert.ok(Object.isFrozen(r.channels));
});
test('invalid format is rejected rather than silently changed', () => {
  feature('makeRequest'); assert.throws(()=>C.makeRequest({idea:'Idea',channels:['instagram'],format:'unsupported'}));
});
test('sample draft retains the user idea and is marked as a simulation', () => {
  feature('sampleDraft'); feature('makeRequest');
  const r=C.makeRequest({idea:'My original sentence.',channels:['linkedin'],format:'post',tone:'neutral',language:'en'});
  const d=C.sampleDraft(r,'linkedin'); assert.ok(d.text.includes('My original sentence.')); assert.equal(d.simulated,true);
});
test('all four formats create distinguishable template previews', () => {
  feature('sampleDraft'); feature('makeRequest');
  const output=['post','thread','carousel','video'].map(format=>C.sampleDraft(C.makeRequest({idea:'An idea',channels:['instagram'],format,tone:'neutral',language:'en'}),'instagram').text);
  assert.equal(new Set(output).size,4); assert.match(output[2],/Slide 1/); assert.match(output[3],/00:00/);
});
test('traditional Chinese template does not pretend to translate the idea', () => {
  feature('sampleDraft'); feature('makeRequest');
  const d=C.sampleDraft(C.makeRequest({idea:'Original English idea.',channels:['threads'],format:'thread',language:'zh',tone:'neutral'}),'threads');
  assert.ok(d.text.includes('Original English idea.')); assert.ok(d.note.includes('not translated'));
});
test('HTML-looking text is preserved as text, not stripped or executed', () => {
  feature('sampleDraft'); feature('makeRequest');
  const input='<img src=x onerror=alert(1)>';
  const d=C.sampleDraft(C.makeRequest({idea:input,channels:['threads'],format:'post'}),'threads');
  assert.ok(d.text.includes(input));
});
