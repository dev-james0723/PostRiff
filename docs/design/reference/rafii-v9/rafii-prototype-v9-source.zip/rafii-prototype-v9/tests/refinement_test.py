"""v4 black-box regressions: deduplicated controls and real phone transitions.
Use RAFII_HTML to replay against an older standalone build.
"""
import os, shutil, unittest
from pathlib import Path
from playwright.sync_api import sync_playwright, expect
ROOT=Path(__file__).resolve().parents[1]
TARGET=Path(os.environ.get('RAFII_HTML',str(ROOT/'index.html')))
class RefinementTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.p=sync_playwright().start();cls.browser=cls.p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox'])
 @classmethod
 def tearDownClass(cls):cls.browser.close();cls.p.stop()
 def setUp(self):
  self.context=self.browser.new_context(viewport={'width':1440,'height':1080},reduced_motion='no-preference')
  self.page=self.context.new_page();self.errors=[];self.page.on('pageerror',lambda e:self.errors.append(str(e)))
  self.page.set_content(TARGET.read_text(),wait_until='load');self.page.wait_for_timeout(80)
  self.page.set_default_timeout(2500)
 def tearDown(self):
  self.context.close();self.assertEqual(self.errors,[])
 def click_now(self,selector):self.page.eval_on_selector(selector,'e=>e.click()')
 def ready(self,count=3):
  self.page.locator('#idea').fill('A daily practice becomes a creative life.')
  self.click_now('#generate')
  expect(self.page.locator('#generation-status')).to_contain_text(f'{count} of {count} ready',timeout=8500)
  self.page.wait_for_timeout(650)
 def test_no_duplicate_tune_shortcut(self):
  expect(self.page.locator('.settings-buttons:visible button')).to_have_count(3)
  self.assertEqual(self.page.locator('#tune-trigger').count(),0,'Extra Tune shortcut duplicates Language')
  self.assertEqual(self.page.locator('#settings-summary').count(),0,'Full summary repeats all three setting buttons')
 def test_showcase_retains_outgoing_phone_during_switch(self):
  self.page.evaluate("window.oldPhone=document.querySelector('#showcase-phone .phone-device')")
  self.click_now('[data-showcase-channel="linkedin"]')
  self.assertTrue(self.page.evaluate('window.oldPhone.isConnected'),'Outgoing phone was destroyed instead of crossfading')
  self.assertGreater(self.page.locator('#showcase-phone').evaluate('(e)=>e.getAnimations({subtree:true}).length'),0)
 def test_generated_phone_has_real_overlap_animation(self):
  self.ready()
  self.page.evaluate("window.oldPhone=document.querySelector('#result-phone .phone-device')")
  self.click_now('[data-draft="linkedin"]')
  self.assertTrue(self.page.evaluate('window.oldPhone.isConnected'),'Generated phone swapped without any outgoing layer')
  self.assertGreater(self.page.locator('#result-phone').evaluate('(e)=>e.getAnimations({subtree:true}).length'),0)
 def test_completed_results_hide_duplicate_platform_flow(self):
  self.ready()
  expect(self.page.locator('.idea-flow')).to_be_hidden()
  expect(self.page.locator('.draft-tab:visible')).to_have_count(3)
 def test_expanded_phone_crossfade(self):
  self.click_now('#showcase-expand');self.page.wait_for_timeout(650)
  self.page.evaluate("window.oldPhone=document.querySelector('#expanded-phone .phone-device')")
  self.click_now('[data-expanded-channel="threads"]')
  self.assertTrue(self.page.evaluate('window.oldPhone.isConnected'))
  self.assertGreater(self.page.locator('#expanded-phone').evaluate('(e)=>e.getAnimations({subtree:true}).length'),0)
 def test_rapid_switches_end_on_last_platform_without_layers_piling_up(self):
  self.page.evaluate('''async()=>{for(const id of ['linkedin','threads','x','facebook','red','instagram','red']){document.querySelector(`[data-showcase-channel="${id}"]`).click();await new Promise(r=>setTimeout(r,45));}}''')
  self.page.wait_for_timeout(800)
  expect(self.page.locator('#showcase-phone .phone-scene[data-role="active"] [data-native-platform="red"]')).to_have_count(1)
  expect(self.page.locator('#showcase-phone .phone-scene')).to_have_count(3)
  self.assertEqual(self.page.locator('#showcase-phone').evaluate('(e)=>e.getAnimations({subtree:true}).length'),0)
 def test_reduced_motion_settles_immediately(self):
  self.page.emulate_media(reduced_motion='reduce')
  self.click_now('[data-showcase-channel="linkedin"]')
  expect(self.page.locator('#showcase-phone .phone-scene[data-role="active"] [data-native-platform="linkedin"]')).to_have_count(1)
  self.assertEqual(self.page.locator('#showcase-phone').evaluate('(e)=>e.getAnimations({subtree:true}).length'),0)
 def test_same_channel_and_typing_do_not_reanimate_phone(self):
  self.click_now('[data-showcase-channel="instagram"]')
  self.page.locator('#idea').fill('Typing must not flash the phone.')
  self.assertEqual(self.page.locator('#showcase-phone').evaluate('(e)=>e.getAnimations({subtree:true}).length'),0)
 def test_per_channel_flag_picker_and_shared_toggle_restore_individual_values(self):
  self.page.emulate_media(reduced_motion='reduce')
  self.click_now('#language-trigger')
  self.click_now('[data-channel-language="instagram"]')
  self.click_now('[data-language-choice="ja-jp"]')
  expect(self.page.locator('[data-channel-language="instagram"]')).to_contain_text('日本語')
  expect(self.page.locator('[data-channel-language="linkedin"]')).to_contain_text('English')
  self.page.locator('#same-language-toggle').check()
  self.click_now('[data-language-choice="zh-hant-hk"]')
  expect(self.page.locator('[data-channel-language="linkedin"]')).to_contain_text('繁體中文')
  self.page.locator('#same-language-toggle').uncheck()
  expect(self.page.locator('[data-channel-language="instagram"]')).to_contain_text('日本語')
  expect(self.page.locator('[data-channel-language="red"]')).to_contain_text('简体中文')
  self.click_now('#save-language');self.click_now('#language-trigger')
  expect(self.page.locator('[data-channel-language="instagram"]')).to_contain_text('日本語')
 def test_expanded_editor_keeps_work_and_three_controls_remain(self):
  self.page.emulate_media(reduced_motion='reduce')
  self.page.locator('#idea').fill('Keep my original')
  self.click_now('#expand-idea-trigger')
  self.page.locator('#idea-expanded').fill('Keep my edited thought')
  self.click_now('#apply-expanded-idea')
  expect(self.page.locator('#idea')).to_have_value('Keep my edited thought')
  expect(self.page.locator('.settings-buttons button:visible')).to_have_count(3)
 def test_phone_active_is_only_accessible_preview(self):
  self.assertEqual(self.page.locator('#showcase-phone .phone-scene[data-role="active"]').count(),1)
  for node in self.page.locator('#showcase-phone .phone-scene:not([data-role="active"])').all():
   self.assertEqual(node.get_attribute('aria-hidden'),'true');self.assertTrue(node.evaluate('e=>e.inert'))
 def test_mobile_six_platforms_fit_in_one_row(self):
  self.page.set_viewport_size({'width':390,'height':844})
  self.page.emulate_media(reduced_motion='reduce')
  self.click_now('#channels-trigger')
  for ch in ['x','facebook','red']:self.click_now(f'[data-channel="{ch}"]')
  self.click_now('#channel-done');self.ready(6)
  self.assertEqual(self.page.locator('.draft-tab:visible').count(),6)
  ys=[round(b.bounding_box()['y']) for b in self.page.locator('.draft-tab:visible').all()]
  self.assertEqual(len(set(ys)),1,'Platform selector wraps into repeated bulky rows')
  self.assertLessEqual(self.page.evaluate('document.documentElement.scrollWidth'),390)
 def test_outgoing_and_incoming_have_intermediate_opacity_at_same_time(self):
  self.click_now('[data-showcase-channel="linkedin"]');self.page.wait_for_timeout(180)
  values=self.page.locator('#showcase-phone').evaluate("""e=>{
   const incoming=e.querySelector('.phone-scene[data-role="active"]');
   const outgoing=e.querySelector('.phone-scene[data-phone-channel="instagram"]');
   return {incoming:Number(getComputedStyle(incoming).opacity),outgoing:Number(getComputedStyle(outgoing).opacity)};
  }""")
  self.assertGreater(values['incoming'],.05);self.assertLess(values['incoming'],.999)
  self.assertGreater(values['outgoing'],.2);self.assertLess(values['outgoing'],1)
 def test_keyboard_switches_the_same_single_selector(self):
  self.page.locator('[data-showcase-channel="instagram"]').focus()
  self.page.keyboard.press('ArrowRight');self.page.wait_for_timeout(700)
  expect(self.page.locator('[data-showcase-channel="linkedin"]')).to_be_focused()
  expect(self.page.locator('#showcase-phone .phone-scene[data-role="active"] [data-native-platform="linkedin"]')).to_have_count(1)
 def test_changing_reduce_motion_during_transition_stops_it(self):
  self.click_now('[data-showcase-channel="linkedin"]');self.page.wait_for_timeout(80)
  self.page.emulate_media(reduced_motion='reduce');self.page.wait_for_timeout(80)
  self.assertEqual(self.page.locator('#showcase-phone').evaluate('(e)=>e.getAnimations({subtree:true}).length'),0)
  expect(self.page.locator('#showcase-phone')).to_have_attribute('data-active-phone','linkedin')
 def test_editor_updates_do_not_discard_the_outgoing_direct_jump(self):
  self.click_now('[data-showcase-channel="facebook"]')
  self.page.locator('#idea').fill('Keep the transition while typing')
  self.assertEqual(self.page.locator('#showcase-phone [data-phone-channel="instagram"]').count(),1)
  self.page.wait_for_timeout(750)
  expect(self.page.locator('#showcase-phone .phone-scene[data-role="active"]')).to_contain_text('Keep the transition while typing')
  expect(self.page.locator('#showcase-phone .phone-scene')).to_have_count(3)
if __name__=='__main__':unittest.main(verbosity=2)
