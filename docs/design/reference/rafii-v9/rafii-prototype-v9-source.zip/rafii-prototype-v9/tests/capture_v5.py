"""Record the real v5 UI: touch-swiped phones, model picker, shared-language reveal."""
import base64,json,shutil,subprocess
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1];PREV=ROOT/'previews-v5';PREV.mkdir(exist_ok=True)
FRAMES=ROOT.parent/'recording-v5-frames';FRAMES.mkdir(exist_ok=True)
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox'])
 desk=b.new_page(viewport={'width':1440,'height':1080});desk.set_content((ROOT/'index.html').read_text());desk.wait_for_timeout(120);desk.screenshot(path=str(PREV/'desktop-home.png'),full_page=True)
 desk.locator('#model-trigger').click();desk.wait_for_timeout(650);desk.locator('[data-provider="xai"]').click();desk.locator('[data-model-choice="grok-reference-46"]').click();desk.locator('[data-thinking="max"]').click();desk.mouse.move(1,1);desk.screenshot(path=str(PREV/'desktop-model.png'));desk.close()
 c=b.new_context(viewport={'width':430,'height':932},has_touch=True,is_mobile=True);page=c.new_page();page.set_content((ROOT/'index.html').read_text());page.screenshot(path=str(PREV/'mobile-home.png'),full_page=True)
 page.locator('#showcase-expand').click();page.wait_for_timeout(650);page.screenshot(path=str(PREV/'mobile-expanded.png'))
 cd=c.new_cdp_session(page);record=[]
 def frame(params):
  f=FRAMES/f'{len(record):05d}.jpg';f.write_bytes(base64.b64decode(params['data']));record.append((f,params['metadata']['timestamp']));cd.send('Page.screencastFrameAck',{'sessionId':params['sessionId']})
 cd.on('Page.screencastFrame',frame);cd.send('Page.startScreencast',{'format':'jpeg','quality':88,'maxWidth':430,'maxHeight':932,'everyNthFrame':1})
 page.wait_for_timeout(500)
 for delta in [-135,-135,135]:
  box=page.locator('#expanded-phone').bounding_box();x=box['x']+box['width']*(.67 if delta<0 else .3);y=box['y']+150
  cd.send('Input.dispatchTouchEvent',{'type':'touchStart','touchPoints':[{'x':x,'y':y}]})
  for n in range(1,9):cd.send('Input.dispatchTouchEvent',{'type':'touchMove','touchPoints':[{'x':x+delta*n/8,'y':y+2*n/8}]});page.wait_for_timeout(22)
  cd.send('Input.dispatchTouchEvent',{'type':'touchEnd','touchPoints':[]});page.wait_for_timeout(1050)
 page.locator('#phone-dialog .close-dialog').click();page.wait_for_timeout(200)
 page.locator('#model-trigger').click();page.wait_for_timeout(650);page.locator('[data-provider="xai"]').click();page.locator('[data-model-choice="grok-reference-46"]').click();page.locator('[data-thinking="max"]').click();page.wait_for_timeout(650);page.screenshot(path=str(PREV/'mobile-model.png'));page.wait_for_timeout(1000)
 page.locator('#model-dialog .close-dialog').click();page.wait_for_timeout(200);page.locator('#language-trigger').click();page.wait_for_timeout(650);page.screenshot(path=str(PREV/'mobile-language.png'));page.wait_for_timeout(500)
 page.locator('#same-language-toggle').check();page.wait_for_timeout(900);page.screenshot(path=str(PREV/'mobile-shared.png'));page.wait_for_timeout(900)
 page.locator('#locale-search').fill('cantonese');page.wait_for_timeout(550);page.screenshot(path=str(PREV/'mobile-catalogue.png'));page.locator('[data-language-choice="yue-hant-hk"]').click();page.wait_for_timeout(1000)
 cd.send('Page.stopScreencast');b.close()
if not record:raise RuntimeError('No recording frames')
listing=[]
for i,(f,t) in enumerate(record):listing += [f"file '{f}'",f"duration {max(.001,record[i+1][1]-t if i+1<len(record) else .6):.6f}"]
listing.append(f"file '{record[-1][0]}'");(FRAMES/'frames.txt').write_text('\n'.join(listing)+'\n')
meta={'frames':len(record),'durationSeconds':round(record[-1][1]-record[0][1]+.6,2),'capture':'Chromium screencast with real timestamps; CDP touch gestures, not button stand-ins','viewport':[430,932]}
(ROOT/'tests/recording-v5.json').write_text(json.dumps(meta,indent=2))
subprocess.run(['ffmpeg','-y','-loglevel','error','-f','concat','-safe','0','-i',str(FRAMES/'frames.txt'),'-vf','fps=30,format=yuv420p','-c:v','libx264','-preset','fast','-crf','21','-movflags','+faststart','/mnt/data/rafii-v5-interactions.mp4'],check=True)
print(meta)
