"""Validate eight viewport sizes, both appearances, plus open v5 selector states."""
import json,shutil
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
SIZES=[(320,640),(360,800),(390,844),(430,932),(768,1024),(1024,768),(1440,900),(1920,1080)]
results=[]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox'])
 for w,h in SIZES:
  c=b.new_context(viewport={'width':w,'height':h},reduced_motion='reduce');page=c.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.set_content((ROOT/'index.html').read_text());checked=[]
  for mode in ['dark','light']:
   if mode=='light':page.locator('#theme-toggle').evaluate('e=>e.click()')
   assert page.evaluate('document.documentElement.scrollWidth')<=w,(w,mode,'page overflow')
   ys=[round(x.bounding_box()['y']) for x in page.locator('.settings-buttons button').all()];assert len(set(ys))==1,(w,'settings wrap')
   for selector in ['#channels-trigger','#language-trigger','#model-trigger','#voice-trigger','#expand-idea-trigger','#showcase-expand']:
    page.locator(selector).evaluate('e=>e.click()');d=page.locator('dialog[open]');box=d.bounding_box()
    assert box['x']>=-1 and box['x']+box['width']<=w+1,(w,mode,selector,'width',box)
    assert box['y']>=-1 and box['y']+box['height']<=h+1,(w,mode,selector,'height',box)
    if selector=='#language-trigger':
     page.locator('#same-language-toggle').evaluate('e=>e.click()')
     assert d.evaluate('e=>e.scrollWidth<=e.clientWidth+1'),(w,mode,'shared overflow')
     page.locator('#locale-search').fill('Portuguese');assert d.evaluate('e=>e.scrollWidth<=e.clientWidth+1')
    if selector=='#model-trigger':
     page.locator('[data-provider="xai"]').evaluate('e=>e.click()');page.locator('[data-model-choice="grok-reference-46"]').evaluate('e=>e.click()')
     assert d.evaluate('e=>e.scrollWidth<=e.clientWidth+1'),(w,mode,'model overflow')
    d.locator('.close-dialog').evaluate('e=>e.click()');checked.append(mode+':'+selector)
   assert not errors,errors
  results.append({'width':w,'height':h,'darkAndLightNoHorizontalOverflow':True,'threeButtonsInOneRow':True,'checkedStates':checked,'pageErrors':errors});c.close();print(w,h,'PASS',flush=True)
 b.close()
(ROOT/'tests/layout-v5.json').write_text(json.dumps(results,indent=2))
