/*
 * DOM port of the existing PostRiff / James-Au-Studio iPhone preview templates.
 * Source: dev-james0723/PostRiff, consumer-saas, 468811b73d28b4389f931519827c05d0e6c8abfb
 * web/src/components/application/post-preview/{phone-frame.tsx,templates/*.tsx}
 * The six source layouts, app chrome, text/media ordering and light palettes are
 * retained. React/Tailwind wrappers are translated to scoped HTML/CSS for offline use.
 * Demo artwork and preview controls are additions. No live engagement is fabricated.
 */
(function(root){
'use strict';
const channels=['instagram','linkedin','threads','x','facebook','red'];
const names={instagram:'Instagram',linkedin:'LinkedIn',threads:'Threads',x:'X',facebook:'Facebook',red:'Xiaohongshu'};
const paths={
 plus:'<path d="M12 5v14M5 12h14"/>',
 heart:'<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0l-1 1-1-1a5.5 5.5 0 0 0-7.8 7.8L12 21l8.8-8.6a5.5 5.5 0 0 0 0-7.8Z"/>',
 comment:'<path d="M21 11a9 9 0 0 1-9 9H3l2-4a9 9 0 1 1 16-5Z"/>',
 repeat:'<path d="m16 3 4 4-4 4M4 7h16M8 21l-4-4 4-4m12 4H4"/>',
 send:'<path d="m22 2-7 20-4-9-9-4 20-7ZM22 2 11 13"/>',
 bookmark:'<path d="M6 3h12v18l-6-4-6 4Z"/>',
 star:'<path d="m12 2 3 6.5 7 .9-5 5 1.2 7L12 18l-6.2 3.4 1.2-7-5-5 7-.9Z"/>',
 dots:'<circle cx="4" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="20" cy="12" r="1"/>',
 home:'<path fill="currentColor" stroke="none" d="m12 2 10 8v11h-7v-7H9v7H2V10Z"/>',
 movie:'<rect x="3" y="4" width="18" height="17" rx="4"/><path d="M3 9h18M8 4l3 5m3-5 3 5m-7 3 5 3-5 3Z"/>',
 search:'<circle cx="10.5" cy="10.5" r="7"/><path d="m16 16 5 5"/>',
 menu:'<path d="M4 6h16M4 12h16M4 18h16"/>',
 user:'<circle cx="12" cy="7" r="4"/><path d="M4 22v-3a8 8 0 0 1 16 0v3Z"/>',
 users:'<circle cx="9" cy="7" r="3"/><path d="M2 21v-3a7 7 0 0 1 14 0v3M17 4a3 3 0 0 1 0 6m1 3c4 1 4 4 4 8"/>',
 globe:'<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c-5 5-5 13 0 18m0-18c5 5 5 13 0 18"/>',
 bell:'<path d="M6 8a6 6 0 0 1 12 0v7l3 3H3l3-3Zm4 13h4"/>',
 briefcase:'<rect x="2" y="7" width="20" height="14" rx="2"/><path d="M8 7V3h8v4M2 12c5 4 15 4 20 0m-10 0v4"/>',
 video:'<rect x="2" y="5" width="13" height="14" rx="2"/><path d="m15 10 7-4v12l-7-4"/>',
 thumb:'<path d="M8 21H3V10h5m0 11h10a2 2 0 0 0 2-2l2-8a2 2 0 0 0-2-2h-7l1-5c0-3-3-3-4 0l-2 6Z"/>',
 share:'<path d="M12 16V2m-5 5 5-5 5 5M6 10H3v12h18V10h-3"/>',
 forward:'<path d="m14 4 8 7-8 7v-5C5 13 3 17 2 20c0-9 4-13 12-13Z"/>',
 chart:'<path d="M4 21V12m5 9V3m6 18V8m5 13V5"/>',
 back:'<path d="m15 5-7 7 7 7"/>',
 close:'<path d="m5 5 14 14M5 19 19 5"/>',
 pencil:'<path d="m3 21 2-7L17 2l5 5L10 19Zm12-17 5 5M5 14l5 5"/>',
 store:'<path d="m3 3-2 7h22l-2-7Zm0 7v12h18V10M8 22v-8h8v8"/>',
 grok:'<rect x="3" y="3" width="18" height="18" rx="4"/><path d="m8 16 8-8"/>',
 messenger:'<path d="M21 11a9 9 0 0 1-9 9H4v-4a9 9 0 1 1 17-5Z"/><path d="m6 13 4-5 4 4 4-3"/>',
 threads:'<path d="M18.6 9c-.6-4.7-3.3-6.5-7-6.5-5.5 0-8.1 3.7-8.1 9.5s2.7 9.5 8.5 9.5c4.7 0 8-2.6 8-6.3 0-3.3-2.7-5.4-6.5-5.4-3.5 0-5.5 1.5-5.5 3.6s1.7 3.3 3.7 3.1c2.8-.3 3.5-2.3 3.5-5.5s-1.1-4.4-3.2-4.4c-1.5 0-2.5.6-3.1 1.6"/>',
 x:'<path d="M4 3h4l12 18h-4ZM20 3 4 21"/>'
};
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function icon(id,size=24){return `<svg class="native-icon" viewBox="0 0 24 24" width="${size}" height="${size}" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths[id]||paths.comment}</svg>`;}
function avatar(size=36){return `<span class="native-avatar" style="width:${size}px;height:${size}px;font-size:${Math.round(size*.36)}px" aria-hidden="true">DS</span>`;}
function footer(items,labels=false){return `<div class="native-tabbar${labels?' native-tabbar-labelled':''}" aria-hidden="true">${items.map(([i,label],index)=>`<span class="native-tabitem${index===0?' is-active':''}">${i==='avatar'?avatar(27):icon(i,25)}${labels?`<small>${label}</small>`:''}</span>`).join('')}</div>`;}
function text(t,clamp=0,extra=''){return `<div class="native-copy ${extra}"${clamp?` style="--clamp:${clamp}"`:''}>${esc(t)}</div>`;}
function media(m){
 if(!m.artwork)return '';
 const slide=Math.max(0,Math.min(3,Number(m.slide)||0));
 const title=['a little<br><em>different.</em>','find your<br><em>rhythm.</em>','make room<br>for <em>ideas.</em>','still<br><em>you.</em>'][slide];
 return `<div class="native-art art-page-${slide}" role="img" aria-label="Sample artwork, page ${slide+1}. Not AI generated."><span class="art-kicker">RAFII / A CREATIVE STUDY</span><div class="art-orbit a"></div><div class="art-orbit b"></div><div class="art-plinth"></div><span class="art-editorial">${title}</span><span class="art-credit">Sample artwork <i>0${slide+1}</i></span>${m.format==='carousel'?`<span class="native-page">${slide+1} / 4</span>`:''}</div>`;
}
function missing(m,need){return `<div class="native-missing"><span>${icon(m.format==='video'?'video':'movie',32)}</span><strong>${m.format==='video'?'Video script only':need}</strong><small>${m.format==='video'?'No video has been rendered.':'No media attached to this demo draft.'}</small></div>`;}
function instagram(m){return `<header class="native-header instagram-header">${icon('plus',27)}<b>Instagram</b>${icon('heart',26)}</header><article class="native-feed"><div class="native-author ig-author">${avatar(32)}<strong>demo.studio</strong>${icon('dots',22)}</div>${media(m)||missing(m,'Instagram posts need a photo or video.')}<div class="native-actions ig-actions">${icon('heart',25)}${icon('comment',25)}${icon('repeat',24)}${icon('send',24)}<span class="spacer"></span>${icon('bookmark',25)}</div><div class="ig-caption"><strong>demo.studio</strong> ${text(m.text,2)}<span class="native-date">September 21</span></div></article>${footer([['home'],['movie'],['send'],['search'],['avatar']])}`;}
function linkedin(m){return `<header class="native-header linkedin-header">${avatar(32)}<span class="native-search">${icon('search',18)} Search</span>${icon('comment',26)}</header><div class="native-feed"><article class="linkedin-post"><div class="native-author li-author">${avatar(48)}<div><strong>Demo studio</strong><small>Now • ${icon('globe',13)}</small></div><span class="spacer"></span>${icon('dots',22)}</div><div class="li-caption">${text(m.text,3)}</div>${media(m)}<div class="native-actions li-actions">${[['thumb','Like'],['comment','Comment'],['repeat','Repost'],['send','Send']].map(([i,l])=>`<span>${icon(i,22)}<small>${l}</small></span>`).join('')}</div></article></div>${footer([['home','Home'],['video','Video'],['users','My Network'],['bell','Notifications'],['briefcase','Jobs']],true)}`;}
function threads(m){return `<header class="native-header threads-header">${icon('menu',25)}${icon('threads',30)}${icon('search',24)}</header><div class="native-feed-tabs"><strong>For you</strong><span>Following</span></div><article class="native-feed conversation-feed"><div class="conversation-avatar">${avatar(36)}</div><div class="conversation-body"><div class="native-author inline-author"><strong>demo.studio</strong><small>now</small><span class="spacer"></span>${icon('dots',20)}</div>${text(m.text)}${media(m)}<div class="native-actions threads-actions">${icon('heart',19)}${icon('comment',19)}${icon('repeat',19)}${icon('send',19)}</div></div></article>${footer([['home'],['send'],['plus'],['heart'],['user']])}`;}
function x(m){return `<header class="native-header x-header">${avatar(32)}${icon('x',26)}<span style="width:32px"></span></header><div class="native-feed-tabs x-tabs"><strong>For you</strong><span>Following</span></div><article class="native-feed conversation-feed x-feed"><div class="conversation-avatar">${avatar(40)}</div><div class="conversation-body"><div class="native-author inline-author"><strong>Demo studio</strong><small>@demo.studio · now</small><span class="spacer"></span>${icon('grok',16)}${icon('dots',18)}</div>${text(m.text,12)}${media(m)}<div class="native-actions x-actions">${['comment','repeat','heart','chart','bookmark','share'].map(i=>icon(i,19)).join('')}</div></div></article><span class="x-compose" aria-hidden="true">${icon('plus',28)}</span>${footer([['home'],['search'],['grok'],['bell'],['comment']])}`;}
function facebook(m){return `<header class="native-header facebook-header">${icon('menu',26)}<b>facebook</b><span class="spacer"></span>${icon('plus',22)}${icon('search',25)}${icon('messenger',26)}</header><div class="native-feed"><article class="facebook-post"><div class="native-author fb-author">${avatar(40)}<div><strong>Demo studio</strong><small>Just now · ${icon('globe',12)}</small></div><span class="spacer"></span>${icon('dots',22)}${icon('close',22)}</div><div class="fb-caption">${text(m.text,5)}</div>${media(m)}<div class="native-actions fb-actions">${icon('thumb',22)}${icon('comment',22)}${icon('forward',22)}</div></article></div>${footer([['home','Home'],['users','Friends'],['movie','Reels'],['store','Marketplace'],['bell','Notifications'],['avatar','Profile']],true)}`;}
function red(m){const [title,...body]=m.text.split('\n');return `<header class="native-header red-header">${icon('back',28)}${avatar(36)}<strong>Demo studio</strong><span class="spacer"></span><span class="red-follow">关注</span>${icon('forward',24)}</header><article class="native-feed red-feed">${media(m)||missing(m,'小红书笔记需要图片或视频。')}<div class="red-caption"><h3>${esc(title)}</h3>${text(body.join('\n'))}<span class="native-date">刚刚</span></div></article><footer class="red-footer" aria-hidden="true"><span class="red-comment">${icon('pencil',16)} 说点什么...</span>${[['heart','点赞'],['star','收藏'],['comment','评论']].map(([i,l])=>`<span>${icon(i,24)}<small>${l}</small></span>`).join('')}</footer>`;}
const templates={instagram,linkedin,threads,x,facebook,red};
// Retains the status glyph geometry from the repository's phone-frame.tsx.
function status(){return `<div class="device-status" aria-hidden="true"><b>9:41</b><span><svg width="19" height="12" viewBox="0 0 19 12" fill="currentColor"><rect x="0" y="8" width="3.2" height="4" rx=".8"/><rect x="5" y="5.5" width="3.2" height="6.5" rx=".8"/><rect x="10" y="3" width="3.2" height="9" rx=".8"/><rect x="15" y="0" width="3.2" height="12" rx=".8"/></svg><svg width="17" height="12" viewBox="0 0 17 12" fill="currentColor"><path d="M8.5 2.3c2.4 0 4.6.9 6.3 2.5l1.2-1.3A10.8 10.8 0 0 0 8.5.5 10.8 10.8 0 0 0 1 3.5l1.2 1.3a9.1 9.1 0 0 1 6.3-2.5Z"/><path d="M8.5 5.9c1.5 0 2.9.6 4 1.5l1.2-1.3a7.6 7.6 0 0 0-10.4 0l1.2 1.3c1.1-1 2.5-1.5 4-1.5Z"/><path d="M8.5 9.4c.6 0 1.2.2 1.7.6L8.5 11.8 6.8 10c.5-.4 1.1-.6 1.7-.6Z"/></svg><svg width="27" height="13" viewBox="0 0 27 13" fill="none"><rect x=".5" y=".5" width="23" height="12" rx="3.8" stroke="currentColor" stroke-opacity=".4"/><rect x="2" y="2" width="20" height="9" rx="2.5" fill="currentColor"/><path d="M25 4.5v4c.8-.3 1.3-1.1 1.3-2s-.5-1.7-1.3-2Z" fill="currentColor" fill-opacity=".45"/></svg></span></div>`;}
function renderPhone({channel,text:body='',format='post',slide=0,artwork=false}={}){
 if(!channels.includes(channel))throw new Error('Unknown preview platform');
 const m={channel,text:String(body),format,slide,artwork};
 return `<div class="phone-device" role="group" aria-label="${names[channel]} iPhone mockup, illustrative preview"><div class="device-shell"><div class="device-screen"><div class="native-app native-${channel}" data-native-platform="${channel}"${channel==='red'?' lang="zh-CN"':''}><div class="native-status-space"></div>${templates[channel](m)}${status()}<div class="device-island" aria-hidden="true"></div><div class="device-home" aria-hidden="true"></div></div></div></div></div>`;
}
const api={channels,screen:{width:393,height:852,statusBar:54,homeIndicator:34,bezel:9,radius:55},renderPhone,icon,sourceCommit:'468811b73d28b4389f931519827c05d0e6c8abfb'};
if(typeof module==='object'&&module.exports)module.exports=api;else root.RafiiPhones=api;
})(typeof globalThis!=='undefined'?globalThis:this);
