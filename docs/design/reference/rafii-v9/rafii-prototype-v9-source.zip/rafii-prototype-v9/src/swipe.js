/* Pointer-first gesture recogniser. pan-y/pinch-zoom remain native; a swipe only changes preview. */
(function(root){'use strict';
 function bindSwipe(target,{onSwipe,motionAllowed=()=>true}){
  let gesture=null,blocked=false,suppressUntil=0;const pointers=new Set();
  const reset=()=>{gesture=null;target.classList.remove('is-dragging');target.style.removeProperty('--swipe-offset');};
  target.addEventListener('pointerdown',e=>{
   pointers.add(e.pointerId);
   if(pointers.size>1){blocked=true;reset();return;}
   if(blocked||e.isPrimary===false||(e.pointerType==='mouse'&&e.button!==0)||e.target.closest('button,a,input,textarea,select,[contenteditable="true"]'))return;
   gesture={id:e.pointerId,x:e.clientX,y:e.clientY,t:performance.now(),dx:0,dy:0,axis:null};
  });
  target.addEventListener('pointermove',e=>{
   const g=gesture;if(!g||g.id!==e.pointerId||blocked)return;
   g.dx=e.clientX-g.x;g.dy=e.clientY-g.y;
   if(!g.axis){if(Math.abs(g.dy)>10&&Math.abs(g.dy)>Math.abs(g.dx)){g.axis='y';reset();return;}if(Math.abs(g.dx)>10&&Math.abs(g.dx)>Math.abs(g.dy)*1.3){g.axis='x';try{target.setPointerCapture(e.pointerId);}catch{}}}
   if(g.axis==='x'){if(e.cancelable)e.preventDefault();target.classList.add('is-dragging');if(motionAllowed())target.style.setProperty('--swipe-offset',`${Math.max(-22,Math.min(22,g.dx*.12))}px`);}
  },{passive:false});
  function end(e,cancelled=false){
   pointers.delete(e.pointerId);const g=gesture;
   if(g?.id===e.pointerId){const dx=e.clientX-g.x,dy=e.clientY-g.y,elapsed=Math.max(1,performance.now()-g.t);const accepted=!cancelled&&!blocked&&g.axis==='x'&&Math.abs(dx)>Math.abs(dy)*1.3&&(Math.abs(dx)>=42||(Math.abs(dx)>=26&&Math.abs(dx)/elapsed>.45));reset();if(accepted){suppressUntil=performance.now()+300;onSwipe(dx<0?1:-1);}}
   if(pointers.size===0)blocked=false;
  }
  target.addEventListener('pointerup',e=>end(e));target.addEventListener('pointercancel',e=>end(e,true));
  target.addEventListener('lostpointercapture',e=>{if(e.target===target&&gesture?.id===e.pointerId)reset();});
  target.addEventListener('click',e=>{if(performance.now()<suppressUntil){e.preventDefault();e.stopImmediatePropagation();}},true);
  target.addEventListener('dragstart',e=>e.preventDefault());
  window.addEventListener('blur',()=>{pointers.clear();blocked=false;reset();});
 }
 root.RafiiSwipe={bindSwipe};
})(globalThis);
