/* Rafii v9: saved account groups. Pure functions; a folder never owns an account. */
(function(root){
'use strict';
const symbols=Object.freeze(['folder','spark','music','briefcase','heart','globe']);
function cleanSelection(ids,accounts){const valid=new Set(accounts.map(a=>a.id));return [...new Set(Array.isArray(ids)?ids:[])].filter(id=>valid.has(id));}
function selectionState(folder,selected,accounts){
 const members=cleanSelection(folder.accountIds,accounts),set=new Set(selected),count=members.filter(id=>set.has(id)).length;
 return {state:members.length===0?'empty':count===0?'none':count===members.length?'all':'mixed',count,total:members.length};
}
function toggleGroup(selected,folder,accounts){
 const current=cleanSelection(selected,accounts),members=cleanSelection(folder.accountIds,accounts);
 return selectionState(folder,current,accounts).state==='all'?current.filter(id=>!members.includes(id)):cleanSelection([...current,...members],accounts);
}
function makeFolder(input,folders,accounts){
 const name=String(input.name||'').trim().replace(/\s+/g,' '),id=String(input.id||('folder-'+(globalThis.crypto?.randomUUID?.()||Date.now().toString(36)+Math.random().toString(36).slice(2))));
 if(!name)throw new Error('Give your folder a name.');
 if(name.length>40)throw new Error('Keep the name within 40 characters.');
 if(folders.some(f=>f.id!==id&&f.name.toLocaleLowerCase()===name.toLocaleLowerCase()))throw new Error('That name is already in use. Try another.');
 const accountIds=cleanSelection(input.accountIds,accounts);
 if(!accountIds.length)throw new Error('Choose at least one account.');
 return {id,name,accountIds,symbol:symbols.includes(input.symbol)?input.symbol:'folder',pinned:!!input.pinned,example:!!input.example};
}
function copyName(name,folders){
 const names=new Set(folders.map(f=>f.name.toLocaleLowerCase()));const base=name.slice(0,32);let label=base+' copy',n=2;
 while(names.has(label.toLocaleLowerCase()))label=base+' copy '+n++;
 return label;
}
function matches(folder,query,accounts){
 const byId=new Map(accounts.map(a=>[a.id,a])),parts=[folder.name];
 for(const id of folder.accountIds){const a=byId.get(id);if(a)parts.push(a.name,a.handle,a.platform,a.platformLabel);}
 return parts.filter(Boolean).join(' ').toLocaleLowerCase().includes(query.trim().toLocaleLowerCase());
}
function visibleFolders(folders,query,all,accounts){
 const sorted=folders.map((f,i)=>({f,i})).sort((a,b)=>Number(b.f.pinned)-Number(a.f.pinned)||a.i-b.i).map(x=>x.f);
 const filtered=query.trim()?sorted.filter(f=>matches(f,query,accounts)):sorted;
 return all||query.trim()?filtered:filtered.slice(0,4);
}
function moveFolder(folders,id,delta){
 const copy=[...folders],i=copy.findIndex(f=>f.id===id);if(i<0)return copy;
 const target=i+Math.sign(delta);if(target<0||target>=copy.length||!delta)return copy;
 [copy[i],copy[target]]=[copy[target],copy[i]];return copy;
}
function snapshotContext(folders,ids){return {sources:[...new Set(ids)].flatMap(id=>{const f=folders.find(f=>f.id===id);return f?[{id:f.id,name:f.name,accountIds:[...f.accountIds]}]:[];})};}
function selectionLabel(selected,context){
 if(!selected.length)return 'No accounts';
 const sources=context?.sources||[];if(!sources.length)return selected.length+' accounts';
 const base=[...new Set(sources.flatMap(f=>f.accountIds))];const same=base.length===selected.length&&base.every(id=>selected.includes(id));
 return (sources.length===1?sources[0].name:sources.length+' folders')+(same?'':', customized');
}
function decodeStored(raw,accounts){
 try{const data=JSON.parse(raw);if(data?.version!==1||!Array.isArray(data.folders))return null;
 const result=[];for(const input of data.folders.slice(0,50)){
  if(!input||typeof input.id!=='string'||result.some(f=>f.id===input.id))continue;
  try{result.push(makeFolder(input,result,accounts));}catch(_){}
 }return result;
 }catch(_){return null;}
}
const api={symbols,cleanSelection,selectionState,toggleGroup,makeFolder,copyName,visibleFolders,moveFolder,snapshotContext,selectionLabel,decodeStored};
if(typeof module==='object'&&module.exports)module.exports=api;else root.RafiiFolderCore=api;
})(globalThis);
