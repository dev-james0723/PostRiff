/* Local, interruptible phone transitions. No runtime dependencies or network calls.
 * All phone markup comes from the existing escaped RafiiPhones renderer.
 * Decorative neighbours are inert, not duplicate selectable phone UIs.
 */
(function (root) {
 'use strict';
 function createPhoneDeck({renderPhone, motionAllowed, duration=560}) {
  const stores=new WeakMap(), activeStores=new Set();
  const easing='cubic-bezier(.22,.78,.22,1)';
  function pose(role) {
   if(role==='active')return {transform:'translateX(0%) rotateY(0deg) scale(1)',opacity:1};
   if(role==='left')return {transform:'translateX(-65%) rotateY(14deg) scale(.83)',opacity:.2};
   if(role==='right')return {transform:'translateX(65%) rotateY(-14deg) scale(.83)',opacity:.2};
   return {transform:'translateX(-38%) rotateY(7deg) scale(.9)',opacity:0};
  }
  function clean(store) {
   for(const [key,item] of store.items)if(!store.keep.has(key)){item.node.remove();store.items.delete(key);}
   store.target.dataset.transition='idle';store.animations=[];
  }
  function finish(store) {
   store.rev++;store.animations.forEach(a=>a.cancel());
   for(const item of store.items.values())Object.assign(item.node.style,pose(item.node.dataset.role));
   clean(store);
  }
  function destroy(target) {
   const store=stores.get(target);
   if(store){store.rev++;store.animations.forEach(a=>a.cancel());activeStores.delete(store);stores.delete(target);}
   target.replaceChildren();delete target.dataset.activePhone;delete target.dataset.transition;
  }
  function render(target,model,models) {
   if(!model){destroy(target);return;}
   const list=models.filter((m,i,a)=>m&&a.findIndex(x=>x.channel===m.channel)===i);
   if(!list.some(m=>m.channel===model.channel))list.unshift(model);
   const pos=list.findIndex(m=>m.channel===model.channel);
   const desired=[{model,role:'active'}];
   if(list.length>1)desired.push({model:list[(pos-1+list.length)%list.length],role:'left'});
   if(list.length>2)desired.push({model:list[(pos+1)%list.length],role:'right'});
   let store=stores.get(target);
   if(!store){store={target,items:new Map(),active:null,keep:new Set(),animations:[],rev:0};stores.set(target,store);activeStores.add(store);}
   const oldActive=store.active, switching=!!oldActive&&oldActive!==model.channel;
   const allow=switching&&motionAllowed()&&target.getClientRects().length>0&&typeof target.animate==='function';
   const nextKeep=new Set(desired.map(x=>x.model.channel));
   const before=new Map();
   if(switching){
    for(const [id,item] of store.items){const style=getComputedStyle(item.node);before.set(id,{transform:style.transform,opacity:style.opacity});}
    store.rev++;store.animations.forEach(a=>a.cancel());store.animations=[];
   }
   function updateItem(m) {
    let item=store.items.get(m.channel);
    if(!item){
     const node=document.createElement('div');node.className='phone-scene';node.dataset.phoneChannel=m.channel;
     item={node,signature:null};store.items.set(m.channel,item);target.append(node);
    }
    const signature=JSON.stringify(m);
    if(signature!==item.signature){
     const scrolls=Array.from(item.node.querySelectorAll('.native-scroll')).map(x=>x.scrollTop);
     item.node.innerHTML=renderPhone(m);item.signature=signature;
     item.node.querySelectorAll('.native-scroll').forEach((n,i)=>n.scrollTop=scrolls[i]||0);
    }
    return item;
   }
   for(const d of desired)updateItem(d.model);
   // Typing updates content, not transition ownership. Keep its exiting layer until completion.
   const retained=!switching&&store.animations.length?[...store.items.keys()]:(allow?[oldActive]:[]);
   const allowedNodes=new Set([...nextKeep,...retained]);
   for(const [id,item] of store.items)if(!allowedNodes.has(id)){item.node.remove();store.items.delete(id);}
   store.keep=nextKeep;store.active=model.channel;target.dataset.activePhone=model.channel;
   for(const [id,item] of store.items) {
    const role=desired.find(x=>x.model.channel===id)?.role||'exit';
    item.node.dataset.role=role;
    item.node.setAttribute('aria-hidden',String(role!=='active'));item.node.inert=role!=='active';
    item.node.style.zIndex=role==='active'?'3':id===oldActive?'2':'1';
    if(switching||!store.animations.length||!item.node.style.transform)Object.assign(item.node.style,pose(role));
   }
   // Keep the sole accessible phone first. Reordering does not destroy the outgoing node.
   target.prepend(store.items.get(model.channel).node);
   if(!allow) {
    if(switching||!store.animations.length){store.animations.forEach(a=>a.cancel());clean(store);}
    return;
   }
   const rev=store.rev;target.dataset.transition='switching';
   const oldPos=list.findIndex(m=>m.channel===oldActive);
   const direction=oldPos<0||((pos-oldPos+list.length)%list.length)<=list.length/2?1:-1;
   for(const [id,item] of store.items) {
    const end=pose(item.node.dataset.role);
    let start=before.get(id);
    if(!start)start=id===model.channel?{transform:`translateX(${direction*24}%) rotateY(${-direction*6}deg) scale(.94)`,opacity:0}:{transform:end.transform,opacity:0};
    if(start.transform==='none')start.transform=pose('active').transform;
    const animation=item.node.animate([start,end],{duration,easing,fill:'both'});
    store.animations.push(animation);
   }
   const animations=[...store.animations];
   Promise.all(animations.map(a=>a.finished.catch(()=>{}))).then(()=>{
    if(store.rev!==rev)return;
    animations.forEach(a=>a.cancel());clean(store);
   });
  }
  function finishAll(){activeStores.forEach(finish);}
  return {render,destroy,finishAll};
 }
 root.RafiiMotion={createPhoneDeck};
})(typeof globalThis!=='undefined'?globalThis:this);
