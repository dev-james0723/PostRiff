/* v9 Channel Folders. DOM adapter: staged destinations, explicitly saved folder edits.
   Storage is local to this browser when available; never contains draft text or credentials. */
(function(root){
'use strict';
function create({dialog,channels,platform,icon,motionAllowed,onCommit}){
 const F=root.RafiiFolderCore,UI=root.RafiiUI,$=s=>dialog.querySelector(s),$$=s=>Array.from(dialog.querySelectorAll(s));
 const esc=v=>String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const accounts=channels.map(c=>({id:'account-'+c.id,platform:c.id,platformLabel:c.name,name:c.id==='linkedin'?'Demo profile':'Demo studio',handle:c.handle}));
 const byId=new Map(accounts.map(a=>[a.id,a]));
 const key='rafii.prototype.v9.channel-folders';
 const seeds=[
  {id:'personal',name:'Personal',symbol:'heart',pinned:true,example:true,accountIds:['account-instagram','account-threads','account-x']},
  {id:'festival',name:'Festival',symbol:'music',pinned:true,example:true,accountIds:['account-instagram','account-facebook','account-red']},
  {id:'professional',name:'Professional',symbol:'briefcase',pinned:true,example:true,accountIds:['account-linkedin','account-x']}
 ];
 let storageOK=false,folders=seeds.map(f=>({...f,accountIds:[...f.accountIds]}));
 try{const raw=localStorage.getItem(key),saved=raw?F.decodeStored(raw,accounts):null;if(saved)folders=saved;localStorage.setItem(key,JSON.stringify({version:1,folders}));storageOK=true;}catch(_){}
 let selected=[],origins=[],query='',all=false,inspecting=null,undo=null,editor=null,returnFocus=null;
 const hasMotion=()=>motionAllowed()&&typeof dialog.animate==='function';
 const symbolLabel={folder:'Folder',spark:'Spark',music:'Music',briefcase:'Work',heart:'Personal',globe:'Global'};
 const copyContext=()=>origins.map(o=>({...o,accountIds:[...o.accountIds]}));
 function folderObject(f,small=false){
  const a=f.accountIds.map(id=>byId.get(id)).filter(Boolean),first=a.slice(0,3);
  return `<span class="folder-object${small?' small-folder-object':''}" aria-hidden="true"><span class="folder-backplate"></span><span class="folder-peek">${first.map((x,i)=>`<span class="peek-item" style="--i:${i}">${platform(x.platform)}</span>`).join('')}</span><span class="folder-front"><span>${icon(f.symbol||'folder')}</span><i></i>${a.length>3?`<b>+${a.length-3}</b>`:''}</span></span>`;
 }
 function persist(){
  try{localStorage.setItem(key,JSON.stringify({version:1,folders}));storageOK=true;}catch(_){storageOK=false;}
  updateStorage();
 }
 function updateStorage(){
  $('#folder-storage-note').innerHTML=icon(storageOK?'bookmark':'info')+(storageOK?'Folders saved in this browser. Demo accounts.':'Session-only folders. Browser storage is unavailable.');
 }
 function feedback(message,previous=null){
  undo=previous;$('#folder-feedback').hidden=false;$('#folder-feedback-text').textContent=message;$('#folder-undo').hidden=!previous;
 }
 function clearFeedback(){undo=null;$('#folder-feedback').hidden=true;}
 function selectionBefore(){return {selected:[...selected],origins:copyContext()};}
 function setSelection(next,message,nextOrigins=origins){
  const previous=selectionBefore();selected=F.cleanSelection(next,accounts);origins=nextOrigins;updateSelection();feedback(message,previous);
 }
 function updateSelection(){
  const set=new Set(selected);
  $$('[data-account-select]').forEach(input=>input.checked=set.has(input.dataset.accountSelect));
  $$('[data-folder-select]').forEach(button=>{
   const f=folders.find(f=>f.id===button.dataset.folderSelect);if(!f)return;
   const info=F.selectionState(f,selected,accounts),mixed=info.state==='mixed',all=info.state==='all';
   button.setAttribute('aria-checked',mixed?'mixed':String(all));button.disabled=info.state==='empty';
   button.setAttribute('aria-label',`${f.name}, ${info.count} of ${info.total} accounts selected`);
   button.closest('.folder-card').dataset.selection=info.state;
   button.querySelector('.folder-state-text').textContent=all?`${info.total} selected`:mixed?`${info.count} of ${info.total} selected`:`${info.total} accounts`;
  });
  $('#channel-done').innerHTML=`Done · ${selected.length} accounts selected ${icon('check')}`;
  $('#channel-done').setAttribute('aria-label',`Done, ${selected.length} accounts selected`);
  $('#clear-channels').disabled=!selected.length;$('#save-selection-folder').disabled=!selected.length;
  $('#individual-account-count').textContent=String(selected.length)+' selected';
 }
 function card(f){return `<article class="folder-card${inspecting===f.id?' is-inspected':''}" data-folder-card="${esc(f.id)}">
  <button class="folder-select" type="button" role="checkbox" aria-checked="false" data-folder-select="${esc(f.id)}">${folderObject(f)}<span class="folder-check" aria-hidden="true">${icon('check')}<i></i></span><strong>${esc(f.name)}</strong><span class="folder-state-text">${f.accountIds.length} accounts</span>${f.pinned?`<span class="folder-pin" aria-hidden="true">${icon('pin')}</span>`:''}</button>
  <button class="folder-inspect-button" type="button" data-folder-inspect="${esc(f.id)}" aria-label="Open ${esc(f.name)} folder" aria-expanded="${inspecting===f.id}" aria-controls="folder-inspector">${icon('chevron')}</button></article>`;}
 function accountRow(a,location='main'){
  const value=location==='main'?a.platform:a.id;
  return `<label class="account-row${location==='main'?' channel-tile':''}" ${location==='main'?`data-channel="${a.platform}"`:''}>
   <input type="checkbox" value="${value}" data-account-select="${a.id}" aria-label="${esc(a.platformLabel)}, ${esc(a.handle)}, demo account" ${selected.includes(a.id)?'checked':''}>
   <span class="account-row-inner${location==='main'?' channel-tile-inner':''}">${platform(a.platform)}<span class="account-row-copy"><strong>${esc(a.platformLabel)}</strong><small>${esc(a.handle)}</small></span><span class="account-row-check" aria-hidden="true">${icon('check')}</span></span></label>`;
 }
 function renderMain({keepInspector=false}={}){
  const shelf=$('#folder-shelf'),inspector=$('#folder-inspector');if(inspector.parentElement===shelf)shelf.after(inspector);
  const visible=F.visibleFolders(folders,query,all,accounts);
  $('#folder-shelf').innerHTML=visible.map(card).join('');
  $('#folder-total').textContent=String(folders.length);
  $('#folder-help').textContent=folders.length?'Tap to select a group. Use the chevron to look inside.':'Save the accounts you use together. Start with a new folder.';
  $('#folder-empty').hidden=folders.length>0||!!query;
  $('#view-all-folders').hidden=!!query||folders.length<=4;
  $('#view-all-folders').textContent=all?'Show fewer folders':`View all ${folders.length} folders`;
  $('#view-all-folders').setAttribute('aria-expanded',String(all));
  const q=query.toLocaleLowerCase();
  $('#channel-grid').innerHTML=accounts.map(a=>accountRow(a)).join('');
  $$('#channel-grid .account-row').forEach(row=>{const a=accounts.find(a=>a.platform===row.dataset.channel);row.hidden=!!q&&!`${a.platformLabel} ${a.name} ${a.handle}`.toLocaleLowerCase().includes(q);});
  const accountCount=$$('#channel-grid .account-row:not([hidden])').length;
  $('#accounts-section').hidden=!accountCount;
  $('#folders-section').hidden=!!query&&!visible.length;
  $('#folder-search-empty').hidden=visible.length>0||accountCount>0;
  $('#clear-search-inline').hidden=!query;
  if(!keepInspector||!visible.some(f=>f.id===inspecting))closeInspector(false);
  else if(inspecting)renderInspector(false);
  updateSelection();updateStorage();
 }
 function renderInspector(animate=true){
  const f=folders.find(f=>f.id===inspecting);if(!f){closeInspector(false);return;}
  const box=$('#folder-inspector'),before=box.getBoundingClientRect().height;
  const cards=$$('#folder-shelf .folder-card'),idx=cards.findIndex(c=>c.dataset.folderCard===f.id);
  if(idx>=0)cards[Math.min(Math.floor(idx/2)*2+1,cards.length-1)].after(box);
  box.innerHTML=`<div class="inspector-inner"><div class="inspector-heading"><div><small>INSIDE THE FOLDER</small><h3>${esc(f.name)}</h3></div><button id="edit-folder" type="button" class="folder-quiet-button">${icon('pencil')} Edit</button><button id="folder-more" type="button" class="folder-square-button" aria-label="More folder actions" aria-expanded="false" aria-controls="folder-menu">${icon('more')}</button></div>
   <div id="folder-menu" class="folder-menu" hidden></div><div id="folder-delete" class="folder-delete" hidden></div>
   <div class="inspector-accounts">${f.accountIds.map(id=>byId.get(id)).filter(Boolean).map(a=>accountRow(a,'inspector')).join('')}</div>
   <p class="inspector-help">Changes here are just for this draft. The saved folder stays the same.</p></div>`;
  box.hidden=false;UI.height(box,before,true,animate&&hasMotion());
  $$('[data-folder-card]').forEach(c=>c.classList.toggle('is-inspected',c.dataset.folderCard===f.id));
  $$('[data-folder-inspect]').forEach(b=>b.setAttribute('aria-expanded',String(b.dataset.folderInspect===f.id)));
  if(animate&&hasMotion())$$('.inspector-accounts .platform').forEach((el,i)=>el.animate([{opacity:0,transform:'translateY(-12px) rotate(-8deg) scale(.8)'},{opacity:1,transform:'none'}],{duration:430,delay:90+i*45,easing:'cubic-bezier(.22,1,.36,1)',fill:'backwards'}));
  updateSelection();
 }
 function openInspector(id){
  if(inspecting===id){closeInspector(true);return;}
  inspecting=id;renderInspector(true);
  const box=$('#folder-inspector');const reveal=()=>{if(dialog.open&&!editor&&inspecting===id)box.scrollIntoView({block:'nearest',behavior:hasMotion()?'smooth':'instant'});};
  if(hasMotion())Promise.all(box.getAnimations().map(a=>a.finished.catch(()=>{}))).then(reveal);else requestAnimationFrame(reveal);
 }
 function closeInspector(animate){
  inspecting=null;const box=$('#folder-inspector');
  UI.height(box,box.getBoundingClientRect().height,false,animate&&hasMotion());
  const finish=()=>{if(inspecting)return;box.replaceChildren();box.hidden=true;$('#folder-shelf').after(box);};
  if(!animate||!hasMotion())finish();else Promise.all(box.getAnimations().map(a=>a.finished.catch(()=>{}))).then(finish);
  $$('[data-folder-card]').forEach(c=>c.classList.remove('is-inspected'));
  $$('[data-folder-inspect]').forEach(b=>b.setAttribute('aria-expanded','false'));
 }
 function renderMenu(){
  const f=folders.find(f=>f.id===inspecting);if(!f)return;
  const sorted=F.visibleFolders(folders,'',true,accounts),i=sorted.findIndex(x=>x.id===f.id);
  $('#folder-menu').innerHTML=[['pin',f.pinned?'Unpin folder':'Pin folder',f.pinned?'pin-off':'pin',false],['duplicate','Duplicate','copy',false],['up','Move up','arrow-up',i===0||sorted[i-1].pinned!==f.pinned],['down','Move down','arrow-down',i===sorted.length-1||sorted[i+1].pinned!==f.pinned],['delete','Delete folder','trash',false]].map(([id,label,ico,disabled])=>`<button type="button" data-folder-command="${id}" ${disabled?'disabled':''}>${icon(ico)}${label}</button>`).join('');
  $('#folder-menu').hidden=false;$('#folder-more').setAttribute('aria-expanded','true');
 }
 function command(cmd){
  const f=folders.find(f=>f.id===inspecting);if(!f)return;
  if(cmd==='delete'){
   $('#folder-menu').hidden=true;$('#folder-more').setAttribute('aria-expanded','false');
   $('#folder-delete').innerHTML=`<strong>Delete “${esc(f.name)}”?</strong><p>This removes the folder only. Accounts and draft destinations stay unchanged.</p><div><button id="cancel-delete-folder" type="button">Keep folder</button><button id="confirm-delete-folder" type="button">Delete folder</button></div>`;$('#folder-delete').hidden=false;$('#cancel-delete-folder').focus();return;
  }
  if(cmd==='duplicate'){
   if(folders.length>=50){feedback('This prototype supports up to 50 folders.');return;}
   const clone=F.makeFolder({...f,id:undefined,name:F.copyName(f.name,folders),example:false,pinned:false},folders,accounts);folders=[...folders,clone];inspecting=clone.id;all=true;feedback('Folder duplicated. Your draft selection is unchanged.');
  }else if(cmd==='pin'){
   folders=folders.map(x=>x.id===f.id?{...x,pinned:!x.pinned}:x);feedback(f.pinned?'Folder unpinned.':'Folder pinned to the shelf.');
  }else if(cmd==='up'||cmd==='down'){
   folders=F.moveFolder(F.visibleFolders(folders,'',true,accounts),f.id,cmd==='up'?-1:1);feedback('Folder order updated.');
  }
  persist();renderMain({keepInspector:true});$('#folder-more')?.focus({preventScroll:true});
 }
 function switchView(editing){
  const previous=editing?$('#folder-main-view'):$('#folder-editor-view');const next=editing?$('#folder-editor-view'):$('#folder-main-view');
  previous.hidden=true;next.hidden=false;$('#folder-back').hidden=!editing;
  $('#channel-title').innerHTML=editing?(editor?.id?'Make it <em>yours.</em>':'Keep a good <em>group.</em>'):'Where should it <em>go?</em>';
  $('#channel-intro').textContent=editing?'A name, a few accounts. Ready for next time.':'Your usual accounts, one thoughtful shortcut.';
  $('#channel-eyebrow').textContent=editing?(editor?.id?'EDIT FOLDER':'NEW FOLDER'):'CHANNEL BLOOM / V9';
  if(hasMotion())next.animate([{opacity:0,transform:`translateX(${editing?14:-14}px)`},{opacity:1,transform:'none'}],{duration:350,easing:'cubic-bezier(.22,1,.36,1)'});
 }
 function openEditor(id=null,fromSelection=false){
  if(!id&&folders.length>=50){feedback('This prototype supports up to 50 folders.');return;}
  returnFocus=document.activeElement;
  const f=folders.find(f=>f.id===id);editor=f?{...f,accountIds:[...f.accountIds],example:false}:{name:'',symbol:'folder',pinned:false,accountIds:fromSelection?[...selected]:[],example:false};
  $('#folder-name').value=editor.name;$('#folder-pinned').checked=editor.pinned;
  $('#folder-symbols').innerHTML=F.symbols.map(s=>`<button type="button" data-folder-symbol="${s}" aria-label="${symbolLabel[s]} symbol" aria-pressed="${editor.symbol===s}" title="${symbolLabel[s]}">${icon(s)}</button>`).join('');
  $('#folder-member-choices').innerHTML=accounts.map(a=>`<label class="account-row"><input type="checkbox" value="${a.id}" data-folder-member="${a.id}" ${editor.accountIds.includes(a.id)?'checked':''}><span class="account-row-inner">${platform(a.platform)}<span class="account-row-copy"><strong>${esc(a.platformLabel)}</strong><small>${esc(a.handle)}</small></span><span class="account-row-check" aria-hidden="true">${icon('check')}</span></span></label>`).join('');
  $('#folder-editor-error').textContent='';switchView(true);validateEditor(false);$('#folder-name').focus({preventScroll:true});
 }
 function validateEditor(showError=true){
  if(!editor)return;
  editor.name=$('#folder-name').value;editor.pinned=$('#folder-pinned').checked;
  $('#folder-name-count').textContent=editor.name.length+' / 40';$('#folder-member-count').textContent=editor.accountIds.length+' selected';
  $('#folder-editor-object').innerHTML=folderObject(editor);$('#folder-live-name').textContent=editor.name.trim()||'Your new folder';
  $$('[data-folder-symbol]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.folderSymbol===editor.symbol)));
  try{F.makeFolder(editor,folders,accounts);$('#save-folder').disabled=false;$('#folder-editor-error').textContent='';}
  catch(error){$('#save-folder').disabled=true;$('#folder-editor-error').textContent=showError&&editor.name.trim()?error.message:'';}
 }
 function finishEditor(saved=false){
  const id=editor?.id;editor=null;switchView(false);renderMain({keepInspector:true});
  if(saved&&id)$(`[data-folder-inspect="${CSS.escape(id)}"]`)?.focus({preventScroll:true});
  else if(returnFocus?.isConnected)returnFocus.focus({preventScroll:true});else $('#new-folder').focus({preventScroll:true});
 }
 function saveEditor(){
  try{
   const f=F.makeFolder(editor,folders,accounts),i=folders.findIndex(x=>x.id===f.id);
   if(i>=0)folders=folders.map(x=>x.id===f.id?f:x);else folders=[...folders,f];
   if(folders.length>4)all=true;inspecting=null;persist();finishEditor(true);feedback('Folder saved. Draft destinations stay unchanged.');
  }catch(error){$('#folder-editor-error').textContent=error.message;}
 }
 function open({platforms,context}){
  selected=accounts.filter(a=>platforms.includes(a.platform)).map(a=>a.id);origins=(context?.sources||[]).map(o=>({...o,accountIds:[...o.accountIds]}));query='';all=false;inspecting=null;editor=null;
  $('#channel-search').value='';clearFeedback();switchView(false);renderMain();$('#channel-scroll').scrollTop=0;
 }
 function done(){onCommit({accountIds:[...selected],platforms:[...new Set(selected.map(id=>byId.get(id)?.platform).filter(Boolean))],context:{sources:copyContext()}});}
 dialog.addEventListener('click',e=>{
  const el=e.target.closest('button');if(!el||el.disabled)return;
  if(el.dataset.folderSelect){
   const f=folders.find(f=>f.id===el.dataset.folderSelect);if(!f)return;const before=selectionBefore(),removing=F.selectionState(f,selected,accounts).state==='all';
   selected=F.toggleGroup(selected,f,accounts);origins=origins.filter(o=>o.id!==f.id);if(!removing)origins.push(F.snapshotContext([f],[f.id]).sources[0]);
   const changed=Math.abs(selected.length-before.selected.length);updateSelection();feedback(`${removing?'Removed':'Added'} ${changed} ${changed===1?'account':'accounts'}. Overlapping folders updated.`,before);
   if(hasMotion())el.querySelector('.folder-object').animate([{transform:'scale(.94)'},{transform:'scale(1.025)',offset:.55},{transform:'scale(1)'}],{duration:470,easing:'cubic-bezier(.22,1,.36,1)'});
  }else if(el.dataset.folderInspect)openInspector(el.dataset.folderInspect);
  else if(el.dataset.folderCommand)command(el.dataset.folderCommand);
  else if(el.dataset.folderSymbol){editor.symbol=el.dataset.folderSymbol;validateEditor();}
  else switch(el.id){
   case 'new-folder':openEditor();break;
   case 'empty-create-folder':openEditor();break;
   case 'save-selection-folder':openEditor(null,true);break;
   case 'edit-folder':openEditor(inspecting);break;
   case 'save-folder':saveEditor();break;
   case 'folder-back':case 'cancel-folder-editor':finishEditor();break;
   case 'view-all-folders':all=!all;renderMain({keepInspector:true});break;
   case 'folder-more':if($('#folder-menu').hidden)renderMenu();else{$('#folder-menu').hidden=true;el.setAttribute('aria-expanded','false');}break;
   case 'cancel-delete-folder':$('#folder-delete').hidden=true;$('#folder-more').focus();break;
   case 'confirm-delete-folder':folders=folders.filter(f=>f.id!==inspecting);inspecting=null;persist();renderMain();feedback('Folder deleted. Accounts and draft destinations are unchanged.');$('#new-folder').focus({preventScroll:true});break;
   case 'clear-channels':setSelection([],'Selection cleared.',[]);break;
   case 'folder-undo':if(undo){selected=[...undo.selected];origins=undo.origins.map(x=>({...x,accountIds:[...x.accountIds]}));updateSelection();feedback('Selection restored.');}break;
   case 'clear-search-inline':case 'clear-folder-search':query='';$('#channel-search').value='';renderMain();$('#channel-search').focus({preventScroll:true});break;
   case 'channel-done':done();break;
  }
 });
 dialog.addEventListener('change',e=>{
  const input=e.target;
  if(input.dataset.accountSelect){const id=input.dataset.accountSelect;setSelection(input.checked?[...selected,id]:selected.filter(a=>a!==id),'Account selection updated.');}
  if(input.dataset.folderMember){const id=input.dataset.folderMember;editor.accountIds=input.checked?F.cleanSelection([...editor.accountIds,id],accounts):editor.accountIds.filter(a=>a!==id);validateEditor();}
  if(input.id==='folder-pinned')validateEditor();
 });
 $('#channel-search').addEventListener('input',e=>{query=e.target.value.trim();renderMain();});
 $('#folder-name').addEventListener('input',()=>validateEditor());
 $('#folder-name').addEventListener('keydown',e=>{if(e.key==='Enter'&&!$('#save-folder').disabled){e.preventDefault();saveEditor();}});
 dialog.addEventListener('cancel',e=>{if(editor){e.preventDefault();e.stopImmediatePropagation();finishEditor();}else if(inspecting){const id=inspecting;e.preventDefault();e.stopImmediatePropagation();closeInspector(true);$(`[data-folder-inspect="${CSS.escape(id)}"]`)?.focus();}},true);
 dialog.addEventListener('keydown',e=>{
  if(e.key!=='Tab')return;
  const controls=$$('button:not(:disabled),input:not(:disabled),[tabindex="0"]').filter(el=>el.getClientRects().length&&!el.closest('[hidden]')&&!el.closest('[inert]'));
  if(!controls.length)return;const first=controls[0],last=controls[controls.length-1];
  if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}
 });
 updateStorage();return {open,accounts,selectionLabel:(platforms,context)=>F.selectionLabel(accounts.filter(a=>platforms.includes(a.platform)).map(a=>a.id),context)};
}
root.RafiiFoldersUI={create};
})(globalThis);
