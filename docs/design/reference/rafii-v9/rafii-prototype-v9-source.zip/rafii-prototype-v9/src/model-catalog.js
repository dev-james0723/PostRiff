/* UI demonstration catalog. Names taken from the existing demo and supplied visual reference.
 * Not a live availability/capabilities catalog. No credentials or provider SDKs are present.
 */
(function(root){
const providers=[{id:'openai',label:'OpenAI'},{id:'anthropic',label:'Anthropic'},{id:'xai',label:'xAI'},{id:'google',label:'Google'},{id:'cli',label:'CLI'}];
const models=[
{id:'gpt-4o',provider:'openai',label:'GPT-4o',note:'Existing prototype preset',thinking:false,image:true},
{id:'openai-reasoning-demo',provider:'openai',label:'Reasoning preset',note:'Demonstration of thinking controls',thinking:true,image:false},
{id:'claude-sonnet',provider:'anthropic',label:'Claude Sonnet',note:'Existing prototype preset',thinking:true,image:true},
{id:'claude-writing-demo',provider:'anthropic',label:'Writing preset',note:'An alternative demo configuration',thinking:false,image:false},
{id:'grok-reference-46',provider:'xai',label:'Grok 4.6',note:'Flagship with live search',thinking:true,image:true,reference:true},
{id:'grok-reference-420',provider:'xai',label:'Grok 4.20',note:'Extended reasoning for tough prompts',thinking:true,image:true,reference:true},
{id:'grok-reference-45',provider:'xai',label:'Grok 4.5',note:'Previous generation, broad knowledge',thinking:true,image:true,reference:true},
{id:'gemini-flash',provider:'google',label:'Gemini Flash',note:'Existing prototype preset',thinking:false,image:true},
{id:'google-reasoning-demo',provider:'google',label:'Reasoning preset',note:'Demonstration of thinking controls',thinking:true,image:true},
{id:'api-cli',provider:'cli',label:'API Model CLI',note:'Your local CLI session · not connected',thinking:false,image:false},
{id:'custom-cli',provider:'cli',label:'Custom CLI profile',note:'Local profile placeholder · not connected',thinking:false,image:false}];
root.RafiiModels={providers,models};
})(globalThis);
