/* Original, dependency-free state helpers. No network calls or account access. */
(function (root) {
  'use strict';
  const locales=typeof module==='object'&&module.exports?require('./locales.js'):root.RafiiLocales;
  const channels = Object.freeze([
    {id:'instagram', name:'Instagram', handle:'@demo.studio', color:'#ffffff', kind:'Visual stories'},
    {id:'linkedin', name:'LinkedIn', handle:'Demo profile', color:'#ffffff', kind:'Professional ideas'},
    {id:'threads', name:'Threads', handle:'@demo.studio', color:'#ffffff', kind:'Conversations'},
    {id:'x', name:'X', handle:'@demo.studio', color:'#ffffff', kind:'Short thoughts'},
    {id:'facebook', name:'Facebook', handle:'Demo studio', color:'#ffffff', kind:'Your community'},
    {id:'red', name:'Xiaohongshu', handle:'Demo studio', color:'#ffffff', kind:'Everyday inspiration'}
  ]);
  const formats = Object.freeze([
    {id:'post',name:'Post',description:'One thought. Beautifully told.',hint:'Drop a thought, a link,\nor a beautifully messy idea…'},
    {id:'thread',name:'Thread',description:'Give your story room to unfold.',hint:'What idea deserves\na little more room?…'},
    {id:'carousel',name:'Carousel',description:'A story, one slide at a time.',hint:'What would you love\nto explain, slide by slide?…'},
    {id:'video',name:'Video script',description:'Set your ideas in motion.',hint:'What story should\nyour next video tell?…'}
  ]);
  const ids = new Set(channels.map(c=>c.id));
  function validChannels(list) { return [...new Set(Array.isArray(list) ? list : [])].filter(id=>ids.has(id)); }
  function toggleChannel(list,id) {
    const copy=validChannels(list); if(!ids.has(id)) return copy;
    return copy.includes(id)?copy.filter(item=>item!==id):[...copy,id];
  }
  function selectionSummary(list,limit=3) {
    const selected=validChannels(list); const cap=Math.max(0,limit);
    return {count:selected.length,visible:selected.slice(0,cap),overflow:Math.max(0,selected.length-cap)};
  }
  function validate(idea,list) {
    if (typeof idea!=='string'||!idea.trim()) return {ok:false,message:'Start with a little idea.'};
    if (idea.length>2000) return {ok:false,message:'Keep your idea under 2,000 characters.'};
    if (!validChannels(list).length) return {ok:false,message:'Choose at least one channel.'};
    return {ok:true,message:''};
  }
  function makeRequest({idea,channels:list,format='post',tone='neutral',language='en',editorialType='status_update',nativeFormat='text'}) {
    const check=validate(idea,list); if(!check.ok) throw new Error(check.message);
    if(!formats.some(f=>f.id===format)) throw new Error('Unknown content format.');
    if(!['neutral','warm','bold'].includes(tone)) throw new Error('Unknown tone.');
    if(!locales.entry(language)) throw new Error('Unknown template language.');
    return Object.freeze({idea:idea.trim(),channels:Object.freeze(validChannels(list)),format,tone,language,editorialType,nativeFormat});
  }
  function sampleDraft(request,channel) {
    if(!request.channels.includes(channel)) throw new Error('Account not selected in this request.');
    const lang=locales.entry(request.language)?.id||'en-us'; const zh=lang.startsWith('zh'); const ja=lang==='ja-jp'; const idea=request.idea;
    const intro=zh ? ({neutral:'一個值得分享的想法。',warm:'想和你分享一個小小的想法。',bold:'值得停下來想一想。'}[request.tone]) : ja ? ({neutral:'シェアしたくなる小さな気づき。',warm:'ちょっと共有したいことがあります。',bold:'立ち止まって考えたくなるひと言。'}[request.tone]) : ({neutral:'A thought worth sharing.',warm:'A little something I wanted to share with you.',bold:'Here’s a thought worth stopping for.'}[request.tone]);
    const closes=zh ? {
      instagram:'你有類似的經驗嗎？在留言告訴我。',linkedin:'這和你的經驗有甚麼共鳴？',threads:'你怎麼想？',x:'你的看法呢？',facebook:'歡迎分享你的故事。',red:'把這個想法留給需要的你。'
    } : ja ? {
      instagram:'あなたならどう感じますか？コメントで教えてください。',linkedin:'あなたの経験とはどうつながりますか？',threads:'あなたはどう思いますか？',x:'あなたの考えは？',facebook:'あなたの話もぜひ聞かせてください。',red:'あとで読み返したい小さなインスピレーション。'
    } : {
      instagram:'Have you had a moment like this? Tell me below.',linkedin:'How does this connect with your own experience?',threads:'What’s your take?',x:'Your thoughts?',facebook:'I’d love to hear your story, too.',red:'A little inspiration to come back to.'
    };
    let text;
    if(request.format==='post') text=`${intro}\n\n${idea}\n\n${closes[channel]}`;
    if(request.format==='thread') text=zh ? `1/3\n${intro}\n\n2/3\n${idea}\n\n3/3\n${closes[channel]}` : `1/3\n${intro}\n\n2/3\n${idea}\n\n3/3\n${closes[channel]}`;
    if(request.format==='carousel') text=zh ? `第 1 頁 · 開場\n${intro}\n\n第 2 頁 · 核心想法\n${idea}\n\n第 3 頁 · 你的故事\n[加入一個你的真實例子。]\n\n第 4 頁 · 一起交流\n${closes[channel]}` :
      `Slide 1 · The hook\n${intro}\n\nSlide 2 · The idea\n${idea}\n\nSlide 3 · Make it yours\n[Add one real example from your own experience.]\n\nSlide 4 · Start a conversation\n${closes[channel]}`;
    if(request.format==='video') text=zh ? `00:00–00:03 · 開場\n${intro}\n\n00:03–00:15 · 核心想法\n${idea}\n\n00:15–00:25 · 畫面\n[加入一個展示這個想法的鏡頭。]\n\n00:25–00:30 · 結尾\n${closes[channel]}` :
      `00:00–00:03 · Hook\n${intro}\n\n00:03–00:15 · The idea\n${idea}\n\n00:15–00:25 · Show, don’t tell\n[Add one shot that brings your idea to life.]\n\n00:25–00:30 · Closing\n${closes[channel]}`;
    return {channel,format:request.format,text,simulated:true,note:zh?'Chinese template; your input is not translated.':ja?'Japanese template; your input is not translated.':lang.startsWith('en')?'Template preview, not AI-written. Platform capabilities are not verified.':'Language preference recorded. English placeholder only; translation is not connected.'};
  }
  const api={channels,formats,toggleChannel,selectionSummary,validate,makeRequest,sampleDraft};
  if(typeof module==='object'&&module.exports) module.exports=api;
  else root.RafiiCore=api;
})(typeof globalThis!=='undefined'?globalThis:this);
