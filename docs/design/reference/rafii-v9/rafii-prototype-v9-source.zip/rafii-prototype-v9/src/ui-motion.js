/* Cancellable local transitions. No timer-based claims about AI or publishing. */
(function(root){
 const running=new WeakMap();
 function cancel(el){const old=running.get(el);if(old){old.forEach(a=>a.cancel());running.delete(el);}}
 function swap(host,html,enabled=true,direction=1){
  if(host.dataset.html===html)return;
  cancel(host);host.querySelectorAll('.switch-outgoing').forEach(n=>n.remove());
  const old=host.querySelector(':scope > .switch-current');
  const height=host.getBoundingClientRect().height;
  const incoming=document.createElement('div');incoming.className='switch-current';incoming.innerHTML=html;
  host.dataset.html=html;
  if(!old||!enabled||!host.getClientRects().length){host.replaceChildren(incoming);host.style.height='';return;}
  old.className='switch-outgoing';old.inert=true;old.setAttribute('aria-hidden','true');
  old.querySelectorAll('[id]').forEach(n=>n.removeAttribute('id'));
  host.append(incoming);host.style.height='auto';const target=incoming.getBoundingClientRect().height;
  const opts={duration:430,easing:'cubic-bezier(.22,1,.36,1)',fill:'both'};
  const a=old.animate([{opacity:1,transform:'translateX(0)'},{opacity:0,transform:`translateX(${-direction*18}px)`}],opts);
  const b=incoming.animate([{opacity:0,transform:`translateX(${direction*22}px)`},{opacity:1,transform:'translateX(0)'}],opts);
  const c=host.animate([{height:height+'px'},{height:target+'px'}],opts);
  const active=[a,b,c];running.set(host,active);
  Promise.all(active.map(x=>x.finished.catch(()=>{}))).then(()=>{if(running.get(host)!==active)return;old.remove();active.forEach(x=>x.cancel());host.style.height='';running.delete(host);});
 }
 function height(el,before,show,enabled=true,endHeight=null){
  cancel(el);el.style.height=show?'auto':'0px';el.style.overflow='hidden';el.inert=!show;
  const after=endHeight===null?(show?el.getBoundingClientRect().height:0):endHeight;
  if(!enabled||Math.abs(before-after)<.5){el.style.height=show?'auto':'0px';return;}
  const a=el.animate([{height:before+'px'},{height:after+'px'}],{duration:480,easing:'cubic-bezier(.22,1,.36,1)',fill:'both'});
  const animations=[a];running.set(el,animations);
  if(show&&before<10){const inner=el.firstElementChild;if(inner)animations.push(inner.animate([{opacity:0,transform:'translateY(-7px)'},{opacity:1,transform:'translateY(0)'}],{duration:330,delay:100,easing:'cubic-bezier(.22,1,.36,1)',fill:'backwards'}));}
  a.finished.catch(()=>{}).then(()=>{if(running.get(el)!==animations)return;animations.forEach(x=>x.cancel());el.style.height=show?'auto':'0px';running.delete(el);});
 }
 root.RafiiUI={swap,height,cancel};
})(globalThis);
