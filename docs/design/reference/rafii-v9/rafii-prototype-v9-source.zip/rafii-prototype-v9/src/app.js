/* Rafii UI prototype. Offline: no APIs, telemetry or remote assets. Only folders may persist locally. */
(function () {
'use strict';
const C=window.RafiiCore;
const P=window.RafiiPhones;
const $=(selector,root=document)=>root.querySelector(selector);
const $$=(selector,root=document)=>Array.from(root.querySelectorAll(selector));
const iconPaths={
 folder:'<path d="M3 7V5a2 2 0 0 1 2-2h5l3 3h6a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7Z"/><path d="M3 9h18"/>',
 'folder-plus':'<path d="M3 7V5a2 2 0 0 1 2-2h5l3 3h6a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7Z"/><path d="M9 14h6m-3-3v6"/>',
 music:'<path d="M9 18V5l11-2v13M9 9l11-2"/><ellipse cx="6" cy="18" rx="3" ry="3"/><ellipse cx="17" cy="16" rx="3" ry="3"/>',
 briefcase:'<rect x="3" y="7" width="18" height="14" rx="3"/><path d="M8 7V3h8v4M3 12c5 4 13 4 18 0m-9 0v5"/>',
 pin:'<path d="m9 3 6 0-1 6 4 4v2H6v-2l4-4-1-6ZM12 15v7"/>',
 'pin-off':'<path d="M3 3l18 18M10 3h5l-1 6 4 4v2h-3M9 9l-3 4v2h6v7"/>',
 more:'<circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/>',
 pencil:'<path d="m4 15 12-12 5 5L9 20H4v-5ZM13 6l5 5"/>',
 'arrow-up':'<path d="M12 21V3m-7 7 7-7 7 7"/>',
 'arrow-down':'<path d="M12 3v18m-7-7 7 7 7-7"/>',
 brain:'<path d="M12 4c-3-4-8 0-6 3-5 0-5 7-1 7-3 5 3 9 6 5V4Zm0 0c3-4 8 0 6 3 5 0 5 7 1 7 3 5-3 9-6 5V4ZM6 7l2 3m-3 4h3m10-7-2 3m3 4h-3"/>',
 image:'<rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="8" cy="8" r="2"/><path d="m5 20 8-10 7 8"/>', 
 globe:'<circle cx="12" cy="12" r="9"/><ellipse cx="12" cy="12" rx="4" ry="9"/><path d="M3 12h18"/>',
 chip:'<rect x="6" y="6" width="12" height="12" rx="3"/><path d="M9 2v4m6-4v4M9 18v4m6-4v4M2 9h4m-4 6h4m12-6h4m-4 6h4"/>',
 wave:'<path d="M3 10v4m4-7v10m5-14v18m5-14v10m4-7v4"/>',
 brand:'<path d="M8 25V10a6 6 0 1 1 6 6H8m8 0 7 9"/>',
 home:'<path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1Z"/>',
 calendar:'<rect x="3" y="5" width="18" height="16" rx="3"/><path d="M16 3v4M8 3v4M3 11h18m-13 5h2"/>',
 queue:'<rect x="3" y="4" width="4" height="4" rx="1"/><rect x="3" y="11" width="4" height="4" rx="1"/><path d="M11 5h10m-10 3h6m-6 4h10m-10 3h6M3 20h18"/>',
 inbox:'<path d="M4 5h16l2 10v5H2v-5Z"/><path d="M2 15h6l2 3h4l2-3h6"/>',
 sliders:'<path d="M5 3v4m0 4v10M12 3v10m0 4v4m7-18v4m0 4v10"/><path d="M2 7h6m1 10h6m1-10h6"/>',
 chevron:'<path d="m6 9 6 6 6-6"/>',
 lock:'<rect x="5" y="10" width="14" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3m-4 5v2"/>',
 'arrow-up-right':'<path d="M6 18 18 6M6 6h12v12"/>',
 'arrow-right':'<path d="M4 12h16m-6-6 6 6-6 6"/>',
 'arrow-left':'<path d="M20 12H4m6-6-6 6 6 6"/>',
 'corner-up':'<path d="M6 19v-6a4 4 0 0 1 4-4h8m-5-5 5 5-5 5"/>',
 spark:'<path d="m12 2 2.5 7.5L22 12l-7.5 2.5L12 22l-2.5-7.5L2 12l7.5-2.5Z"/>',
 shield:'<path d="m12 3 8 3v6c0 5-8 9-8 9s-8-4-8-9V6Z"/><path d="m8 12 3 3 5-6"/>',
 heart:'<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0l-1 1-1-1a5.5 5.5 0 0 0-7.8 7.8L12 21l8.8-8.6a5.5 5.5 0 0 0 0-7.8Z"/>',
 comment:'<path d="M21 11.5a8.5 8.5 0 0 1-8.5 8.5H3l2-4a8.5 8.5 0 1 1 16-4.5Z"/>',
 send:'<path d="m22 2-7 20-4-9-9-4 20-7ZM22 2 11 13"/>',
 bookmark:'<path d="M6 3h12v18l-6-4-6 4Z"/>',
 close:'<path d="m6 6 12 12M6 18 18 6"/>',
 search:'<circle cx="10.5" cy="10.5" r="7"/><path d="m16 16 5 5"/>',
 check:'<path d="m5 12 4 4L19 6"/>',
 info:'<circle cx="12" cy="12" r="9"/><path d="M12 11v6m0-10v.1"/>',
 paperclip:'<path d="m8 13 7-7a3 3 0 0 1 4 4L9 20a5 5 0 0 1-7-7L13 2a4 4 0 0 1 6 6L8 19"/>',
 plus:'<path d="M12 5v14M5 12h14"/>',
 refresh:'<path d="M20 7a8 8 0 1 0 1 8M20 2v6h-6"/>',
 menu:'<path d="M4 6h16M4 12h16M4 18h16"/>',
 copy:'<rect x="8" y="8" width="13" height="13" rx="2"/><path d="M16 4V3H3v13h1"/>',
 file:'<path d="M14 2H5v20h14V7Zm0 0v6h5M8 13h8m-8 4h6"/>',
 trash:'<path d="M3 6h18M9 6V3h6v3M6 6l1 15h10l1-15M10 10v7m4-7v7"/>',
 play:'<path d="m9 5 11 7-11 7Z"/>'
};
function icon(name) {
 const brand=name==='brand';
 return `<svg viewBox="0 0 ${brand?'32 32':'24 24'}" fill="none" stroke="currentColor" stroke-width="${brand?'3.5':'1.65'}" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${iconPaths[name]||iconPaths.spark}</svg>`;
}
function platform(id) {
 const c=C.channels.find(item=>item.id===id); if(!c) return '';
 const instagram='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" aria-hidden="true"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none"/></svg>';
 const x='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="M4 3h4l12 18h-4ZM20 3 4 21"/></svg>';
 const contents={instagram,linkedin:'<span class="platform-letters">in</span>',threads:P.icon('threads',24),x,facebook:'<span class="platform-letters">f</span>',red:'<span class="platform-letters">小红书</span>'};
 return `<span class="platform platform-${id}" aria-hidden="true">${contents[id]}</span>`;
}
function decorate(root=document) {
 $$('[data-icon]',root).forEach(node=>{node.innerHTML=icon(node.dataset.icon);});
 $$('[data-platform]',root).forEach(node=>{node.innerHTML=platform(node.dataset.platform);});
}
function escapeHTML(value){return String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
const motionQuery=window.matchMedia('(prefers-reduced-motion: reduce)');
const canAnimate=()=>!motionQuery.matches&&!document.body.classList.contains('reduced-motion');
const ease='cubic-bezier(.2,.8,.2,1)';
const tones={neutral:'Neutral',warm:'Warm',bold:'Bold'};
const L=window.RafiiLocales;
const phoneDeck=window.RafiiMotion.createPhoneDeck({renderPhone:P.renderPhone,motionAllowed:canAnimate});
const T=window.RafiiTaxonomy;
const UI=window.RafiiUI;
const languageOptions=L.entries;
const modelOptions=window.RafiiModels.models;
const defaultChannelLanguages={instagram:'en-us',linkedin:'en-us',threads:'en-us',x:'en-us',facebook:'en-us',red:'zh-cn'};
const channelLanguageTemplates={instagram:'Home feed',linkedin:'Home feed',threads:'For you',x:'For you',facebook:'Home feed',red:'Note detail'};
function languageInfo(id){return L.entry(id)||L.entry('en-US');}
function languageLabel(id){return languageInfo(id).label;}
function languageShort(id){return languageInfo(id).short;}
function modelLabel(id){return (modelOptions.find(option=>option.id===id)||modelOptions[0]).label;}
function outputLanguageFor(channel){return state.sameLanguage?state.language:(state.channelLanguages[channel]||state.language);}
function initialSources(){return [
 {id:'sample-voice',name:'A little about the voice',content:'Sample notes: be thoughtful, direct, and curious. Sound like a person, not a press release.',include:true,quote:false,sample:true},
 {id:'sample-brief',name:'The creative brief',content:'Sample brief: share the process, not just the finished thing. Invite a genuine conversation.',include:true,quote:false,sample:true}
];}
function initialState(){return {folderContext:null,channels:['instagram','linkedin','threads'],format:'post',editorialType:'status_update',nativeFormat:'text',tone:'neutral',language:'en-us',sameLanguage:false,channelLanguages:{...defaultChannelLanguages},model:'gpt-4o',thinking:{},sources:initialSources(),queue:[],request:null,drafts:{},activeDraft:null,busy:false,view:'home',simulateError:false,requestId:0};}
let channelFolders=null;
let state=initialState(); let draftChannels=[]; let draftTone='neutral'; let draftLanguage=state.language; let draftSameLanguage=state.sameLanguage; let draftChannelLanguages={...state.channelLanguages}; let draftModel=state.model; let editingLanguageChannel='instagram'; let activeDialog=null; let toastTimer; let timerList=[]; let generationToken=0; let pendingFocus=null;
let sharedConfirmed=true,catalogOpen=false,localeQuery='',localeRows=[],localeActive=0,recentLocales=[];
let modelProvider='openai',modelQuery='',draftThinking={};
let taxonomyTab='editorial',taxonomyQuery='',draftEditorial='status_update',draftNative='text';
function taxonomyItem(id){return T.items.find(i=>i.id===id);}
function legacyFormat(id){return id==='thread'?'thread':id==='carousel'?'carousel':['short_vertical_video','long_video','livestream'].includes(id)?'video':'post';}
function tinyThumbnail(id){return libraryMini(id);}
function taxonomySummary(){return `${taxonomyItem(state.editorialType).title} · ${taxonomyItem(state.nativeFormat).title}`;}
const dialogTriggers=new WeakMap(); const promptSamples={
 behind:'A behind-the-scenes thought: the quiet, imperfect work is usually where the best ideas begin.',
 lesson:'One thing piano practice taught me about creating: consistency matters more than waiting for inspiration.'
};
function toast(text){const el=$('#toast');el.textContent=text;el.classList.add('visible');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('visible'),3500);}
function schedule(fn,delay){const t=setTimeout(fn,delay);timerList.push(t);return t;}
function clearTimers(){timerList.forEach(clearTimeout);timerList=[];generationToken++;}
function renderComposer(){
 const summary=C.selectionSummary(state.channels);
 $('#format-label').innerHTML=`<strong>${escapeHTML(taxonomyItem(state.editorialType).title)}</strong><small>${escapeHTML(taxonomyItem(state.nativeFormat).title)}</small>`;
 $('#format-trigger').setAttribute('aria-label',`Choose content type and native format, ${taxonomySummary()}`);
 $('#mini-format').className='mini-format taxonomy-mini';$('#mini-format').innerHTML=tinyThumbnail(state.editorialType)+tinyThumbnail(state.nativeFormat);
 $('#idea').placeholder=C.formats.find(f=>f.id===state.format).hint;
 $('#channel-stack').innerHTML=summary.count?summary.visible.map(platform).join('')+(summary.overflow?`<span class="overflow">+${summary.overflow}</span>`:''):'<span class="empty-stack">Channels</span>';
 $('#channels-count').textContent=String(summary.count);
 $('#channel-folder-summary').textContent=state.folderContext?.sources?.length?channelFolders.selectionLabel(state.channels,state.folderContext):'Channels';
 $('#channels-trigger').setAttribute('aria-label',`Choose channels, ${summary.count} selected`);
 const languages=[...new Set(state.channels.map(outputLanguageFor))];
 $('#language-summary').textContent=state.sameLanguage?languageLabel(state.language):languages.length===1?languageLabel(languages[0]):'Per channel';
 $('#model-summary').textContent=modelLabel(state.model);
 $('#voice-summary').textContent=tones[state.tone];
 $('#source-count').textContent=String(state.sources.length);
 $('#generate-count').textContent=String(summary.count);
 $('#generate-count').hidden=state.busy||summary.count===0;
 const input=$('#idea').value; const check=C.validate(input,state.channels);
 $('#generate').disabled=state.busy||!check.ok;
 $('#generate').classList.toggle('busy',state.busy);
 $('#generate-label').textContent=state.busy?'Shaping your previews':!summary.count?'Choose channels first':state.request?'Generate again':'Generate drafts';
 $('#input-help').textContent=state.busy?'Simulating locally. No AI or network calls.':!summary.count?'Open the channel stack and pick at least one.':input.trim()?'One idea. A draft preview for every selected channel.':'Start with an idea. We’ll take it from there.';
 $('#cancel-generation').hidden=!state.busy;
 ['#idea','#format-trigger','#channels-trigger','#context-trigger','#try-idea','#language-trigger','#model-trigger','#voice-trigger','#expand-idea-trigger'].forEach(s=>{const node=$(s); if(node) node.disabled=state.busy;});
 $$('[data-prompt]').forEach(b=>b.disabled=state.busy);
 $('#try-idea').hidden=input.length>0;
 $('#character-count').hidden=input.length===0;
 $('#character-count').textContent=`${input.length.toLocaleString()} / 2,000`;
 if(!state.request)renderShowcase();
 observeArt();
}
function animatePanel(dialog,trigger){
 if(!canAnimate()||typeof dialog.animate!=='function')return;
 const r=dialog.getBoundingClientRect(); const t=trigger?.getBoundingClientRect();
 const dx=t?(t.left+t.width/2-r.left-r.width/2):0;
 const dy=t?(t.top+t.height/2-r.top-r.height/2):30;
 const podOrigin=trigger?.classList.contains('pod-part');
 const sx=podOrigin?Math.max(.23,t.width/r.width):.93;
 const sy=podOrigin?Math.max(.12,t.height/r.height):.89;
 dialog.animate([{opacity:0,transform:`translate(${podOrigin?dx:dx*.1}px,${podOrigin?dy:dy*.1}px) scale(${sx},${sy})`,borderRadius:'35px'},{opacity:1,transform:'translate(0,0) scale(1)',borderRadius:'28px'}],{duration:podOrigin?560:400,easing:ease});
 if(dialog.id==='channel-dialog'){
  $$('.channel-tile-inner>.platform',dialog).forEach((node,i)=>node.animate([
   {opacity:0,transform:`translate(${(2-i%3)*15}px,30px) rotate(${i%2?12:-12}deg) scale(.65)`},
   {opacity:1,transform:'translate(0,0) rotate(-5deg) scale(1)'}
  ],{duration:560,delay:65+i*45,easing:ease,fill:'backwards'}));
 }
 if(dialog.id==='format-dialog'){
  $$('.format-option',dialog).forEach((node,i)=>{
   const rest=getComputedStyle(node).transform;
   node.animate([{opacity:0,transform:`translate(${(1.5-i)*33}px,42px) rotate(0) scale(.87)`},{opacity:1,transform:rest}],{duration:580,delay:70+i*50,easing:ease,fill:'backwards'});
  });
 }
 if(dialog.id==='language-dialog'){
  $$('.language-chip',dialog).forEach((node,i)=>node.animate([{opacity:0,transform:'translateY(16px) scale(.92)'},{opacity:1,transform:'translateY(0) scale(1)'}],{duration:420,delay:40+i*35,easing:ease,fill:'backwards'}));
  $$('.channel-language-row',dialog).forEach((node,i)=>node.animate([{opacity:0,transform:'translateY(12px)'},{opacity:1,transform:'translateY(0)'}],{duration:420,delay:120+i*35,easing:ease,fill:'backwards'}));
 }
 if(dialog.id==='model-dialog' || dialog.id==='idea-dialog'){
  $$('.model-option',dialog).forEach((node,i)=>node.animate([{opacity:0,transform:'translateY(12px) scale(.96)'},{opacity:1,transform:'translateY(0) scale(1)'}],{duration:420,delay:50+i*35,easing:ease,fill:'backwards'}));
 }
}
function openDialog(id,trigger){
 if(activeDialog) closeDialog(activeDialog,false);
 const dialog=$(`#${id}`); if(!dialog)return;
 if(id==='channel-dialog')channelFolders.open({platforms:state.channels,context:state.folderContext});
 if(id==='format-dialog'){taxonomyTab='editorial';taxonomyQuery='';draftEditorial=state.editorialType;draftNative=state.nativeFormat;$('#taxonomy-search').value='';renderFormatDeck();}
 if(id==='language-dialog'){draftLanguage=state.language;draftSameLanguage=state.sameLanguage;draftChannelLanguages={...state.channelLanguages};editingLanguageChannel=state.activeDraft||state.channels[0]||'instagram';sharedConfirmed=true;catalogOpen=false;localeQuery='';$('#locale-search').value='';renderLanguageDialog();}
 if(id==='model-dialog'){draftModel=state.model;draftThinking={...state.thinking};modelProvider=modelOptions.find(m=>m.id===draftModel).provider;modelQuery='';$('#model-search').value='';renderModelDialog();}
 if(id==='tune-dialog'){draftTone=state.tone;renderTones();}
 if(id==='idea-dialog'){syncExpandedIdea(true);}
 if(id==='context-dialog'){renderSources();$('#source-error').textContent='';}
 if(id==='controls-dialog'){$('#reduce-motion').checked=motionQuery.matches||document.body.classList.contains('reduced-motion');$('#simulate-error').checked=state.simulateError;}
 activeDialog=dialog;dialogTriggers.set(dialog,trigger||document.activeElement);
 trigger?.setAttribute('aria-expanded','true');
 dialog.showModal();document.body.style.overflow='hidden';if(id==='model-dialog'){requestAnimationFrame(moveProviderLens);}$$('.preview-channel-dock',dialog).forEach(moveDockLens);
 // Focus a stable close control, not an input: mobile keyboards should not obscure a new sheet.
 if(id==='channel-dialog')$('#channel-title').focus({preventScroll:true});else $('.close-dialog',dialog)?.focus({preventScroll:true});
 animatePanel(dialog,trigger);
}
function closeDialog(dialog=activeDialog,animate=true){
 if(!dialog||!dialog.open)return Promise.resolve();
 const trigger=dialogTriggers.get(dialog);trigger?.setAttribute('aria-expanded','false');
 function finish(){dialog.close();if(activeDialog===dialog){activeDialog=null;document.body.style.overflow='';}if(trigger&&document.contains(trigger)&&!trigger.disabled)trigger.focus({preventScroll:true});}
 if(!animate||!canAnimate()||typeof dialog.animate!=='function'){finish();return Promise.resolve();}
 // Disable only the closing surface; changing another panel always closes this one first.
 const a=dialog.animate([{opacity:1,transform:'translateY(0) scale(1)'},{opacity:0,transform:'translateY(12px) scale(.965)'}],{duration:170,easing:'ease-in',fill:'forwards'});
 return a.finished.catch(()=>{}).then(()=>{a.cancel();finish();});
}
// v7 Content Library. Filtering never mutates draft channels or committed choices.
const G=window.RafiiLibrary;
let libraryView='gallery',libraryCategory={editorial:'all',native:'all'},libraryPlatform='all';
let libraryPaused=false,librarySwapToken=0,libraryAnimations=[],glyphSerial=0;
let tipTarget=null,tipTimer=0,evidenceTrigger=null;
const artworkObserver=typeof IntersectionObserver==='function'?new IntersectionObserver(entries=>entries.forEach(e=>e.target.classList.toggle('art-visible',e.isIntersecting&&!document.hidden)),{threshold:.05}):null;
function categoryInfo(id,dimension=taxonomyTab){return G.categories[dimension].find(c=>c.id===id);}
function libraryMini(id){
 const raw=G.mini[id];if(!raw)return '<span class="legacy-art" aria-label="Legacy item">?</span>';
 return `<span class="compact-art artwork" data-art-id="${id}" style="--art-delay:-${T.items.findIndex(i=>i.id===id)%7*.6}s">${raw}</span>`;
}
function libraryArt(id){
 let raw=G.art[id];if(!raw)throw new Error('Missing v7 artwork: '+id);
 const ns='art-'+(++glyphSerial)+'-';
 raw=raw.replace(/id="([^"]+)"/g,(_,x)=>`id="${ns+x}"`).replace(/url\(#([^)]*)\)/g,(_,x)=>`url(#${ns+x})`);
 raw=raw.replace('<g style="filter:grayscale(1)">','<g class="art-motif" style="filter:grayscale(1)">');
 // Independent foreground accent plus a very restrained scene movement. Text remains stationary relative to the scene.
 raw=raw.replace(/(<g class="art-motif"[^>]*>)([\s\S]*)(<\/g><\/svg>)$/,(_,head,body,tail)=>{
  const last=body.lastIndexOf('<circle ');if(last>=0){const end=body.indexOf('/>',last);if(end>=0)body=body.slice(0,last)+'<g class="art-accent">'+body.slice(last,end+2)+'</g>'+body.slice(end+2);}
  return head+body+tail;
 });
 return `<span class="large-art artwork" data-art-id="${id}" style="--art-delay:-${T.items.findIndex(i=>i.id===id)%7*.6}s">${raw}</span>`;
}
function observeArt(){
 if(artworkObserver)artworkObserver.disconnect();
 $$('.artwork').forEach(el=>{if(artworkObserver)artworkObserver.observe(el);else el.classList.add('art-visible');});
}
function appFitBadges(ids){
 if(!ids.length)return '<span class="special-surface">Specialist surface</span>';
 return `<span class="fit-apps" aria-label="Suggested app fit: ${ids.map(id=>G.platforms.find(p=>p.id===id).label).join(', ')}">${ids.slice(0,4).map(id=>`<span title="${G.platforms.find(p=>p.id===id).label}">${platform(id)}</span>`).join('')}${ids.length>4?`<span class="fit-overflow">+${ids.length-4}</span>`:''}</span>`;
}
function itemTags(item){const d=G.items[item.id];return `<span class="item-tags">${d.tags.map(t=>`<span>${escapeHTML(t)}</span>`).join('')}</span>`;}
function infoButton(item){return `<button class="info-button" data-info="${item.id}" aria-label="About ${escapeHTML(item.title)}" aria-expanded="false">${icon('info')}</button>`;}
function taxonomyCard(item,chosen=false,disabled=false){
 const d=G.items[item.id],s=chosen?'true':'false';
 if(libraryView==='list')return `<article class="item-shell list-shell" data-selected="${s}"><button class="taxonomy-card list-card" data-taxonomy-item="${item.id}" aria-pressed="${s}" ${disabled?'disabled':''}>${libraryMini(item.id)}<span class="item-copy"><strong>${escapeHTML(item.title)}</strong>${itemTags(item)}</span><span class="list-fit">${appFitBadges(d.platforms)}</span><span class="selection-tick" aria-hidden="true">${icon('check')}</span></button>${infoButton(item)}</article>`;
 if(libraryView==='pairings')return pairingCard(item,chosen,disabled);
 return `<article class="item-shell gallery-shell" data-selected="${s}"><button class="taxonomy-card ${item.dimension}-card gallery-card" data-taxonomy-item="${item.id}" aria-pressed="${s}" ${disabled?'disabled':''}><span class="taxonomy-art">${libraryArt(item.id)}<span class="taxonomy-check">${icon('check')}</span></span><span class="gallery-copy">${itemTags(item)}<strong>${escapeHTML(item.title)}</strong><span class="taxonomy-description">${escapeHTML(item.description)}</span><span class="gallery-fit"><small>SUGGESTED FIT</small>${appFitBadges(d.platforms)}</span></span></button>${infoButton(item)}</article>`;
}
function pairingCard(item,chosen,disabled){
 const d=G.items[item.id];let pairs=d.pairings.filter(p=>libraryPlatform==='all'||p.platforms.includes(libraryPlatform));
 // Pairings for a native format explicitly show a suggested editorial intent; never imply the intent was measured.
 pairs=pairs.slice(0,2);
 return `<article class="item-shell guide-shell" data-selected="${chosen}"><div class="guide-heading"><button class="taxonomy-card guide-select" data-taxonomy-item="${item.id}" aria-pressed="${chosen}" ${disabled?'disabled':''}>${libraryMini(item.id)}<span class="item-copy">${itemTags(item)}<strong>${escapeHTML(item.title)}</strong></span><span class="selection-tick">${icon('check')}</span></button>${infoButton(item)}</div><div class="guide-routes">${pairs.map(p=>{
  const other=taxonomyItem(item.dimension==='editorial'?p.native:p.editorial);
  const main=G.evidence[p.evidence[0]];
  return `<div class="guide-route"><div class="route-map"><span class="route-link" aria-hidden="true">↳</span>${libraryMini(other.id)}<div class="route-title"><small>${item.dimension==='editorial'?'PRESENT AS':'TRY THIS INTENT'}</small><strong>${escapeHTML(other.title)}</strong></div><span class="route-arrow" aria-hidden="true">→</span>${appFitBadges(p.platforms)}</div><p>${escapeHTML(p.why)}</p><div class="route-actions"><button class="evidence-link" data-evidence-pair="${p.id}">${icon('info')}${main?escapeHTML(main.kind):'Fit suggestion'}</button><button class="use-pairing" data-use-pairing="${p.id}" aria-label="Use ${escapeHTML(taxonomyItem(p.editorial).title)} with ${escapeHTML(taxonomyItem(p.native).title)}">Use pairing <span aria-hidden="true">↗</span></button></div></div>`;
 }).join('')}</div></article>`;
}
function renderLibrarySelection(){
 $('#taxonomy-selection').innerHTML=[['editorial',draftEditorial],['native',draftNative]].map(([kind,id])=>`<div>${libraryMini(id)}<span><small>${kind==='editorial'?'EDITORIAL TYPE':'NATIVE FORMAT'}</small><strong>${escapeHTML(taxonomyItem(id).title)}</strong></span></div>`).join('');
}
function swapLibrary(html,animate){
 const host=$('#taxonomy-grid'),token=++librarySwapToken;
 libraryAnimations.forEach(a=>a.cancel());libraryAnimations=[];
 host.querySelectorAll('.library-outgoing').forEach(n=>n.remove());
 const old=$('.library-current',host),oldHeight=old?.getBoundingClientRect().height||0;
 const next=document.createElement('div');next.className='library-current';next.dataset.view=libraryView;next.innerHTML=html;
 if(!old||!animate||!canAnimate()){host.replaceChildren(next);host.style.height='';observeArt();return;}
 old.className='library-outgoing';old.inert=true;old.setAttribute('aria-hidden','true');old.querySelectorAll('[id]').forEach(el=>el.removeAttribute('id'));
 host.append(next);const h=next.getBoundingClientRect().height;
 const opt={duration:320,easing:'cubic-bezier(.22,1,.36,1)',fill:'both'};
 libraryAnimations=[old.animate([{opacity:1,transform:'translateY(0)'},{opacity:0,transform:'translateY(-6px)'}],opt),next.animate([{opacity:0,transform:'translateY(8px)'},{opacity:1,transform:'translateY(0)'}],opt)];
 const local=libraryAnimations;observeArt();
 Promise.all(local.map(a=>a.finished.catch(()=>{}))).then(()=>{if(token!==librarySwapToken)return;old.remove();local.forEach(a=>a.cancel());libraryAnimations=[];host.style.height='';observeArt();});
}
function renderFormatDeck(animate=false){
 closeLibraryTip(true);
 $$('.taxonomy-tabs [data-taxonomy-tab]').forEach(b=>b.setAttribute('aria-selected',String(b.dataset.taxonomyTab===taxonomyTab)));
 $('.taxonomy-tabs').dataset.tab=taxonomyTab;
 $('#taxonomy-panel').setAttribute('aria-labelledby',taxonomyTab==='editorial'?'editorial-tab':'native-tab');
 $('#taxonomy-search').placeholder=taxonomyTab==='editorial'?'Search editorial types…':'Search native formats…';
 const q=taxonomyQuery.toLowerCase().trim(),cat=libraryCategory[taxonomyTab],all=T.items.filter(i=>i.dimension===taxonomyTab);
 const items=all.filter(i=>{const d=G.items[i.id];return(cat==='all'||d.category===cat)&&(libraryPlatform==='all'||d.platforms.includes(libraryPlatform))&&`${i.title} ${i.id} ${i.description} ${i.family} ${d.tags.join(' ')} ${categoryInfo(d.category).label}`.toLowerCase().includes(q);});
 const options=[{id:'all',label:taxonomyTab==='editorial'?'All editorial types':'All native formats',description:'Find a purpose. Give it a form.'},...G.categories[taxonomyTab]];
 const count=c=>all.filter(i=>c.id==='all'||G.items[i.id].category===c.id).length;
 $('#library-category').innerHTML=options.map(c=>`<option value="${c.id}" ${c.id===cat?'selected':''}>${c.label} · ${count(c)}</option>`).join('');

 const active=options.find(c=>c.id===cat)||options[0];$('#category-title').textContent=active.label;$('#category-description').textContent=active.description;
 $$('.view-switch button').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.libraryView===libraryView)));
 $('.view-switch').style.setProperty('--view-index',['gallery','list','pairings'].indexOf(libraryView));
 $('#taxonomy-count').textContent=`${items.length} / ${all.length}`;
 $('#taxonomy-grid').dataset.view=libraryView;
 $('#taxonomy-empty').hidden=items.length>0;
 $('#pairings-intro').hidden=libraryView!=='pairings';
 $('#format-dialog').classList.toggle('art-paused',libraryPaused);
 swapLibrary(items.map(i=>taxonomyCard(i,i.id===(taxonomyTab==='editorial'?draftEditorial:draftNative))).join(''),animate);
 renderLibrarySelection();renderLibraryFilterSummary();observeArt();
}
// v8 groups secondary controls in one dismissible, keyboard-accessible panel.
let filterAnimation=null,filterTransition=0;
function renderLibraryFilterSummary(){
 const category=libraryCategory[taxonomyTab],count=Number(category!=='all')+Number(libraryPlatform!=='all');
 const badge=$('#library-filter-count');badge.textContent=String(count);badge.hidden=!count;
 $('#library-filter-trigger').setAttribute('aria-label',count?`Filters, ${count} active`:'Filters');
 $('#active-library-filters').hidden=!count;
 $('#active-library-filter-label').textContent=[category!=='all'?categoryInfo(category)?.label:null,libraryPlatform!=='all'?G.platforms.find(p=>p.id===libraryPlatform)?.label:null].filter(Boolean).join(' · ');
}
function openLibraryFilters(){
 closeLibraryTip(true);
 const layer=$('#library-filter-layer'),panel=$('#library-filter-panel'),trigger=$('#library-filter-trigger');
 ++filterTransition;if(filterAnimation){filterAnimation.cancel();filterAnimation=null;}
 layer.hidden=false;layer.inert=false;
 const r=$('#format-dialog').getBoundingClientRect(),t=trigger.getBoundingClientRect();
 const top=Math.max(12,Math.min(t.bottom-r.top+9,r.height-panel.scrollHeight-28));
 layer.style.setProperty('--filter-top',top+'px');
 $$('.taxonomy-head,.library-body,.taxonomy-footer',$('#format-dialog')).forEach(n=>n.inert=true);
 trigger.setAttribute('aria-expanded','true');$('#close-library-filters').focus({preventScroll:true});
 if(canAnimate())filterAnimation=panel.animate([{opacity:0,transform:'translateY(-8px) scale(.98)'},{opacity:1,transform:'translateY(0) scale(1)'}],{duration:270,easing:'cubic-bezier(.22,1,.36,1)'});
}
function closeLibraryFilters(immediate=false,restore=true){
 const layer=$('#library-filter-layer');if(layer.hidden)return;
 const token=++filterTransition;if(filterAnimation){filterAnimation.cancel();filterAnimation=null;}
 const finish=()=>{if(token!==filterTransition)return;layer.hidden=true;layer.inert=false;filterAnimation?.cancel();filterAnimation=null;
  $$('.taxonomy-head,.library-body,.taxonomy-footer',$('#format-dialog')).forEach(n=>n.inert=false);
  $('#library-filter-trigger').setAttribute('aria-expanded','false');
  if(restore&&$('#format-dialog').open)$('#library-filter-trigger').focus({preventScroll:true});};
 if(immediate||!canAnimate()){finish();return;}
 layer.inert=true;filterAnimation=$('#library-filter-panel').animate([{opacity:1,transform:'translateY(0) scale(1)'},{opacity:0,transform:'translateY(-5px) scale(.985)'}],{duration:170,easing:'ease-in',fill:'forwards'});
 filterAnimation.finished.catch(()=>{}).then(finish);
}
function closeLibraryTip(immediate=false){
 clearTimeout(tipTimer);const tip=$('#library-tooltip');const had=tipTarget||!tip.hidden;
 tip.classList.remove('tip-open');if(tipTarget){tipTarget.setAttribute('aria-expanded','false');tipTarget.removeAttribute('aria-describedby');}tipTarget=null;
 if(immediate||!canAnimate())tip.hidden=true;else tipTimer=setTimeout(()=>{if(!tipTarget)tip.hidden=true;},180);
 return Boolean(had);
}
function openLibraryTip(button){
 if(tipTarget===button){closeLibraryTip();return;}
 closeLibraryTip(true);const item=taxonomyItem(button.dataset.info);if(!item)return;
 const tip=$('#library-tooltip');$('strong',tip).textContent=item.title;$('p',tip).textContent=item.description;
 tip.hidden=false;tipTarget=button;button.setAttribute('aria-expanded','true');button.setAttribute('aria-describedby','library-tooltip');
 const r=button.getBoundingClientRect(),bounds=$('#format-dialog').getBoundingClientRect();
 tip.style.width=Math.min(280,bounds.width-28)+'px';const w=tip.offsetWidth,h=tip.offsetHeight;
 const left=Math.max(bounds.left+14,Math.min(bounds.right-w-14,r.right-w));
 let top=r.bottom+9;if(top+h>bounds.bottom-14)top=r.top-h-9;top=Math.max(bounds.top+12,top);
 tip.style.left=left+'px';tip.style.top=top+'px';
 requestAnimationFrame(()=>{if(tipTarget===button)tip.classList.add('tip-open');});
}
function showLibraryEvidence(pairId,trigger){
 closeLibraryTip(true);evidenceTrigger=trigger||document.activeElement;
 const p=G.pairings.find(p=>p.id===pairId);const refs=p?p.evidence:Object.keys(G.evidence);
 const lead=p?`<div class="evidence-pair"><span class="evidence-kind">FIT SUGGESTION</span><h4>${escapeHTML(taxonomyItem(p.editorial).title)} → ${escapeHTML(taxonomyItem(p.native).title)}</h4><p>${escapeHTML(p.why)}</p><small>${escapeHTML(p.surface_note)}</small></div>`:'';
 const text='<p class="evidence-principle">Suggested fit is our editorial judgement. <strong>Usage</strong> means how often a format was posted. <strong>Engagement</strong> measures a response. Neither establishes the most popular editorial topic, and the metrics are not directly comparable across platforms.</p>';
 $('#evidence-content').innerHTML=lead+text+(refs.length?refs.map(ref=>{const e=G.evidence[ref];return `<article class="evidence-record"><span class="evidence-kind">${e.kind.toUpperCase()}</span><h4>${e.label}</h4><p>${e.finding}</p><small>${e.sample}</small><p class="evidence-limit">${e.limit}</p><a href="${e.url}" target="_blank" rel="noopener noreferrer">${e.publisher} · ${e.date} ↗</a></article>`;}).join(''):'<div class="evidence-record"><h4>No quantitative signal attached.</h4><p>This is a composition suggestion, not a measured popular pairing.</p></div>')+'<p class="evidence-bottom">Research snapshot: 22 September 2026. No live analytics. Xiaohongshu pairings are design suggestions only; no comparable usage or engagement dataset was verified here. This prototype does not check API support, account eligibility or platform surfaces.</p>';
 const panel=$('#library-evidence');panel.hidden=false;
 $$('.taxonomy-head,.library-body,.taxonomy-footer',$('#format-dialog')).forEach(n=>n.inert=true);
 requestAnimationFrame(()=>panel.classList.add('evidence-open'));$('#close-library-evidence').focus({preventScroll:true});
}
function closeLibraryEvidence(){
 const panel=$('#library-evidence');if(panel.hidden)return false;
 panel.classList.remove('evidence-open');panel.hidden=true;
 $$('.taxonomy-head,.library-body,.taxonomy-footer',$('#format-dialog')).forEach(n=>n.inert=false);
 evidenceTrigger?.focus({preventScroll:true});return true;
}
function selectLibraryItem(id){
 if(taxonomyTab==='editorial')draftEditorial=id;else draftNative=id;
 $$('.library-current [data-taxonomy-item]').forEach(n=>{const selected=n.dataset.taxonomyItem===id;n.setAttribute('aria-pressed',String(selected));n.closest('.item-shell').dataset.selected=String(selected);});
 renderLibrarySelection();observeArt();
}
function wireTaxonomy(){
 $('.taxonomy-tabs').onclick=e=>{const b=e.target.closest('[data-taxonomy-tab]');if(!b||taxonomyTab===b.dataset.taxonomyTab)return;taxonomyTab=b.dataset.taxonomyTab;taxonomyQuery='';$('#taxonomy-search').value='';renderFormatDeck(true);$('#taxonomy-panel').scrollTop=0;};
 $('.taxonomy-tabs').onkeydown=e=>{if(!['ArrowLeft','ArrowRight','Home','End'].includes(e.key))return;e.preventDefault();taxonomyTab=e.key==='Home'?'editorial':e.key==='End'?'native':taxonomyTab==='editorial'?'native':'editorial';taxonomyQuery='';$('#taxonomy-search').value='';renderFormatDeck(true);$(`[data-taxonomy-tab="${taxonomyTab}"]`).focus();};
 $('.view-switch').onclick=e=>{const b=e.target.closest('[data-library-view]');if(!b||libraryView===b.dataset.libraryView)return;libraryView=b.dataset.libraryView;renderFormatDeck(true);$('#taxonomy-panel').scrollTop=0;};
 $('#library-category').onchange=e=>{libraryCategory[taxonomyTab]=e.target.value;renderFormatDeck(true);$('#taxonomy-panel').scrollTop=0;};
 $('#library-platform').onchange=e=>{libraryPlatform=e.target.value;renderFormatDeck(true);$('#taxonomy-panel').scrollTop=0;};
 $('#taxonomy-search').oninput=e=>{taxonomyQuery=e.target.value;renderFormatDeck(false);$('#taxonomy-panel').scrollTop=0;};
 $('#clear-library-filters').onclick=()=>{libraryCategory[taxonomyTab]='all';libraryPlatform='all';taxonomyQuery='';$('#taxonomy-search').value='';$('#library-platform').value='all';renderFormatDeck(true);$('#taxonomy-search').focus();};
 $('#taxonomy-grid').onclick=e=>{
  const info=e.target.closest('[data-info]');if(info){e.stopPropagation();openLibraryTip(info);return;}
  const why=e.target.closest('[data-evidence-pair]');if(why){showLibraryEvidence(why.dataset.evidencePair,why);return;}
  const use=e.target.closest('[data-use-pairing]');if(use){const p=G.pairings.find(p=>p.id===use.dataset.usePairing);draftEditorial=p.editorial;draftNative=p.native;selectLibraryItem(taxonomyTab==='editorial'?p.editorial:p.native);toast('Pairing selected. Your channels are unchanged.');return;}
  const b=e.target.closest('[data-taxonomy-item]');if(!b||b.disabled||b.closest('[inert]'))return;selectLibraryItem(b.dataset.taxonomyItem);
 };
 $('#taxonomy-grid').onkeydown=e=>{if(!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','Home','End'].includes(e.key))return;const cards=$$('.library-current [data-taxonomy-item]:not(:disabled)');const idx=cards.indexOf(document.activeElement);if(idx<0)return;e.preventDefault();const cols=libraryView==='gallery'&&innerWidth>600?2:1;const step={ArrowLeft:-1,ArrowRight:1,ArrowUp:-cols,ArrowDown:cols}[e.key]||0;const next=e.key==='Home'?0:e.key==='End'?cards.length-1:Math.max(0,Math.min(cards.length-1,idx+step));cards[next]?.focus();};
 $('#apply-taxonomy').onclick=()=>{closeLibraryTip(true);state.editorialType=draftEditorial;state.nativeFormat=draftNative;state.format=legacyFormat(draftNative);renderComposer();observeArt();closeDialog();};
 $('#library-filter-trigger').onclick=openLibraryFilters;
 $('#close-library-filters').onclick=()=>closeLibraryFilters();
 $('#library-filter-layer').onclick=e=>{if(e.target===$('#library-filter-layer'))closeLibraryFilters();};
 $('#clear-active-library-filters').onclick=()=>{libraryCategory[taxonomyTab]='all';libraryPlatform='all';$('#library-platform').value='all';renderFormatDeck(true);$('#taxonomy-panel').scrollTop=0;$('#library-filter-trigger').focus({preventScroll:true});};
 $('#art-motion-toggle').onclick=()=>{libraryPaused=!libraryPaused;document.body.classList.toggle('art-paused',libraryPaused);$('#format-dialog').classList.toggle('art-paused',libraryPaused);$('#art-motion-toggle').setAttribute('aria-pressed',String(libraryPaused));$('#art-motion-toggle').innerHTML=`<span class="motion-symbol" aria-hidden="true">${libraryPaused?'▷':'Ⅱ'}</span><span>${libraryPaused?'Play artwork':'Pause artwork'}</span>`;};
 $('#pairings-research').onclick=e=>showLibraryEvidence(null,e.currentTarget);
 $('#library-research-trigger').onclick=()=>{closeLibraryFilters(true,false);showLibraryEvidence(null,$('#library-filter-trigger'));};
 $('#close-library-evidence').onclick=closeLibraryEvidence;
 $('#format-dialog').addEventListener('keydown',e=>{
  if(!$('#library-filter-layer').hidden){
   if(e.key==='Escape'){e.preventDefault();e.stopImmediatePropagation();closeLibraryFilters();return;}
   if(e.key==='Tab'){const controls=$$('button:not(:disabled),select:not(:disabled)',$('#library-filter-layer')).filter(el=>el.getClientRects().length);const first=controls[0],last=controls.at(-1);if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}}
  }
  if(e.key==='Escape'&&(tipTarget||!$('#library-evidence').hidden)){e.preventDefault();e.stopImmediatePropagation();if(tipTarget)closeLibraryTip();else closeLibraryEvidence();}
  if(e.key==='Tab'&&!$('#library-evidence').hidden){const nodes=$$('button,a[href]',$('#library-evidence'));const first=nodes[0],last=nodes.at(-1);if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}}
 },true);
 $('#format-dialog').addEventListener('click',e=>{if(!e.target.closest('[data-info]')&&!e.target.closest('#library-tooltip'))closeLibraryTip();});
 $('#format-dialog').addEventListener('close',()=>{closeLibraryFilters(true,false);closeLibraryTip(true);closeLibraryEvidence();artworkObserver?.disconnect();});
 $('#taxonomy-panel').addEventListener('scroll',()=>closeLibraryTip(true),{passive:true});
 window.addEventListener('resize',()=>closeLibraryTip(true));
 document.addEventListener('visibilitychange',()=>document.body.classList.toggle('art-document-hidden',document.hidden));
 observeArt();
}

function chosenDraftLocale(){return languageInfo(draftSameLanguage?draftLanguage:draftChannelLanguages[editingLanguageChannel]||draftLanguage);}
function localeButtonHTML(id){const e=languageInfo(id);return `<span class="flag" aria-hidden="true">${e.flag}</span><span class="locale-button-copy"><strong dir="${e.dir}" lang="${e.tag}">${escapeHTML(e.native)}</strong><small>${escapeHTML(e.english)}</small></span><span class="small-chevron">${icon('chevron')}</span>`;}
function renderLanguageDialog(){
 const sizing=['individual-language-panel','shared-language-content','locale-catalog'].map(id=>{const el=$('#'+id);const h=el.hidden?0:el.getBoundingClientRect().height;UI.cancel(el);return [el,h];});
 const name=C.channels.find(c=>c.id===editingLanguageChannel)?.name||'channel';
 $('#language-target-label').textContent=`Output language for ${name}`;
 $('#individual-language-panel').hidden=false;$('#individual-language-panel').inert=draftSameLanguage;
 $('#individual-language-button').innerHTML=localeButtonHTML(draftChannelLanguages[editingLanguageChannel]||draftLanguage);
 $('#individual-language-button').setAttribute('aria-expanded',String(catalogOpen&&!draftSameLanguage));
 $('#same-language-toggle').checked=draftSameLanguage;$('#same-language-toggle').setAttribute('aria-expanded',String(draftSameLanguage));
 $('#shared-language-box').classList.toggle('is-shared',draftSameLanguage);
 $('#shared-language-content').inert=!draftSameLanguage;
 $('#shared-language-hint').textContent=draftSameLanguage?(sharedConfirmed?'One shared choice. Your individual settings stay saved.':'Choose a language below before applying.'):'Individual settings are kept for later.';
 $('#shared-language-button').innerHTML=sharedConfirmed?localeButtonHTML(draftLanguage):`${icon('globe')}<span>Choose a shared language…</span><span class="small-chevron">${icon('chevron')}</span>`;
 $('#shared-language-button').setAttribute('aria-expanded',String(catalogOpen&&draftSameLanguage));
 $('#language-mode-label').textContent=draftSameLanguage?(sharedConfirmed?'Shared language':'Choose shared language'):'Individual languages';
 $('#channel-language-list').innerHTML=C.channels.map(channel=>{
  const saved=draftChannelLanguages[channel.id]||draftLanguage;
  const lang=draftSameLanguage&&sharedConfirmed?draftLanguage:saved;const e=languageInfo(lang);
  return `<div class="channel-language-row${!draftSameLanguage&&editingLanguageChannel===channel.id?' editing-language':''}" data-channel-language-row="${channel.id}">${platform(channel.id)}<div class="channel-language-copy"><strong>${channel.name}</strong></div><button class="channel-language-button" data-channel-language="${channel.id}" aria-label="Output language for ${channel.name}: ${escapeHTML(e.label)}" aria-pressed="${!draftSameLanguage&&editingLanguageChannel===channel.id}" ${draftSameLanguage?'disabled':''}><span aria-hidden="true">${e.flag}</span><strong dir="${e.dir}" lang="${e.tag}">${escapeHTML(e.label)}</strong><span class="small-chevron">${icon('chevron')}</span></button></div>`;
 }).join('');
 $('#save-language').disabled=draftSameLanguage&&!sharedConfirmed;
 const catalog=$('#locale-catalog');const slot=$(draftSameLanguage?'#shared-picker-slot':'#individual-picker-slot');
 if(catalog.parentElement!==slot)slot.append(catalog);catalog.hidden=false;catalog.inert=!catalogOpen;
 if(catalogOpen)renderLocaleList();
 const animate=$('#language-dialog').open&&canAnimate();
 const shows=[!draftSameLanguage,draftSameLanguage,catalogOpen];
 // Measure the final nested layout before starting any child animation.
 sizing.forEach(([el],i)=>{el.style.height=shows[i]?'auto':'0px';});
 const ends=sizing.map(([el],i)=>shows[i]?el.getBoundingClientRect().height:0);
 sizing.forEach(([el,before],i)=>UI.height(el,before,shows[i],animate,ends[i]));
}
function renderLocaleList(){
 const groups=L.groups(localeQuery,recentLocales,[draftChannelLanguages[editingLanguageChannel]||draftLanguage,'en-US','zh-Hant-HK','zh-Hans-CN','ja-JP']);
 localeRows=groups.flatMap(g=>g.rows);localeActive=Math.max(0,Math.min(localeActive,localeRows.length-1));
 const selected=draftSameLanguage&&!sharedConfirmed?null:chosenDraftLocale().id;let index=0;
 $('#locale-results').innerHTML=groups.filter(g=>g.rows.length).map(g=>`<section role="group" aria-label="${escapeHTML(g.label)}"><h4>${escapeHTML(g.label)}</h4>${g.rows.map(e=>{const n=index++;return `<div id="locale-option-${n}" class="locale-option${n===localeActive?' keyboard-active':''}" role="option" aria-selected="${e.id===selected}" data-index="${n}" data-language-choice="${e.id}"><span class="flag" aria-hidden="true">${e.flag}</span><span class="locale-names"><strong lang="${e.tag}" dir="${e.dir}">${escapeHTML(e.native)}</strong><small>${escapeHTML(e.english)}</small></span>${e.regionless?'<span class="regionless-note">No region</span>':''}<span class="locale-check">${e.id===selected?icon('check'):''}</span></div>`;}).join('')}</section>`).join('');
 if(!localeRows.length){const guess=L.didYouMean(localeQuery);$('#locale-results').innerHTML=`<div class="locale-empty">No language matches “${escapeHTML(localeQuery)}”.<small>Try an English name, native name or region.</small>${guess?`<button class="secondary-button" id="locale-suggestion">Did you mean ${escapeHTML(guess)}?</button>`:''}</div>`;if(guess)$('#locale-suggestion').onclick=()=>{localeQuery=guess;$('#locale-search').value=guess;localeActive=0;renderLocaleList();};}
 $('#locale-search').setAttribute('aria-activedescendant',localeRows.length?`locale-option-${localeActive}`:'');
 $('#clear-locale-search').hidden=!localeQuery;
 $('#locale-status').textContent=localeQuery?`${localeRows.length} matching choices`:`${L.entries.length} language & regional choices · Your project catalogue`;
}
function openLocaleList(){catalogOpen=!catalogOpen;localeQuery='';localeActive=0;$('#locale-search').value='';renderLanguageDialog();if(catalogOpen&&innerWidth>760)$('#locale-search').focus({preventScroll:true});}
function pickLocale(id){const e=L.entry(id);if(!e)return;
 if(draftSameLanguage){draftLanguage=e.id;sharedConfirmed=true;}else draftChannelLanguages[editingLanguageChannel]=e.id;
 recentLocales=[e.id,...recentLocales.filter(x=>x!==e.id)].slice(0,3);catalogOpen=false;renderLanguageDialog();
 $(draftSameLanguage?'#shared-language-button':'#individual-language-button').focus({preventScroll:true});
}
function wireLanguages(){
 $('#individual-language-button').onclick=openLocaleList;$('#shared-language-button').onclick=openLocaleList;
 $('#same-language-toggle').onchange=e=>{draftSameLanguage=e.target.checked;sharedConfirmed=!draftSameLanguage;catalogOpen=draftSameLanguage;localeQuery='';localeActive=0;$('#locale-search').value='';renderLanguageDialog();};
 $('#channel-language-list').onclick=e=>{const b=e.target.closest('[data-channel-language]');if(!b||draftSameLanguage)return;editingLanguageChannel=b.dataset.channelLanguage;catalogOpen=true;localeQuery='';localeActive=0;$('#locale-search').value='';renderLanguageDialog();$('#language-dialog').scrollTo({top:0,behavior:canAnimate()?'smooth':'instant'});};
 $('#locale-search').oninput=e=>{localeQuery=e.target.value;localeActive=0;renderLocaleList();$('#locale-results').scrollTop=0;};
 $('#clear-locale-search').onclick=()=>{localeQuery='';localeActive=0;$('#locale-search').value='';renderLocaleList();$('#locale-search').focus();};
 $('#locale-results').onmousedown=e=>{if(e.target.closest('[data-language-choice]'))e.preventDefault();};
 $('#locale-results').onclick=e=>{const b=e.target.closest('[data-language-choice]');if(b)pickLocale(b.dataset.languageChoice);};
 $('#locale-search').onkeydown=e=>{
  const moves={ArrowDown:1,ArrowUp:-1,PageDown:8,PageUp:-8};
  if(e.key in moves&&localeRows.length){e.preventDefault();localeActive=Math.max(0,Math.min(localeRows.length-1,localeActive+moves[e.key]));renderLocaleList();$(`#locale-option-${localeActive}`)?.scrollIntoView({block:'nearest'});}
  if(e.key==='Enter'&&localeRows[localeActive]){e.preventDefault();pickLocale(localeRows[localeActive].id);}
  if(e.key==='Escape'){e.preventDefault();e.stopPropagation();catalogOpen=false;renderLanguageDialog();$(draftSameLanguage?'#shared-language-button':'#individual-language-button').focus({preventScroll:true});}
 };
}

function providerGlyph(id){
 const svg=window.RafiiBrandIcons[id];
 return `<span class="provider-glyph provider-${id}" ${svg?`data-brand-asset="${id}"`:''}>${svg||'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><rect x="2" y="3" width="20" height="18" rx="4"/><path d="m6 8 4 4-4 4m7 0h5"/></svg>'}</span>`;
}
function capabilityBadges(m){return `<span class="model-capabilities" aria-label="Illustrative badges, not verified capability">${m.image?`<span title="Image input · demo">${icon('image')}</span>`:''}</span>`;}
function updateReasoning(){
 const opts=$('#thinking-options');
 if(!opts.childElementCount)opts.innerHTML='<span class="reasoning-lens" aria-hidden="true"></span>'+['low','medium','high','max'].map(level=>`<button data-thinking="${level}" aria-pressed="false">${level[0].toUpperCase()+level.slice(1)}</button>`).join('');
 const level=draftThinking[draftModel]||'medium',index=['low','medium','high','max'].indexOf(level);
 opts.dataset.level=level;opts.style.setProperty('--reason-index',index);
 $$('[data-thinking]',opts).forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.thinking===level)));
 $$('.thinking-bars i').forEach((bar,i)=>{bar.classList.toggle('lit',i<=index);bar.style.setProperty('--bar-delay',`${i*35}ms`);});
 $('.thinking-bars').setAttribute('data-count',String(index+1));
 $('#thinking-control').hidden=false;$('#reasoning-for-model').textContent=modelLabel(draftModel);
}
function moveProviderLens(){const active=$(`[data-provider="${modelProvider}"]`),lens=$('.provider-lens');if(!active||!lens)return;lens.style.height=active.offsetHeight+'px';lens.style.width=active.offsetWidth+'px';lens.style.transform=`translate(${active.offsetLeft}px,${active.offsetTop}px)`;}
function renderModelDialog(transition=false,direction=1){
 const selected=modelOptions.find(m=>m.id===draftModel)||modelOptions[0];
 const last=$('#selected-model-label').textContent;
 $('#selected-model-logo').innerHTML=providerGlyph(selected.provider);$('#selected-model-label').textContent=selected.label;
 if(last!==selected.label&&canAnimate()&&$('#model-dialog').open){$('#selected-model-label').animate([{opacity:0,transform:'translateY(5px)'},{opacity:1,transform:'translateY(0)'}],{duration:330,easing:ease});}
 const rail=$('#provider-rail');if(!rail.childElementCount)rail.innerHTML='<span class="provider-lens" aria-hidden="true"></span>'+window.RafiiModels.providers.map(p=>`<button role="tab" id="provider-${p.id}" data-provider="${p.id}" title="${p.label}" aria-label="${p.label} models" aria-selected="false" aria-controls="provider-model-panel">${providerGlyph(p.id)}<span class="sr-only">${p.label}</span></button>`).join('');
 $$('[data-provider]',rail).forEach(b=>{const on=b.dataset.provider===modelProvider;b.setAttribute('aria-selected',String(on));b.tabIndex=on?0:-1;});
 $('#provider-model-panel').setAttribute('aria-labelledby',`provider-${modelProvider}`);
 const query=modelQuery.trim().toLowerCase(),candidates=query?modelOptions.filter(m=>`${m.label} ${m.provider} ${m.note}`.toLowerCase().includes(query)):modelOptions.filter(m=>m.provider===modelProvider);
 const title=query?`SEARCH RESULTS · ${candidates.length}`:window.RafiiModels.providers.find(p=>p.id===modelProvider).label;
 $('#clear-model-search').hidden=!query;
 const cards=candidates.map(m=>`<button class="model-option${draftModel===m.id?' selected':''}" data-model-choice="${m.id}" aria-pressed="${draftModel===m.id}">${providerGlyph(m.provider)}<span class="model-option-copy"><strong>${escapeHTML(m.label)}${draftModel===m.id?icon('check'):''}</strong><small>${escapeHTML(m.note)}</small>${query?`<span class="model-search-provider">${escapeHTML(m.provider)}</span>`:''}</span>${capabilityBadges(m)}</button>`).join('')||'<div class="model-empty">No models found.<small>Try a provider or model name.</small></div>';
 UI.swap($('#model-list-transition'),`<div id="model-provider-title" class="model-provider-title">${escapeHTML(title)}</div><div id="model-options" class="model-options" role="group" aria-label="Model options">${cards}</div>`,transition&&canAnimate(),direction);
 updateReasoning();moveProviderLens();
 $$('[data-model-mode]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.modelMode===(modelProvider==='cli'?'cli':'api'))));
 $('#model-demo-note').textContent='Offline demo. Reasoning is a saved preference for every model; provider support, names and capabilities are not verified. No API or CLI runs.';
}
function setProvider(id){const list=window.RafiiModels.providers.map(p=>p.id);const direction=list.indexOf(id)>=list.indexOf(modelProvider)?1:-1;modelProvider=id;modelQuery='';$('#model-search').value='';renderModelDialog(true,direction);}
function wireModels(){
 $('#provider-rail').onclick=e=>{const b=e.target.closest('[data-provider]');if(!b||b.dataset.provider===modelProvider)return;setProvider(b.dataset.provider);b.focus({preventScroll:true});};
 $('#provider-rail').onkeydown=e=>{const b=e.target.closest('[data-provider]');if(!b||!['ArrowDown','ArrowUp','Home','End'].includes(e.key))return;e.preventDefault();const ids=window.RafiiModels.providers.map(p=>p.id);let n=ids.indexOf(b.dataset.provider)+(e.key==='ArrowDown'?1:-1);if(e.key==='Home')n=0;if(e.key==='End')n=ids.length-1;setProvider(ids[(n+ids.length)%ids.length]);$(`[data-provider="${modelProvider}"]`).focus();};
 $('#model-list-transition').onclick=e=>{const b=e.target.closest('[data-model-choice]');if(!b||b.closest('.switch-outgoing'))return;draftModel=b.dataset.modelChoice;modelProvider=modelOptions.find(m=>m.id===draftModel).provider;renderModelDialog();$(`[data-model-choice="${draftModel}"]`)?.focus({preventScroll:true});};
 $('#model-search').oninput=e=>{modelQuery=e.target.value;renderModelDialog();};
 $('#clear-model-search').onclick=()=>{modelQuery='';$('#model-search').value='';renderModelDialog();$('#model-search').focus();};
 $('#thinking-options').onclick=e=>{const b=e.target.closest('[data-thinking]');if(!b)return;draftThinking[draftModel]=b.dataset.thinking;updateReasoning();};
 $('#thinking-options').onkeydown=e=>{if(!['ArrowLeft','ArrowRight','Home','End'].includes(e.key))return;e.preventDefault();const levels=['low','medium','high','max'];let i=levels.indexOf(draftThinking[draftModel]||'medium');i=e.key==='Home'?0:e.key==='End'?3:(i+(e.key==='ArrowRight'?1:3))%4;draftThinking[draftModel]=levels[i];updateReasoning();$(`[data-thinking="${levels[i]}"]`).focus();};
 $$('[data-model-mode]').forEach(b=>b.onclick=()=>setProvider(b.dataset.modelMode==='cli'?'cli':'openai'));
}
function syncExpandedIdea(fromMain){
 if(fromMain){$('#idea-expanded').value=$('#idea').value;$('#expanded-character-count').textContent=`${$('#idea').value.length.toLocaleString()} / 2,000`;}
 else {$('#idea').value=$('#idea-expanded').value;$('#expanded-character-count').textContent=`${$('#idea-expanded').value.length.toLocaleString()} / 2,000`;renderComposer();}
}

function renderTones(){
 $$('[data-tone]').forEach(b=>{const selected=b.dataset.tone===draftTone;b.classList.toggle('selected',selected);b.setAttribute('aria-pressed',String(selected));});
}
function renderSources(){
 $('#source-list').innerHTML=state.sources.length?state.sources.map(s=>`<article class="source-row" data-source="${escapeHTML(s.id)}"><div class="source-title"><span>${icon('file')}</span><div><strong>${escapeHTML(s.name)}</strong><small>${s.sample?'SAMPLE DOCUMENT':'LOCAL TO THIS TAB'} · ${s.content.length.toLocaleString()} characters</small></div><button class="remove-source" aria-label="Remove ${escapeHTML(s.name)}">×</button></div><p class="source-excerpt">${escapeHTML(s.content.slice(0,190))}${s.content.length>190?'…':''}</p><div class="source-controls"><label><input class="include-source" type="checkbox" ${s.include?'checked':''}> Include in drafting context <span class="demo-chip">DEMO</span></label><label><input class="quote-permission" type="checkbox" ${s.quote?'checked':''} ${!s.include?'disabled':''}> Allow public quoting of this text</label></div></article>`).join(''):'<p class="dialog-note">Your pocket is empty. Add a note or a small text file.</p>';
 $$('.source-row').forEach(row=>{
  const source=state.sources.find(s=>s.id===row.dataset.source);
  $('.remove-source',row).addEventListener('click',()=>{state.sources=state.sources.filter(s=>s.id!==source.id);renderSources();renderComposer();$('#source-note').focus();});
  $('.include-source',row).addEventListener('change',e=>{source.include=e.target.checked;const quote=$('.quote-permission',row);quote.disabled=!source.include;if(!source.include){source.quote=false;quote.checked=false;}});
  $('.quote-permission',row).addEventListener('change',e=>{source.quote=e.target.checked;});
 });
}
function addSource(name,content){
 const clean=content.trim();if(!clean)throw new Error('This note is empty. Add a little context first.');
 if(content.length>131072)throw new Error('Keep each source under 128 KB for this prototype.');
 state.sources.push({id:'source-'+Date.now()+'-'+Math.random().toString(36).slice(2,7),name:name.slice(0,100),content:clean,include:true,quote:false,sample:false});
 renderSources();renderComposer();$('#source-error').textContent='Added locally. Public quoting is off.';
}
function setExample(which='lesson'){$('#idea').value=promptSamples[which]||promptSamples.lesson;renderComposer();$('#idea').focus({preventScroll:true});}
function renderFlow(){
 const selected=state.request?.channels||[];const width=360;
 $('#flow-branches').innerHTML=`<svg viewBox="0 0 360 70" preserveAspectRatio="none" aria-hidden="true">${selected.map((id,i)=>{
  const x=width*(i+.5)/selected.length;const path=`M180 0 V10 C180 39 ${x} 24 ${x} 69`;
  return `<path class="flow-path" d="${path}"/><path class="flow-beam" data-beam="${id}" pathLength="203" d="${path}" style="animation-delay:${i*.19}s"/>`;
 }).join('')}</svg><div class="flow-nodes">${selected.map(id=>`<div class="flow-node pending" data-node="${id}">${platform(id)}<span class="node-state">·</span></div>`).join('')}</div>`;
}
function updateFlow(){
 Object.entries(state.drafts).forEach(([id,d])=>{
  const node=$(`[data-node="${id}"]`);if(!node)return;
  node.className=`flow-node ${d.status}`;$('.node-state',node).textContent=d.status==='ready'?'✓':d.status==='error'?'!':'·';
  const beam=$(`[data-beam="${id}"]`);if(beam){if(d.status==='pending')beam.removeAttribute('hidden');else beam.setAttribute('hidden','');}
 });
}
function renderDraftTabs(){
 if(!state.request)return;
 renderDock($('#draft-tabs'),state.request.channels,state.activeDraft,'data-draft',id=>{
  if(id===state.activeDraft)return;state.activeDraft=id;resultSlide=0;renderDraftTabs();renderPreview();
 },true);
}
function renderPreview(){
 const id=state.activeDraft;const draft=state.drafts[id];if(!draft)return;
 const c=C.channels.find(c=>c.id===id);
 $('#draft-channel-name').textContent=c.name;
 $('#draft-format-meta').innerHTML=`<span class="draft-taxonomy-chip">${tinyThumbnail(state.request.editorialType||'status_update')}${escapeHTML(taxonomyItem(state.request.editorialType||'status_update').title)}</span><span class="draft-taxonomy-chip">${tinyThumbnail(state.request.nativeFormat||'text')}${escapeHTML(taxonomyItem(state.request.nativeFormat||'text').title)}</span><span>${escapeHTML(languageLabel(state.request.outputLanguages[id]))}</span>`;
 $('#draft-state-badge').textContent=draft.status==='ready'?'Demo draft':draft.status==='error'?'Retry available':'Simulating';
 $('#draft-editor').hidden=draft.status!=='ready';$('#draft-actions').hidden=draft.status!=='ready';
 $('#draft-loading').hidden=draft.status!=='pending';$('#draft-error').hidden=draft.status!=='error';
 if(draft.status==='ready'){
  if($('#draft-editor').value!==draft.text)$('#draft-editor').value=draft.text;
  const saved=state.queue.some(q=>q.id===draft.id);
  $('#save-draft').innerHTML=icon(saved?'check':'bookmark')+(saved?' Update saved draft':' Save to queue');
  $('#draft-note').textContent=draft.note+' Native format is a concept preference; the phone shows an illustrative caption preview, not verified platform support.';
 }else $('#draft-note').textContent='';
 renderResultPhone();
}
function updateGeneration(){
 const drafts=Object.values(state.drafts);const total=drafts.length;
 const ready=drafts.filter(d=>d.status==='ready').length;const errors=drafts.filter(d=>d.status==='error').length;const pending=drafts.filter(d=>d.status==='pending').length;
 const status=$('#generation-status');
 if(pending){status.textContent=`Simulating previews · ${ready} of ${total} ready`;status.classList.remove('ready');}
 else if(errors){status.textContent=`${ready} of ${total} ready · ${errors} ${errors===1?'needs a retry':'need a retry'}`;status.classList.remove('ready');}
 else {status.textContent=`${ready} of ${total} ready · yours to edit`;status.classList.add('ready');}
 if(!pending){state.busy=false;renderComposer();}
 updateFlow();$('.idea-flow').hidden=!pending;renderDraftTabs();renderPreview();
}
function beginGeneration(){
 if(state.busy)return;
 resultSlide=0;$('#result-artwork').checked=false;
 const check=C.validate($('#idea').value,state.channels);if(!check.ok){toast(check.message);return;}
 clearTimers();const token=generationToken;
 try{const request=C.makeRequest({idea:$('#idea').value,channels:state.channels,format:state.format,tone:state.tone,language:state.language,editorialType:state.editorialType,nativeFormat:state.nativeFormat});state.request=Object.freeze({...request,outputLanguages:Object.freeze(Object.fromEntries(request.channels.map(id=>[id,outputLanguageFor(id)]))),model:state.model,thinking:state.thinking[state.model]||null});}
 catch(error){toast(error.message);return;}
 const shouldFail=state.simulateError;state.simulateError=false;$('#simulate-error').checked=false;
 state.requestId++;state.drafts={};state.busy=true;state.activeDraft=state.request.channels[0];
 state.request.channels.forEach(id=>{state.drafts[id]={id:`draft-${state.requestId}-${id}`,channel:id,status:'pending',text:'',note:''};});
 $('#preview-idle').hidden=true;$('#results').hidden=false;renderComposer();renderFlow();updateGeneration();
 if(window.innerWidth<=980)$('#results').scrollIntoView({behavior:canAnimate()?'smooth':'instant',block:'start'});
 state.request.channels.forEach((id,i)=>{
  schedule(()=>{
   if(token!==generationToken)return;
   const d=state.drafts[id];
   if(shouldFail&&i===Math.min(1,state.request.channels.length-1))d.status='error';
   else {const language=state.request.outputLanguages[id]; const sample=C.sampleDraft({...state.request,language},id);Object.assign(d,{status:'ready',text:sample.text,note:`${sample.note} · Output language: ${languageLabel(language)}.`});}
   updateGeneration();
  },750+i*620);
 });
}
function retryDraft(){
 const id=state.activeDraft;if(!id||state.drafts[id]?.status!=='error')return;
 const token=generationToken;state.drafts[id].status='pending';state.busy=true;renderComposer();updateGeneration();
 schedule(()=>{
  if(token!==generationToken)return;
  const language=state.request.outputLanguages[id]; const sample=C.sampleDraft({...state.request,language},id);Object.assign(state.drafts[id],{status:'ready',text:sample.text,note:`${sample.note} · Output language: ${languageLabel(language)}.`});updateGeneration();
 },850);
}
function cancelGeneration(){
 clearTimers();state.busy=false;state.request=null;state.drafts={};state.activeDraft=null;
 $('#results').hidden=true;$('#preview-idle').hidden=false;renderComposer();toast('Simulation cancelled. Your idea is still here.');
}
function saveDraft(){
 const d=state.drafts[state.activeDraft];if(!d||d.status!=='ready')return;
 d.text=$('#draft-editor').value;
 const record={id:d.id,channel:d.channel,format:state.request.format,editorialType:state.request.editorialType,nativeFormat:state.request.nativeFormat,text:d.text};
 const index=state.queue.findIndex(q=>q.id===d.id);
 if(index>=0)state.queue[index]=record;else state.queue.push(record);
 updateQueueCounts();renderPreview();toast('Saved to this session’s queue. Nothing published.');
}
async function copyDraft(){
 const d=state.drafts[state.activeDraft];if(!d||d.status!=='ready')return;
 try{
  if(!navigator.clipboard?.writeText)throw new Error('Clipboard unavailable');
  await navigator.clipboard.writeText($('#draft-editor').value);toast('Draft copied. Make it your own.');
 }catch(_){$('#draft-editor').focus();$('#draft-editor').select();toast('Text selected. Use your device’s Copy command.');}
}
function updateQueueCounts(){$$('.queue-count').forEach(node=>{node.textContent=String(state.queue.length);node.hidden=!state.queue.length;});}
function renderQueue(){
 const root=$('#queue-items');
 if(!state.queue.length){root.innerHTML=`<div class="empty-state"><span>${icon('bookmark')}</span><h2>No drafts saved yet.</h2><p>Generate a sample, make it yours, then save it here.<br>This queue lives only in your current tab.</p><button class="small-primary" data-view="home">Start with an idea ${icon('arrow-right')}</button></div>`;return;}
 root.innerHTML=state.queue.map(q=>{
  const c=C.channels.find(c=>c.id===q.channel);const format=C.formats.find(f=>f.id===q.format).name;
  return `<article class="queue-card"><div class="queue-header">${platform(q.channel)}<div><strong>${c.name}</strong><small>${format} · Local demo draft</small></div><button class="icon-button" data-remove-draft="${q.id}" aria-label="Remove ${c.name} draft">${icon('trash')}</button></div><p class="queue-body">${escapeHTML(q.text)}</p><div class="queue-footer">Not scheduled · only in this session</div></article>`;
 }).join('');
 $$('[data-remove-draft]').forEach(b=>b.addEventListener('click',()=>{state.queue=state.queue.filter(q=>q.id!==b.dataset.removeDraft);updateQueueCounts();renderQueue();toast('Draft removed from this demo queue.');}));
}
function moveNavLens(){
 const idx=['home','calendar','queue','inbox','more'].indexOf(state.view);const nav=$('.mobile-nav');const lens=$('.nav-lens');
 if(nav&&lens&&idx>=0){const col=(nav.clientWidth-28)/5;lens.style.transform=`translateX(${idx*col}px)`;}
}
function navigate(view){
 if(view==='more'){openDialog('controls-dialog',$('[data-view="more"]:focus')||$('#demo-controls'));return;}
 if(!['home','calendar','queue','inbox'].includes(view))return;
 state.view=view;$$('.view').forEach(v=>v.hidden=v.id!==`${view}-view`);
 $$('[data-view]').forEach(b=>{const on=b.dataset.view===view;b.classList.toggle('active',on);if(on)b.setAttribute('aria-current','page');else b.removeAttribute('aria-current');});
 if(view==='queue')renderQueue();moveNavLens();window.scrollTo({top:0,behavior:'instant'});
}
function resetDemo(){
 clearTimers();state=initialState();recentLocales=[];showroomChannel='instagram';showroomSlide=0;resultSlide=0;$('#showcase-artwork').checked=true;$('#result-artwork').checked=false;$('#idea').value='';$('#source-note').value='';$('#add-note').disabled=true;
 $('#results').hidden=true;$('#preview-idle').hidden=false;$('#simulate-error').checked=false;
 renderComposer();updateQueueCounts();navigate('home');closeDialog().then(()=>toast('A clean slate. Drafts reset. Saved folders kept.'));
}
// Repository-derived phone views. Preview navigation never changes draft destinations.
let showroomChannel='instagram',showroomSlide=0,resultSlide=0,expandedMode='showcase';
const platformSurfaces={instagram:'Home feed',linkedin:'Home feed',threads:'For you',x:'For you',facebook:'Home feed',red:'Note detail'};
const showcaseText={
 instagram:'A little different. Still me.\nThe quiet work, the small experiments, the idea that finally finds its shape. What are you creating this week?',
 linkedin:'One thing piano practice taught me about creating: consistency matters more than waiting for inspiration.\n\nSmall, deliberate steps change what is possible.',
 threads:'The best ideas usually show up while I’m making something, not while I’m waiting for inspiration. Anyone else?',
 x:'A little less waiting for inspiration. A little more making things. Small steps, every day.',
 facebook:'A little look behind the scenes. This week I’m making space for the quiet work: practising, experimenting, and finding new ways to share it. What are you working on?',
 red:'同一個想法，另一種表達\n練琴教會我的事：比起等待靈感，每一天的小小練習更重要。\n\n分享過程，也分享不完美的時刻。'
};
function renderDock(root,ids,active,attribute,onSelect,drafts=false){
 const signature=ids.join('|')+attribute;
 if(root.dataset.dockSignature!==signature){
  root.innerHTML='<span class="dock-lens" aria-hidden="true"></span>'+ids.map(id=>{
   const c=C.channels.find(c=>c.id===id);
   return `<button class="preview-channel-button${drafts?' draft-tab':''}" ${attribute}="${id}" aria-label="Preview ${c.name} on iPhone" aria-pressed="false">${platform(id)}<span>${id==='red'?'RED':c.name}</span><i class="tab-status" aria-hidden="true"></i></button>`;
  }).join('');
  root.dataset.dockSignature=signature;root.style.setProperty('--dock-count',String(ids.length));
 }
 const buttons=$$('button',root);
 buttons.forEach(button=>{
  const id=button.getAttribute(attribute),selected=id===active;
  button.setAttribute('aria-pressed',String(selected));button.classList.toggle('selected',selected);
  if(drafts)button.dataset.status=state.drafts[id]?.status||'pending';
  button.onclick=()=>onSelect(id);
 });
 root.onkeydown=e=>{
  if(!['ArrowLeft','ArrowRight','Home','End'].includes(e.key))return;
  const current=buttons.indexOf(document.activeElement);if(current<0)return;e.preventDefault();
  const next=e.key==='Home'?0:e.key==='End'?buttons.length-1:(current+(e.key==='ArrowRight'?1:-1)+buttons.length)%buttons.length;
  buttons[next].focus({preventScroll:true});buttons[next].click();
 };
 moveDockLens(root);
}
function moveDockLens(root){
 const selected=$('button[aria-pressed="true"]',root),lens=$('.dock-lens',root);if(!selected||!lens)return;
 lens.style.width=selected.offsetWidth+'px';lens.style.height=selected.offsetHeight+'px';
 lens.style.transform=`translate(${selected.offsetLeft}px,${selected.offsetTop}px)`;
}
function showcaseModel(){return {channel:showroomChannel,text:$('#idea').value.trim()||showcaseText[showroomChannel],format:state.format,slide:showroomSlide,artwork:$('#showcase-artwork').checked&&state.format!=='video'};}
function resultModel(){const d=state.drafts[state.activeDraft];return d&&d.status==='ready'?{channel:d.channel,text:d.text,format:state.request.format,slide:resultSlide,artwork:$('#result-artwork').checked&&state.request.format!=='video'}:null;}
function showcaseModels(){return P.channels.map(channel=>({...showcaseModel(),channel,text:$('#idea').value.trim()||showcaseText[channel]}));}
function resultModels(){return state.request?state.request.channels.filter(id=>state.drafts[id]?.status==='ready').map(id=>({channel:id,text:state.drafts[id].text,format:state.request.format,slide:resultSlide,artwork:$('#result-artwork').checked&&state.request.format!=='video'})):[];}
function renderShowcase(){
 const c=C.channels.find(c=>c.id===showroomChannel),m=showcaseModel();
 renderDock($('#showcase-channels'),P.channels,showroomChannel,'data-showcase-channel',id=>{
  if(id===showroomChannel)return;showroomChannel=id;showroomSlide=0;renderShowcase();
 });
 phoneDeck.render($('#showcase-phone'),m,showcaseModels());
 $('#showcase-platform-name').textContent=c.name;
 $('#showcase-surface').textContent=platformSurfaces[showroomChannel]+' · iPhone preview';
 $('#showcase-page-controls').hidden=state.format!=='carousel'||!m.artwork;
 $('#showcase-page').textContent=`${showroomSlide+1} / 4`;
 $('#showcase-artwork').disabled=state.format==='video';
 if($('#phone-dialog').open&&expandedMode==='showcase')renderExpanded();
}
function renderResultPhone(){
 const m=resultModel();$('#result-phone-wrap').hidden=!m;
 if(m){phoneDeck.render($('#result-phone'),m,resultModels());$('#result-page-controls').hidden=m.format!=='carousel'||!m.artwork;$('#result-page').textContent=`${resultSlide+1} / 4`;$('#result-artwork').disabled=m.format==='video';}
 else phoneDeck.destroy($('#result-phone'));
 if($('#phone-dialog').open&&expandedMode==='result')renderExpanded();
}
function renderExpanded(){
 const m=expandedMode==='result'?resultModel():showcaseModel();
 if(!m){closeDialog($('#phone-dialog'),false);return;}
 const c=C.channels.find(c=>c.id===m.channel);
 $('#phone-title').textContent=c.name+' on iPhone.';
 phoneDeck.render($('#expanded-phone'),m,expandedMode==='result'?resultModels():showcaseModels());
 $('#expanded-description').textContent=expandedMode==='result'?'Your edited draft inside its destination app. This is an illustrative layout, not a published post.':'Switch platforms to see the same idea in another app.';
 const ids=expandedMode==='result'?state.request.channels.filter(id=>state.drafts[id]?.status==='ready'):P.channels;
 renderDock($('#expanded-channels'),ids,m.channel,'data-expanded-channel',id=>{
  if(expandedMode==='result'){if(id===state.activeDraft)return;state.activeDraft=id;resultSlide=0;renderDraftTabs();renderPreview();}
  else{if(id===showroomChannel)return;showroomChannel=id;showroomSlide=0;renderShowcase();}
 });
 $('#expanded-page-controls').hidden=m.format!=='carousel'||!m.artwork;
 $('#expanded-page').textContent=`${m.slide+1} / 4`;
}
function openPhone(mode,trigger){expandedMode=mode;renderExpanded();openDialog('phone-dialog',trigger);}
function changePreviewSlide(mode,delta){if(mode==='result'){resultSlide=(resultSlide+delta+4)%4;renderResultPhone();}else{showroomSlide=(showroomSlide+delta+4)%4;renderShowcase();}}
function stepPreview(context,delta){
 const mode=context==='expanded'?expandedMode:context;
 const ids=mode==='result'?resultModels().map(m=>m.channel):P.channels;
 if(ids.length<2)return;
 const current=mode==='result'?state.activeDraft:showroomChannel;
 const next=ids[(Math.max(0,ids.indexOf(current))+delta+ids.length)%ids.length];
 if(mode==='result'){state.activeDraft=next;resultSlide=0;renderDraftTabs();renderPreview();}
 else{showroomChannel=next;showroomSlide=0;renderShowcase();}
}
function wirePhonePreviews(){
 ['showcase','result','expanded'].forEach(context=>window.RafiiSwipe.bindSwipe($(`#${context}-phone`),{onSwipe:delta=>stepPreview(context,delta),motionAllowed:canAnimate}));
 // Native dialog can yield focus to browser chrome after its last button.
 // Keep Tab and Shift+Tab cycling through this preview's visible controls.
 $('#phone-dialog').addEventListener('keydown',e=>{
  if(e.key!=='Tab')return;
  const controls=$$('button:not(:disabled),input:not(:disabled),select:not(:disabled),textarea:not(:disabled),[tabindex]:not([tabindex="-1"])',$('#phone-dialog')).filter(el=>el.getClientRects().length>0&&!el.closest('[hidden]'));
  if(!controls.length)return;
  const first=controls[0],last=controls[controls.length-1];
  if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}
  else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}
 });
 $('#showcase-artwork').addEventListener('change',()=>renderShowcase(true));
 $('#result-artwork').addEventListener('change',renderResultPhone);
 $('#showcase-expand').addEventListener('click',e=>openPhone('showcase',e.currentTarget));
 $('#result-expand').addEventListener('click',e=>openPhone('result',e.currentTarget));
 ['showcase','result','expanded'].forEach(mode=>['prev','next'].forEach(direction=>{
  $(`#${mode}-${direction}`).addEventListener('click',()=>changePreviewSlide(mode==='expanded'?expandedMode:mode,direction==='next'?1:-1));
 }));
 $('#theme-toggle').addEventListener('click',()=>{
  const light=document.documentElement.dataset.appearance!=='light';
  document.documentElement.dataset.appearance=light?'light':'dark';
  $('#theme-toggle').setAttribute('aria-label',`Switch to ${light?'dark':'light'} theme`);
  $('.theme-glyph').textContent=light?'☾':'☼';
  $('meta[name="theme-color"]').content=light?'#fcfcfc':'#000000';
 });
}

// v9: folders retain stable account IDs; this six-account demo adapts to existing platform previews.
channelFolders=window.RafiiFoldersUI.create({dialog:$('#channel-dialog'),channels:C.channels,platform,icon,motionAllowed:canAnimate,onCommit:selection=>{state.channels=selection.platforms;state.folderContext=selection.context;renderComposer();closeDialog();}});
// Wire controls once. No user-provided value is inserted as executable HTML.
decorate();
wirePhonePreviews();
wireLanguages();
wireModels();
wireTaxonomy();
$('#format-trigger').addEventListener('click',e=>openDialog('format-dialog',e.currentTarget));
$('#channels-trigger').addEventListener('click',e=>openDialog('channel-dialog',e.currentTarget));
$('#language-trigger').addEventListener('click',e=>openDialog('language-dialog',e.currentTarget));
$('#model-trigger').addEventListener('click',e=>openDialog('model-dialog',e.currentTarget));
$('#voice-trigger').addEventListener('click',e=>openDialog('tune-dialog',e.currentTarget));
$('#expand-idea-trigger').addEventListener('click',e=>openDialog('idea-dialog',e.currentTarget));
$('#context-trigger').addEventListener('click',e=>openDialog('context-dialog',e.currentTarget));
$('#demo-controls').addEventListener('click',e=>openDialog('controls-dialog',e.currentTarget));
$$('.close-dialog').forEach(b=>b.addEventListener('click',()=>closeDialog(b.closest('dialog'))));
$$('dialog').forEach(dialog=>{
 dialog.addEventListener('cancel',e=>{e.preventDefault();closeDialog(dialog);});
 dialog.addEventListener('click',e=>{if(e.target!==dialog)return;const r=dialog.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)closeDialog(dialog);});
});
$$('[data-tone]').forEach(b=>b.addEventListener('click',()=>{draftTone=b.dataset.tone;renderTones();}));
$('#save-tune').addEventListener('click',()=>{state.tone=draftTone;renderComposer();closeDialog();});
$('#save-language').addEventListener('click',()=>{if(draftSameLanguage&&!sharedConfirmed)return;state.language=draftLanguage;state.sameLanguage=draftSameLanguage;state.channelLanguages={...draftChannelLanguages};renderComposer();closeDialog();});
$('#save-model').addEventListener('click',()=>{state.model=draftModel;state.thinking={...draftThinking};renderComposer();closeDialog();});
$('#idea-expanded').addEventListener('input',()=>syncExpandedIdea(false));
$('#apply-expanded-idea').addEventListener('click',()=>{syncExpandedIdea(false);closeDialog();});
$('#source-note').addEventListener('input',e=>{$('#add-note').disabled=!e.target.value.trim();});
$('#add-note').addEventListener('click',()=>{
 const text=$('#source-note').value;
 try{addSource(text.trim().split('\n')[0].slice(0,38)||'A new note',text);$('#source-note').value='';$('#add-note').disabled=true;}
 catch(error){$('#source-error').textContent=error.message;}
});
$('#source-file').addEventListener('change',async e=>{
 const file=e.target.files?.[0];if(!file)return;
 try{
  if(!/\.(txt|md)$/i.test(file.name))throw new Error('Choose a .txt or .md file. Other formats are not parsed in this demo.');
  if(file.size>131072)throw new Error('That file is too large. Choose a text file under 128 KB.');
  const text=await file.text();addSource(file.name,text);
 }catch(error){$('#source-error').textContent=error.message||'This file could not be read.';}
 e.target.value='';
});
$('#idea').addEventListener('input',()=>{renderComposer(); if($('#idea-dialog').open) syncExpandedIdea(true);});
$('#idea').addEventListener('keydown',e=>{if(e.key==='Enter'&&(e.metaKey||e.ctrlKey)){e.preventDefault();beginGeneration();}});
$('#try-idea').addEventListener('click',()=>setExample());
$$('[data-prompt]').forEach(b=>b.addEventListener('click',()=>setExample(b.dataset.prompt)));
$('#generate').addEventListener('click',beginGeneration);
$('#cancel-generation').addEventListener('click',cancelGeneration);
$('#retry-draft').addEventListener('click',retryDraft);
$('#draft-editor').addEventListener('input',e=>{const d=state.drafts[state.activeDraft];if(d&&d.status==='ready'){d.text=e.target.value;renderResultPhone();}});
$('#save-draft').addEventListener('click',saveDraft);
$('#copy-draft').addEventListener('click',copyDraft);
$('#reduce-motion').addEventListener('change',e=>{document.body.classList.toggle('reduced-motion',e.target.checked);if(e.target.checked)phoneDeck.finishAll();});
$('#simulate-error').addEventListener('change',e=>{state.simulateError=e.target.checked;});
$('#reset-demo').addEventListener('click',resetDemo);
$$('[data-tour]').forEach(b=>b.addEventListener('click',async()=>{
 const step=b.dataset.tour;await closeDialog();navigate('home');
 if(step==='channels')openDialog('channel-dialog',$('#channels-trigger'));
 if(step==='format')openDialog('format-dialog',$('#format-trigger'));
 if(step==='generate'){setExample();beginGeneration();}
}));
document.addEventListener('click',e=>{const b=e.target.closest('[data-view]');if(b){e.preventDefault();navigate(b.dataset.view);}});
$$('.brand-mark,.wordmark').forEach(a=>a.addEventListener('click',e=>{e.preventDefault();navigate('home');}));
$('#calendar-days').innerHTML=['MON','TUE','WED','THU','FRI','SAT','SUN'].map((day,i)=>`<div class="calendar-day">${day}<strong>0${i+1}</strong></div>`).join('');
window.addEventListener('resize',()=>{moveNavLens();moveProviderLens();$$('.preview-channel-dock').forEach(moveDockLens);});
if(motionQuery.addEventListener)motionQuery.addEventListener('change',()=>{$('#reduce-motion').checked=motionQuery.matches||document.body.classList.contains('reduced-motion');if(!canAnimate())phoneDeck.finishAll();});
window.addEventListener('pagehide',()=>{clearTimers();phoneDeck.finishAll();});
renderComposer();updateQueueCounts();moveNavLens();
})();
