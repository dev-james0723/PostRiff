"""Bundle every local source reference into one offline HTML document."""
import argparse,re
from pathlib import Path
root=Path(__file__).resolve().parent
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,default=root/'index.html');args=p.parse_args()
h=(root/'src/index.html').read_text()
def css(m):return '<style>\n'+(root/'src'/m[1]).read_text()+'\n</style>'
def js(m):return '<script>\n'+(root/'src'/m[1]).read_text()+'\n</script>'
h=re.sub(r'<link rel="stylesheet" href="([^"/]+\.css)">',css,h)
h=re.sub(r'<script src="([^"/]+\.js)"></script>',js,h)
assert not re.search(r'<(?:script[^>]+src|link[^>]+stylesheet[^>]+href)=',h)
args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(h);print(f'Built {args.output} ({args.output.stat().st_size:,} bytes)')
