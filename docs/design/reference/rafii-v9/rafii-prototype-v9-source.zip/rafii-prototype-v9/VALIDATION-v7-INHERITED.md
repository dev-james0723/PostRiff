# Rafii v7 validation

## Build and verification status

Verified against the self-contained v7 HTML in this delivery, using Chromium 144 on Linux and Python Playwright. `node --check src/app.js` and the local bundler completed successfully. No external dependency or account was needed to execute the prototype.

**139 automated unit/browser tests passed.**

| Suite | Passed |
|---|---:|
| Core, phone templates, locales, taxonomy and v7 data/icon contracts | 39 |
| Original composer, channels, sources, draft, queue and simulation regressions | 22 |
| Theme, phone-frame, live edit and expanded preview regressions | 13 |
| De-duplicated controls, crossfade, language and editor regressions | 16 |
| Swipe, language catalogue and model-selector regressions | 25 |
| v6 reasoning, provider crossfade and taxonomy regressions | 8 |
| v7 categories, three views, tags, tooltips, pairing selection, motion and sources | 16 |
| **Total** | **139** |

The v7 UI suite was run in two eight-test batches. An earlier combined run exceeded the tool's time budget; its interrupted output is preserved as `tests/v7/attempt-timeout.txt`, not represented as a green result. Both final batches completed with `OK`. Final logs are `v7-group-1.txt`, `v7-group-2.txt`, `node-green.txt` and the five `*-regression.txt` files. No outstanding test failure remains.

v6 gallery assertions were adapted for intentional v7 markup changes: animated inline SVG replaces image data URIs, and the grid is inside `.library-current`. Coverage of 31 editorial illustrations, 20 native-format illustrations and responsive columns is retained. A visual regression caught the inherited gallery column direction on compact rows; a dedicated geometry test failed at 194px and passed after the row became 83px.

## Layout and visuals

**96 layout states passed:** eight screen sizes × two themes × two taxonomy dimensions × three views.

Sizes: 320×740, 375×812, 390×844, 430×932, 768×1024, 1024×768, 1440×1000 and 1920×1080. Checks covered modal bounds, page and panel horizontal overflow, all expected items, SVG presence, compact row dimensions and one-column mobile/two-column larger-screen gallery layout. Internal vertical scrolling is intentional.

All 51 standalone compact SVGs were XML-parsed. Unit tests verify unique SHA256 hashes, local paths, complete thumbnail contracts and semantic geometry rather than text-only/blank placeholders. The original 51 large illustrations remain separately hashed and locally available. No network request occurred in the visual audit.

Actual browser screenshots were inspected for the desktop list, mobile gallery/list/pairings, tooltip, light native list and the complete 51-icon and large-art contact sheets. Screenshots also cover keyboard focus, a tooltip near the boundary, and an explicitly labelled legacy fallback with a deliberately long title. The audit-only legacy mutation is not used for any item in the delivered app.

Representative evidence in `previews-v7/`:

- `final-gallery.png`, `final-list.png`, `final-pairings.png`
- `desktop-list.png`, `desktop-light-list.png`
- `mobile-tooltip.png`, `mobile-boundary-tooltip.png`, `mobile-focus.png`
- `mobile-legacy-long-title.png`
- `all-51-icons-dark.png`, `all-51-icons-light.png`, `all-51-gallery-art.png`

Screenshots are from the working browser or the local vector atlas, not generated concept images. Text/background legibility was reviewed visually; this is not a complete WCAG conformance or assistive-technology audit.

## Interaction acceptance

Gallery/List/Pairings share selection state. Each taxonomy dimension has its own category; the platform-fit filter is shared. Filtering or using a pairing never changes selected draft channels. Apply commits pending taxonomy choices; Cancel discards them. Every list row has a distinct compact vector, name, tags and a separate information button. The information button does not select the row.

View transitions retain the outgoing layer until the incoming view fades in; rapid switching discards stale layers. Information descriptions use a short eased opacity/position transition. Escape dismisses a tooltip before dismissing the library. All artwork has restrained motion, a pause control, viewport/hidden-tab pausing and reduced-motion handling.

The phone swipe/crossfade, model search/provider switches, reasoning indicator, per-channel and shared languages, expanded editor and local queue passed inherited regression checks. The new video `rafii-v7-interactions.mp4` records actual browser frames with wall-clock durations preserved; capture frame rate is not a phone-performance benchmark.

## Research accuracy boundary

67 editorial/native suggestions are labelled fit advice, not popularity results. Eight source records distinguish usage from engagement and include study samples/periods and limitations. No all-platform editorial-popularity ranking is claimed. Xiaohongshu suggestions have no quantitative benchmark attached. No real account/API capability, current app UI guarantee or publishing eligibility is implied.

## Not verified

Physical iPhone, Safari/WebKit, Firefox, screen-reader behavior, real GPU frame pacing or battery use, real AI/CLI operation, platform publishing, current vendor-model availability and live analytics were not tested. This is an offline rough prototype, not a production integration. Real model/API adapters must map or reject unsupported reasoning/preferences and native formats before any live launch.
