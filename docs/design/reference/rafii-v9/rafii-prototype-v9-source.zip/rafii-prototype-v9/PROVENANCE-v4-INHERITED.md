# v4 provenance

This update starts from the user-supplied `rafii-prototype-v3.html` and matching source archive. Original attachments are preserved. Changes in v4 are local UI/state/animation refinements, with no new third-party component code or remote assets imported.

The six phone renderers and the base monochrome/glass styling were inherited from that archive. The record below accompanied the older prototype; the repository and pinned revision were **not re-fetched or independently verified in this v4 pass**. No access to the current laptop checkout or uncommitted project changes is claimed.

---

## Inherited provenance record

# Source provenance and adaptation boundary

## Existing prototype

Updated the user-supplied `rafii-prototype.html` and the matching `rafii-prototype-source.zip`. The original attachments were not overwritten.

## Connected project source actually inspected

Repository: `dev-james0723/PostRiff`
Branch: `consumer-saas`
Pinned commit: `468811b73d28b4389f931519827c05d0e6c8abfb`

This is the remote source associated with the user's James-Au-Studio / Rafii work. No access to the current local laptop checkout or its uncommitted changes is claimed.

Theme files inspected:

- `web/src/styles/globals.css`
- `web/src/styles/theme.css`
- `web/src/styles/themes/vercel.css`

The neutral dark/light background, foreground, card, popover and primary token values in `glass.css` come from the existing Vercel black-and-white theme. The liquid-glass material and soft reflections are the prototype update. We did not establish which persisted theme selection is active for every live user.

Preview files inspected:

- `web/src/components/application/post-preview/README.md`
- `web/src/components/application/post-preview/phone-frame.tsx`
- `web/src/components/application/post-preview/templates/instagram.tsx`
- `web/src/components/application/post-preview/templates/linkedin.tsx`
- `web/src/components/application/post-preview/templates/threads.tsx`
- `web/src/components/application/post-preview/templates/x.tsx`
- `web/src/components/application/post-preview/templates/facebook.tsx`
- `web/src/components/application/post-preview/templates/xiaohongshu.tsx`

## How the templates were used

The six existing layouts were translated from React/Tailwind to self-contained, scoped HTML/CSS. The logical 393 × 852 phone screen, 54px status-bar allowance, 9px unscaled bezel, Dynamic Island dimensions, system status glyph geometry and home indicator follow the existing phone frame.

The port preserves each platform's distinct top navigation, author/media/caption ordering, main typography and action/tab-bar arrangement. The project templates inspected use light app palettes; these remain inside the mockups even when Rafii's surrounding interface is dark. Real platform blue/red accents are therefore not replaced by the monochrome Rafii skin.

This is not a byte-for-byte runtime reuse of the TSX files, and does not include the production preview provider stack. Small icon approximations, CSS-only sample artwork, demo captions, the selector dock, and the expanded-preview controls are prototype additions. Caption wrapping and scrolling can differ from the source's measurement-driven components. Source features such as real account pictures, private media loading, video playback, production time-zone resolution, preview guide overlays, social-specific validation, image export and template currency checks are not wired in this demo. Xiaohongshu uses the image-note detail layout; a video script is not presented as a rendered video note.

All user-entered text is escaped. Missing media is disclosed instead of silently fabricated. Sample artwork is visibly labelled and opt-in for generated draft previews. The monogram and account are explicitly demo data. No engagement totals are invented.

No production code was changed, no GitHub write operation was made, and no deployment was requested or performed.
