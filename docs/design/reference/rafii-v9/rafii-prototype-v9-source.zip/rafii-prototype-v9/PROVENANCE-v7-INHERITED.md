# Rafii v7 provenance

## Base
Built by modifying a separate copy of the v6 HTML/source archive supplied in this conversation. No live repository, local laptop checkout, social account, API, model endpoint or deployed site was changed. The repo-derived phone layouts and 196-entry language selector remain inherited; they were not re-fetched or re-verified in this turn. See PROVENANCE-v6-INHERITED.md and the earlier provenance files.

## Original additions
Seven editorial-purpose groups and seven presentation groups, 51 compact pictograms, the gallery/list/pairings renderer, cancellable view crossfades, click/tap/keyboard information popovers, animated SVG accents, viewport-paused artwork, platform-fit filters and research explanations are original v7 code. These do not use Hyperframe, Rive, remote libraries or a CDN. CSS and browser animation APIs are sufficient for this prototype.

Each new pictogram is a local 48×48 SVG with a separate static body and animated accent. Source paths, SHA256 hashes, alt text, conceptual metadata and version are in src/library-data.json. The original v6 320×200 SVG compositions and hashes are unchanged; v7 inlines them with per-instance IDs and motion classes at render time. The explicit legacy audit state is not used by any of the 51 new items.

## Editorial advice versus measurement
67 pairings are editorial design suggestions. They are not a survey result, a capability matrix, a popularity ranking, or proof that a topic performs well. Eight attached evidence records preserve the publisher, publication date, metric, sample, period and limitations. Studies come from the organizations that performed the analyses, not from an invented analytics service. Read RESEARCH.md.

Evidence only measures the cited formats, not all 31 editorial categories. Instagram image carousels and LinkedIn document/PDF posts are kept distinct. The six-channel fit filter does not alter destination selection. An app badge denotes a possible composition fit, not publishing/API eligibility. Xiaohongshu has no comparable quantitative benchmark verified here; its pairings are explicitly design suggestions.

Provider marks and platform icons are inherited local assets. All notices remain in src/assets/brands. No font binaries, secrets, credentials, analytics or remote image assets are included.
