# v9 provenance and scope

Base: the user-supplied `rafii-prototype-v8-source.zip` and standalone v8 HTML from this conversation.
Base standalone SHA-256: `7266e550f2ff83deb68d11bcc8cd7f00689da07da8e7c248b026c39d4ee20d20`.

The new folder core, controller, folder illustrations and stylesheet are original deterministic code written for this prototype. Folder illustrations combine the existing local social-platform glyphs with new CSS glass folder surfaces. There are no new third-party runtime dependencies, stock images, remote image URLs or font files.

The existing platform phone templates, model logo assets, locale catalogue and editorial/native taxonomy library remain inherited from v8. Their source/license notes are preserved in the `PROVENANCE-*-INHERITED.md` files and local assets. Research/fit data was not refreshed for this folder-focused change and must not be interpreted as a current ranking.

No connected repository, cloud database, live website, OAuth configuration or publishing account was modified. All edits and validation occurred in the working-container copy. Folder browser storage is a separate optional local feature, not the user's persistent ChatGPT file Library.
