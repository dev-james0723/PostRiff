# v7 fit, usage and engagement evidence

Research checked on 22 September 2026. These are published study snapshots, not a live trends feed. The prototype stores eight records in `src/library-data.json`, each with its metric, sample, period, publication date, URL and limitations.

## Interpretation rules

**Fit suggestion** is our editorial judgement about a useful composition. **Usage signal** describes what was posted in a study. **Engagement signal** describes an audience response in that study. The latter is not evidence of which format was used most. None of the studies supplies a comparable ranking for all 31 editorial types.

Platform samples, accounts and measurement definitions differ. Association is not causation and sample averages or medians are not personal forecasts. A document/PDF carousel on LinkedIn is not the same native format as an Instagram image carousel. The prototype's platform badges do not verify API support, eligibility or app surfaces.

## Sources

### Metricool: Instagram study, 16 June 2026
https://metricool.com/press-release-instagram-study-2026/

Study: 24,364,803 posts from 375,118 accounts; January–February 2025 versus January–February 2026. Used in the UI for the format-level save signal: carousels produced nine times the saves of single-image posts. This does not establish that every educational or other editorial category performs similarly.

### Metricool: Instagram carousel analysis, 24 June 2026
https://metricool.com/instagram-carousel-multiple-captions/

Used only for its study-based usage observation: carousels were posted 37% less often than single images. This is relative use in the sample, not a complete format-popularity ranking. Feature-rollout claims in the article were not adopted into the prototype.

### Metricool: LinkedIn study, 14 April 2026
https://metricool.com/press-release-linkedin-study-2026/

Study: 673,658 posts, 63,108 accounts; January–February 2025 versus January–February 2026. Company Page image/video posts comprised nearly 75% of the sample's posts; video was the most-used format among Personal Profiles. These populations must not be combined into one claim. The UI uses this as a usage signal, not proof of performance for a specific topic.

### Buffer: content format analysis, 19 March 2026
https://buffer.com/resources/data-best-content-format-social-media/

Format-level engagement observations used for LinkedIn documents, X text, Threads video and Facebook's small differences across formats. The report's linked methodology describes Buffer-published content, not all-platform activity. Engagement definitions are platform-dependent. The UI displays each figure with its scope and limitations rather than a cross-platform leaderboard.

### Buffer: engagement report and methodology, 5 March 2026
https://buffer.com/resources/state-of-social-media-engagement-2026/

General underlying data extends through 3 December 2025; specific analyses use different windows. The Instagram reach observation is drawn from a separate 4M+ post analysis spanning January 2022 to October 2024. Its Reels-versus-carousel reach difference is labelled older reach evidence, not a current algorithm promise.

## Unverified areas
No comparable Xiaohongshu usage/engagement dataset was verified. Its pairings are clearly labelled design suggestions. No ranking of editorial type popularity, live API capability check, account-specific recommendation or causal performance guarantee is provided.

## UI mapping
67 editorial/native suggestions link to one or more of the six demo platforms, or explicitly note a specialist/conditional surface. Choosing a pairing changes only the pending taxonomy choices. It does not connect an account, choose publishing destinations or post content.
