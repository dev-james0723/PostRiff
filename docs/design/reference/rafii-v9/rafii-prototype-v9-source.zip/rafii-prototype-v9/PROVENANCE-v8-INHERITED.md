# v8 provenance

Base: the supplied conversation attachment `rafii-prototype-v7.html` and its source archive.
Base standalone SHA256: `b43f91333f397fd1b86122b045134ef7b1bdc86f650086ac7f896ec769054982`.

This is a local, isolated revision. The live Rafii site, GitHub repository, platform accounts and API credentials were not accessed or modified.

No new third-party artwork or new research data was introduced. All 51 taxonomy illustrations, compact icons, model/provider assets, locales and platform-preview templates are retained from v7. Their original sources, licences and limitations are recorded in `PROVENANCE-v7-INHERITED.md` and the earlier inherited provenance documents. No claim is made that inherited research/model data was refreshed.

The screenshots in `previews-v8/` were captured from the executable HTML. The side-by-side preview uses unaltered 390×844 browser screenshots of v7 and v8, with comparison captions outside the screenshots. It is not an image-generated approximation of the app.
