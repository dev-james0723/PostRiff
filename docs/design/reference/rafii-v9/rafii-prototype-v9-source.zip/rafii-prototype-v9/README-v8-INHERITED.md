# Rafii prototype v8 · Organized Content Library

Open `index.html` in a browser. The file is self-contained and includes its own scripts, styles, icons and data. No server, install, account or network access is needed. A file previewer that does not run JavaScript is not equivalent to a browser.

## This update

The Content Library now has a deliberate hierarchy:

1. Editorial type / Native format: the main content decision.
2. Search: a full-width row on mobile.
3. Gallery / List / Pairings + Filters: aligned 44px-or-larger controls.
4. Category, suggested app fit, artwork motion and research: grouped in one temporary Filters & display panel.
5. Selected editorial type + native format and one primary Use these choices button.

The large mobile introduction, permanent mismatched filter dropdowns, separate category row, isolated pause icon, repeated research/footer copy and desktop category sidebar have been removed from the default surface. Nothing was removed from the underlying taxonomy, app-fit guidance or draft configuration.

Open Filters to choose a category and/or app fit. Changes update results immediately but do not commit draft choices or change selected channels. A count and compact active-filter summary appear on the toolbar; Clear resets category/app filters. Done, Escape, or tapping the backdrop dismisses the panel. Search remains independent. Artwork motion has an explicit text label rather than an isolated triangle. Research and limitations are accessible from the same panel, and pairing evidence links remain in Pairings.

Gallery, List and Pairings retain their original animated transitions. Apply commits the selected content options; closing the library discards pending content changes. The added filter panel has a short eased entrance/exit, a keyboard focus trap and focus restoration. Reduced motion uses immediate transitions.

## Files and scope

- `src/index.html`: scoped library markup update.
- `src/library-v8.css`: new scoped hierarchy/geometry layer, loaded after v7 styles.
- `src/app.js`: filter panel, summary and keyboard/dismissal handling.
- `tests/v8/`: focused acceptance tests, fresh retained-suite results and responsive audit.
- `previews-v8/`: screenshots of this build; `mobile-v7-before.png` is the comparison baseline.

The other prototype features are retained: phone swipe/slide/crossfade, per-channel languages, model/reasoning demo settings, expanded writing area, local editing and session queue. Files in `previews-v7/` and `*-v7-INHERITED.md` are historical evidence, not v8 validation.

## Build and test

```sh
python build.py
node --test tests/*.cjs tests/v5/*.cjs tests/v6/*.cjs tests/v7/*.cjs
python tests/v8/test_toolbar.py
python tests/v8/run_regressions.py
python tests/v8/layout_audit.py
```

Browser tests use Python Playwright and Chromium on PATH. They load the bundled HTML with `set_content`; they do not navigate to a blocked file URL or modify browser policies. v7 tests were updated only to open the new Filters panel before interacting with settings relocated there.

## Boundaries

This remains an offline prototype, not a deployed site or a change to your repository. No AI, CLI, real social accounts or publishing is connected. Session data disappears on reload. App-fit/research data is inherited from v7 and has not been refreshed in v8. Model names/preferences do not assert current API support. No font files or remote image dependencies have been added. Physical iPhone, Safari, Firefox and assistive-technology testing remain unverified.
