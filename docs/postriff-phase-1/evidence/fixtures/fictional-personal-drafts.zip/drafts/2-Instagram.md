# Instagram · 繁體中文

從這裡開始。

主題（作者提供）：一起交換種子，也交換種植心得

• 社區花園將於星期六舉辦免費種子交換活動。
• 參加者可以帶種子來，也可以單純來學習。
• 活動包括適合新手的種植示範。

先收藏這個起點。你最想探索哪一部分？

#社區 #一起學習

---
Deterministic preview.

Deterministic writing preview. No language model was called.
Timing, location, outcomes and personal experience not supplied in approved facts remain unknown.