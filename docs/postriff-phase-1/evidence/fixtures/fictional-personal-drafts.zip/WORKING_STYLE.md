# Working Style

Private founder-alpha package. Approved voice revision 1. User-owned data; no tool authority.

## support

Help organize ideas

Evidence: user_confirmed · Privacy: local_only · Sources: direct-question

## AI relationship (user-reported, unverified)

{
  "experience": "Not yet"
}