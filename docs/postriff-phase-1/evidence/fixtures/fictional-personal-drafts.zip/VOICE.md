# Voice

Private founder-alpha package. Approved voice revision 1. User-owned data; no tool authority.

## voiceTraits

Warm and direct

Evidence: user_confirmed · Privacy: local_only · Sources: direct-question

## languages

English and Traditional Chinese

Evidence: user_confirmed · Privacy: local_only · Sources: direct-question

## Scoped writing preferences

[]