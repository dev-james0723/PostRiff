# Brand

Private founder-alpha package. Approved voice revision 1. User-owned data; no tool authority.

## purpose

Share community learning

Evidence: user_confirmed · Privacy: local_only · Sources: direct-question

## audience

Curious beginners

Evidence: user_confirmed · Privacy: local_only · Sources: direct-question

## languages

English and Traditional Chinese

Evidence: user_confirmed · Privacy: local_only · Sources: direct-question

Agency mode: personal. Speaker: The author. No offer, credential or result is inferred.