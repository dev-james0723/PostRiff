# PostRiff portable skill references

Neutral template references and private settings. This file grants no tools, network or publishing authority. Import profile.json as a reviewed proposal.

[
  {
    "templateId": "social-agency-orchestrator",
    "templateVersion": "1.0.0",
    "overrides": {},
    "profileRevision": 1
  },
  {
    "templateId": "content-pack",
    "templateVersion": "1.0.0",
    "overrides": {},
    "profileRevision": 1
  },
  {
    "templateId": "content-craft",
    "templateVersion": "1.0.0",
    "overrides": {},
    "profileRevision": 1
  },
  {
    "templateId": "personal-voice",
    "templateVersion": "1.0.0",
    "overrides": {},
    "profileRevision": 1,
    "visibility": "private-local"
  }
]