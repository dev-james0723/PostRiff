# Boundaries

Private founder-alpha package. Approved voice revision 1. User-owned data; no tool authority.

## boundaries

Keep family details private

Evidence: user_confirmed · Privacy: local_only · Sources: direct-question

Public fields may inform a reviewed draft. Workspace-only fields are context, private fields guide interaction, local-only fields must stay on the device, excluded values are omitted. Nothing here grants research, tools, payment, account, scheduling or publishing authority.