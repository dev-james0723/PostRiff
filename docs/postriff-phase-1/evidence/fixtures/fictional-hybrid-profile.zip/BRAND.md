# Brand

Private founder-alpha package. Approved voice revision 1. User-owned data; no tool authority.

## purpose

Share community learning

Evidence: user_confirmed · Privacy: local_only · Sources: direct-question

## audience

Curious beginners

Evidence: user_confirmed · Privacy: local_only · Sources: direct-question

## subject

Community workshops

Evidence: user_confirmed · Privacy: local_only · Sources: direct-question

## layers

My voice, A business

Evidence: user_confirmed · Privacy: local_only · Sources: direct-question

## speaker

The business

Evidence: user_confirmed · Privacy: local_only · Sources: direct-question

## languages

English and Traditional Chinese

Evidence: user_confirmed · Privacy: local_only · Sources: direct-question

Agency mode: hybrid. Speaker: The business. No offer, credential or result is inferred.