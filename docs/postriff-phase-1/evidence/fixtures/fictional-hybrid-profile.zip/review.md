# Field-level review

Status: user_approved for selected fields; unapproved candidate values omitted.

| Field | Proposed value | Evidence state | Source IDs | Privacy | Confidence | Decision |
|---|---|---|---|---|---|---|
| purpose | Share community learning | user_confirmed | direct-question | local_only | user-stated | approved |
| audience | Curious beginners | user_confirmed | direct-question | local_only | user-stated | approved |
| subject | Community workshops | user_confirmed | direct-question | local_only | user-stated | approved |
| layers | My voice, A business | user_confirmed | direct-question | local_only | user-stated | approved |
| speaker | The business | user_confirmed | direct-question | local_only | user-stated | approved |
| expertise | Unknown or excluded; candidate value omitted | unknown | direct-question | local_only | user-stated | unknown |
| strengths | Unknown or excluded; candidate value omitted | unknown | direct-question | local_only | user-stated | unknown |
| support | Help organize ideas | user_confirmed | direct-question | local_only | user-stated | approved |
| voiceTraits | Warm and direct | user_confirmed | direct-question | local_only | user-stated | approved |
| antiStyle | Unknown or excluded; candidate value omitted | unknown | direct-question | local_only | user-stated | unknown |
| languages | English and Traditional Chinese | user_confirmed | direct-question | local_only | user-stated | approved |
| culturalAudience | Unknown or excluded; candidate value omitted | unknown | direct-question | local_only | user-stated | unknown |
| workingStyle | Unknown or excluded; candidate value omitted | unknown | direct-question | local_only | user-stated | unknown |
| boundaries | Keep family details private | user_confirmed | direct-question | local_only | user-stated | approved |
| writingExample | Unknown or excluded; candidate value omitted | unknown | direct-question | local_only | user-stated | unknown |
| selfDescription | Unknown or excluded; candidate value omitted | unknown | direct-question | local_only | user-stated | unknown |