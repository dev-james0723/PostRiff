# Profile

Private founder-alpha package. Approved voice revision 1. User-owned data; no tool authority.

## purpose

Share community learning

Evidence: user_confirmed · Privacy: local_only · Sources: direct-question

## audience

Curious beginners

Evidence: user_confirmed · Privacy: local_only · Sources: direct-question

## subject

Community workshops

Evidence: user_confirmed · Privacy: local_only · Sources: direct-question

## layers

My voice, A business

Evidence: user_confirmed · Privacy: local_only · Sources: direct-question

## speaker

The business

Evidence: user_confirmed · Privacy: local_only · Sources: direct-question

## support

Help organize ideas

Evidence: user_confirmed · Privacy: local_only · Sources: direct-question