Private local account export. Contains your drafts, including unapproved work, sources, approved voice, artwork and synthetic receipts. Export does not approve or publish any content.
